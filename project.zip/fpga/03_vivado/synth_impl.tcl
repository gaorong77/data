# ============================================================
# synth_impl.tcl
# PA-3HDA L1_ROI_CNN Vivado 工程级综合 + 实现 + 生成比特流
#
# 功能：
#   1. 创建 Vivado 工程（ZU9EG）
#   2. 创建 Block Design
#      - 添加 Zynq UltraScale+ MPSoC PS
#      - 添加 HLS 生成的 L1_ROI_CNN IP 核
#      - 添加 AXI DMA（用于 PS←→PL 数据搬运）
#      - 连接 AXI4-Lite（控制）/ AXI MM（DDR）/ AXI4-Stream（数据）
#   3. 生成 HDL 包装
#   4. 运行综合 → 实现 → 生成比特流
#   5. 导出 .bit 和 .hwh（用于 PYNQ）
#   6. 报告 DSP/BRAM/LUT 资源利用率
#
# 用法：
#   vivado -mode batch -source fpga/03_vivado/synth_impl.tcl
#
# 前提条件：
#   - Vitis HLS 已完成，IP 位于 ./ip_export/
#   - 用法 XDC 约束存放在 ./constraints/pa3hda_zu9eg.xdc
# ============================================================

# ------------------------------------------------------------
# 全局参数配置
# ------------------------------------------------------------
set ::PROJ_NAME     "pa3hda_fpga"
set ::PROJ_DIR      "./${::PROJ_NAME}"
set ::PART          "xczu9eg-ffvb1156-2-e"
set ::BOARD         ""          ;# 若有板级文件，填写板卡名，否则留空
set ::BD_NAME       "pa3hda_bd"
set ::HLS_IP_DIR    [file normalize "./ip_export"]
set ::OUTPUT_DIR    "./output_files"
set ::TOP_MODULE    "${::BD_NAME}_wrapper"

puts "============================================"
puts " PA-3HDA Vivado 综合实现脚本"
puts "  工程    : ${::PROJ_NAME}"
puts "  器件    : ${::PART}"
puts "  BD 名称 : ${::BD_NAME}"
puts "  HLS IP  : ${::HLS_IP_DIR}"
puts "============================================"

# ------------------------------------------------------------
# 输出目录
# ------------------------------------------------------------
file mkdir ${::OUTPUT_DIR}

# ------------------------------------------------------------
# Step 1: 创建 Vivado 工程
# ------------------------------------------------------------
puts "\n\[Vivado\] 创建工程..."
create_project ${::PROJ_NAME} ${::PROJ_DIR} -part ${::PART} -force

# 设置工程属性
set_property target_language Verilog [current_project]
set_property simulator_language Mixed [current_project]

# 添加 HLS IP 仓库路径
set_property ip_repo_paths ${::HLS_IP_DIR} [current_project]
update_ip_catalog
puts "\[Vivado\] HLS IP 仓库已注册: ${::HLS_IP_DIR}"

# ------------------------------------------------------------
# Step 2: 创建 Block Design
# ------------------------------------------------------------
puts "\n\[Vivado\] 创建 Block Design: ${::BD_NAME}..."
create_bd_design ${::BD_NAME}

# ------ 2.1 添加 Zynq UltraScale+ MPSoC PS ------
puts "\[BD\] 添加 Zynq MPSoC PS..."
set zynq_ps [create_bd_cell -type ip -vlnv xilinx.com:ip:zynq_ultra_ps_e:3.4 zynq_ultra_ps_e_0]

# 应用 ZU9EG 预设（基本 PS 配置，HP0 接口开放给 PL 访问 DDR）
apply_bd_automation -rule xilinx.com:bd_rule:zynq_ultra_ps_e \
    -config {apply_board_preset "0" \
             Master "Disable" \
             Slave  "Disable"} $zynq_ps

# 开启 HP0 AXI Slave 接口（DMA 通过此接口读写 DDR）
set_property -dict [list \
    CONFIG.PSU__USE__M_AXI_GP0 {1} \
    CONFIG.PSU__USE__S_AXI_GP2 {1} \
    CONFIG.PSU__SAXIGP2__DATA_WIDTH {64} \
    CONFIG.PSU__HIGH_ADDRESS__ENABLE {1} \
] $zynq_ps
puts "\[BD\] Zynq MPSoC PS 配置完毕"

# ------ 2.2 添加 AXI DMA ------
# AXI DMA 负责在 DDR（PS 侧）和 HLS IP（PL 侧）之间传输数据
puts "\[BD\] 添加 AXI DMA..."
set axi_dma [create_bd_cell -type ip -vlnv xilinx.com:ip:axi_dma:7.1 axi_dma_0]
set_property -dict [list \
    CONFIG.c_include_sg              {0} \
    CONFIG.c_sg_include_stscntrl_strm {0} \
    CONFIG.c_m_axi_mm2s_data_width   {64} \
    CONFIG.c_m_axis_mm2s_tdata_width {8} \
    CONFIG.c_mm2s_burst_size         {16} \
    CONFIG.c_s2mm_burst_size         {16} \
    CONFIG.c_include_mm2s_dre        {1} \
    CONFIG.c_include_s2mm_dre        {1} \
] $axi_dma
puts "\[BD\] AXI DMA 配置完毕"

# ------ 2.3 添加 HLS L1_ROI_CNN IP 核 ------
# IP 名称以 Vitis HLS 导出时的 vendor:library:name:version 为准
# 默认 vendor=xilinx.com, lib=hls, name=l1_roi_cnn_top
puts "\[BD\] 添加 HLS L1_ROI_CNN IP..."
set hls_ip_name [lindex [get_ipdefs -filter {NAME == l1_roi_cnn_top}] 0]
if {$hls_ip_name eq ""} {
    # 尝试模糊匹配
    set hls_ip_name [lindex [get_ipdefs -filter {NAME =~ *l1_roi_cnn*}] 0]
}
if {$hls_ip_name eq ""} {
    puts "\[BD\] 警告: 未找到 L1_ROI_CNN HLS IP，使用占位 FIFO 代替"
    set hls_ip [create_bd_cell -type ip -vlnv xilinx.com:ip:axis_data_fifo:2.0 l1_roi_cnn_0]
    set_property CONFIG.TDATA_NUM_BYTES {1} $hls_ip
} else {
    puts "\[BD\] 找到 HLS IP: $hls_ip_name"
    set hls_ip [create_bd_cell -type ip -vlnv $hls_ip_name l1_roi_cnn_0]
}

# ------ 2.4 添加 AXI Interconnect（AXI-Lite 控制总线） ------
puts "\[BD\] 添加 AXI Interconnect（控制总线）..."
set axi_ic [create_bd_cell -type ip -vlnv xilinx.com:ip:axi_interconnect:2.1 axi_interconnect_0]
set_property CONFIG.NUM_SI {1} $axi_ic
set_property CONFIG.NUM_MI {1} $axi_ic

# ------ 2.5 添加 Processor System Reset ------
puts "\[BD\] 添加 Proc System Reset..."
set ps_rst [create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset:5.0 proc_sys_reset_0]

# ------------------------------------------------------------
# Step 3: 连接 Block Design
# ------------------------------------------------------------
puts "\n\[BD\] 连接各模块..."

# 3.1 时钟与复位
# PS FCLK_CLK0 (100 MHz) 驱动 DMA 和 HLS IP
connect_bd_net [get_bd_pins zynq_ultra_ps_e_0/pl_clk0] \
               [get_bd_pins axi_dma_0/s_axi_lite_aclk] \
               [get_bd_pins axi_dma_0/m_axi_mm2s_aclk] \
               [get_bd_pins axi_dma_0/m_axi_s2mm_aclk] \
               [get_bd_pins axi_interconnect_0/ACLK] \
               [get_bd_pins axi_interconnect_0/S00_ACLK] \
               [get_bd_pins axi_interconnect_0/M00_ACLK] \
               [get_bd_pins proc_sys_reset_0/slowest_sync_clk]

# HLS IP 时钟
connect_bd_net [get_bd_pins zynq_ultra_ps_e_0/pl_clk0] \
               [get_bd_pins l1_roi_cnn_0/ap_clk]

# 复位连接
connect_bd_net [get_bd_pins zynq_ultra_ps_e_0/pl_resetn0] \
               [get_bd_pins proc_sys_reset_0/ext_reset_in]
connect_bd_net [get_bd_pins proc_sys_reset_0/peripheral_aresetn] \
               [get_bd_pins axi_dma_0/axi_resetn] \
               [get_bd_pins axi_interconnect_0/ARESETN] \
               [get_bd_pins axi_interconnect_0/S00_ARESETN] \
               [get_bd_pins axi_interconnect_0/M00_ARESETN] \
               [get_bd_pins l1_roi_cnn_0/ap_rst_n]

# 3.2 AXI4-Stream 连接（数据通路）
# DMA MM2S (PS→PL) → HLS in_stream
connect_bd_intf_net [get_bd_intf_pins axi_dma_0/M_AXIS_MM2S] \
                    [get_bd_intf_pins l1_roi_cnn_0/in_stream]

# HLS out_stream → DMA S2MM (PL→PS)
connect_bd_intf_net [get_bd_intf_pins l1_roi_cnn_0/out_stream] \
                    [get_bd_intf_pins axi_dma_0/S_AXIS_S2MM]

puts "\[BD\] AXI4-Stream 数据通路连接完毕"

# 3.3 AXI4-Lite 控制接口
# PS M_AXI_HPM0 → AXI Interconnect → DMA S_AXI_LITE
connect_bd_intf_net [get_bd_intf_pins zynq_ultra_ps_e_0/M_AXI_HPM0_LPD] \
                    [get_bd_intf_pins axi_interconnect_0/S00_AXI]
connect_bd_intf_net [get_bd_intf_pins axi_interconnect_0/M00_AXI] \
                    [get_bd_intf_pins axi_dma_0/S_AXI_LITE]

puts "\[BD\] AXI4-Lite 控制接口连接完毕"

# 3.4 AXI Memory Mapped 接口（DMA 读写 DDR）
# DMA MM2S Master → PS HP0 Slave
connect_bd_intf_net [get_bd_intf_pins axi_dma_0/M_AXI_MM2S] \
                    [get_bd_intf_pins zynq_ultra_ps_e_0/S_AXI_HP0_FPD]
# DMA S2MM Master → PS HP0 Slave（通过 AXI SmartConnect 合并，此处简化）
connect_bd_intf_net [get_bd_intf_pins axi_dma_0/M_AXI_S2MM] \
                    [get_bd_intf_pins zynq_ultra_ps_e_0/S_AXI_HP0_FPD]

puts "\[BD\] AXI Memory Mapped 接口连接完毕"

# 3.5 中断（可选：DMA 完成中断连接到 PS）
connect_bd_net [get_bd_pins axi_dma_0/mm2s_introut] \
               [get_bd_pins zynq_ultra_ps_e_0/pl_ps_irq0]
connect_bd_net [get_bd_pins axi_dma_0/s2mm_introut] \
               [get_bd_pins zynq_ultra_ps_e_0/pl_ps_irq1]

puts "\[BD\] 中断连接完毕"

# ------------------------------------------------------------
# Step 4: 验证 BD 并生成 HDL 包装
# ------------------------------------------------------------
puts "\n\[BD\] 验证 Block Design..."
validate_bd_design
puts "\[BD\] 验证通过"

puts "\[BD\] 生成 HDL 包装..."
make_wrapper -files [get_files "${::PROJ_DIR}/${::PROJ_NAME}.srcs/sources_1/bd/${::BD_NAME}/${::BD_NAME}.bd"] -top
add_files -norecurse "${::PROJ_DIR}/${::PROJ_NAME}.srcs/sources_1/bd/${::BD_NAME}/hdl/${::TOP_MODULE}.v"
update_compile_order -fileset sources_1
puts "\[BD\] HDL 包装生成完毕"

# ------------------------------------------------------------
# Step 5: 综合（Synthesis）
# ------------------------------------------------------------
puts "\n\[Vivado\] 开始综合..."
launch_runs synth_1 -jobs 8
wait_on_run synth_1

set synth_status [get_property STATUS [get_runs synth_1]]
puts "\[Vivado\] 综合状态: $synth_status"
if {[get_property PROGRESS [get_runs synth_1]] != "100%"} {
    puts "\[Vivado\] 警告: 综合未 100% 完成，请检查日志"
}

# ------------------------------------------------------------
# Step 6: 实现（Implementation）
# ------------------------------------------------------------
puts "\n\[Vivado\] 开始实现..."
launch_runs impl_1 -to_step write_bitstream -jobs 8
wait_on_run impl_1

set impl_status [get_property STATUS [get_runs impl_1]]
puts "\[Vivado\] 实现状态: $impl_status"

# ------------------------------------------------------------
# Step 7: 导出比特流和 HWH（用于 PYNQ）
# ------------------------------------------------------------
puts "\n\[Vivado\] 导出输出文件..."

# 比特流路径
set bit_src "${::PROJ_DIR}/${::PROJ_NAME}.runs/impl_1/${::TOP_MODULE}.bit"
set bit_dst "${::OUTPUT_DIR}/l1_roi_cnn.bit"

if {[file exists $bit_src]} {
    file copy -force $bit_src $bit_dst
    puts "\[Vivado\] 比特流导出: $bit_dst"
} else {
    puts "\[Vivado\] 警告: 比特流文件未找到: $bit_src"
}

# HWH 文件（硬件描述，PYNQ 加载 overlay 时需要）
set hwh_src "${::PROJ_DIR}/${::PROJ_NAME}.srcs/sources_1/bd/${::BD_NAME}/hw_handoff/${::BD_NAME}.hwh"
set hwh_dst "${::OUTPUT_DIR}/l1_roi_cnn.hwh"

if {[file exists $hwh_src]} {
    file copy -force $hwh_src $hwh_dst
    puts "\[Vivado\] HWH 文件导出: $hwh_dst"
} else {
    puts "\[Vivado\] 警告: HWH 文件未找到: $hwh_src"
}

# ------------------------------------------------------------
# Step 8: 报告资源利用率
# ------------------------------------------------------------
puts "\n\[Vivado\] ---- 资源利用率报告 ----"

# 读取实现后资源报告
open_run impl_1
report_utilization -file "${::OUTPUT_DIR}/utilization.rpt" -hierarchical

# 简单打印 DSP/BRAM/LUT
set util_rpt "${::OUTPUT_DIR}/utilization.rpt"
if {[file exists $util_rpt]} {
    set fp [open $util_rpt r]
    set in_summary 0
    while {[gets $fp line] >= 0} {
        if {[string match "*Slice LUTs*" $line] || \
            [string match "*Block RAM Tile*" $line] || \
            [string match "*DSPs*" $line] || \
            [string match "*1. Slice Logic*" $line] || \
            [string match "*2. Memory*" $line] || \
            [string match "*4. DSP*" $line]} {
            puts $line
        }
    }
    close $fp
}

# 时序报告
report_timing_summary -file "${::OUTPUT_DIR}/timing_summary.rpt"
puts "\[Vivado\] 时序报告已保存: ${::OUTPUT_DIR}/timing_summary.rpt"

# ------------------------------------------------------------
# 完成
# ------------------------------------------------------------
puts "\n============================================"
puts " Vivado 综合实现全部完成！"
puts "  比特流  : ${::OUTPUT_DIR}/l1_roi_cnn.bit"
puts "  HWH     : ${::OUTPUT_DIR}/l1_roi_cnn.hwh"
puts "  资源报告: ${::OUTPUT_DIR}/utilization.rpt"
puts "  时序报告: ${::OUTPUT_DIR}/timing_summary.rpt"
puts "============================================"

# 关闭工程
close_project
exit
