# ============================================================
# create_project.tcl
# PA-3HDA L1_ROI_CNN Vitis HLS 一键创建项目并运行 C 仿真 + 综合
#
# 用法：
#   vitis_hls -f fpga/03_vivado/create_project.tcl
#
# 输出：
#   ./l1_roi_cnn_hls/solution1/syn/report/  综合报告
#   ./l1_roi_cnn_hls/solution1/impl/ip/     IP Catalog 导出
#
# 目标器件  : Xilinx UltraScale+ ZU9EG  xczu9eg-ffvb1156-2-e
# 目标时钟  : 5 ns (200 MHz)
# ============================================================

# ------------------------------------------------------------
# 全局路径配置
# 脚本假定从 PA3HDA_v4/ 根目录运行；
# 若从其他路径运行，修改 ::FPGA_DIR 变量
# ------------------------------------------------------------
set ::FPGA_DIR      "../fpga"
set ::HLS_DIR       "${::FPGA_DIR}/02_hls"
set ::PROJ_NAME     "l1_roi_cnn_hls"
set ::SOL_NAME      "solution1"
set ::TOP_FUNC      "l1_roi_cnn_top"
set ::PART          "xczu9eg-ffvb1156-2-e"
set ::CLOCK_PERIOD  "5"   ;# 单位 ns，对应 200 MHz

puts "============================================"
puts " PA-3HDA HLS 工程创建脚本"
puts "  工程名  : ${::PROJ_NAME}"
puts "  方案    : ${::SOL_NAME}"
puts "  顶层    : ${::TOP_FUNC}"
puts "  器件    : ${::PART}"
puts "  时钟    : ${::CLOCK_PERIOD} ns"
puts "============================================"

# ------------------------------------------------------------
# Step 1: 创建工程
# ------------------------------------------------------------
open_project ${::PROJ_NAME}
puts "\[HLS\] 工程创建完成: ${::PROJ_NAME}"

# ------------------------------------------------------------
# Step 2: 设置顶层函数
# ------------------------------------------------------------
set_top ${::TOP_FUNC}
puts "\[HLS\] 顶层函数: ${::TOP_FUNC}"

# ------------------------------------------------------------
# Step 3: 添加设计源文件（HLS C++）
# ------------------------------------------------------------
add_files "${::HLS_DIR}/l1_roi_cnn.cpp" -cflags "-I${::HLS_DIR}"
add_files "${::HLS_DIR}/l1_roi_cnn.h"   -cflags "-I${::HLS_DIR}"
puts "\[HLS\] 设计文件添加完毕"

# ------------------------------------------------------------
# Step 4: 添加 Testbench（仿真专用，不参与综合）
# ------------------------------------------------------------
add_files -tb "${::HLS_DIR}/l1_roi_cnn_tb.cpp" -cflags "-I${::HLS_DIR}"
puts "\[HLS\] Testbench 文件添加完毕"

# ------------------------------------------------------------
# Step 5: 创建综合方案（Solution）
# ------------------------------------------------------------
open_solution ${::SOL_NAME}

# 选择目标器件
set_part ${::PART}
puts "\[HLS\] 目标器件: ${::PART}"

# 创建时钟约束（5 ns = 200 MHz）
create_clock -period "${::CLOCK_PERIOD}ns" -name default
puts "\[HLS\] 时钟约束: ${::CLOCK_PERIOD} ns"

# ------------------------------------------------------------
# HLS 配置选项
# ------------------------------------------------------------

# 启用流水线重排（允许 HLS 在 II=1 目标下合法重排操作）
config_schedule -effort high -relax_ii_for_timing false

# 使用 DSP 实现乘法（ZU9EG 有 2520 个 DSP）
config_bind -effort high

# 导出使用 IP Catalog 格式
config_export -format ip_catalog -output "./ip_export" -version "1.0"

puts "\[HLS\] HLS 配置完成"

# ------------------------------------------------------------
# Step 6: C 仿真（csim）
# ------------------------------------------------------------
puts "\n\[HLS\] 开始 C 仿真..."
csim_design -O -clean
puts "\[HLS\] C 仿真完成"

# ------------------------------------------------------------
# Step 7: HLS C 综合（csynth）
# 将 HLS C++ 综合为 RTL（Verilog/VHDL）
# ------------------------------------------------------------
puts "\n\[HLS\] 开始 C 综合（csynth）..."
csynth_design
puts "\[HLS\] C 综合完成"

# ------------------------------------------------------------
# Step 8: 读取并打印综合报告（资源估算）
# ------------------------------------------------------------
puts "\n\[HLS\] ---- 综合资源报告摘要 ----"
set rpt_file "./${::PROJ_NAME}/${::SOL_NAME}/syn/report/${::TOP_FUNC}_csynth.rpt"
if {[file exists $rpt_file]} {
    set fp [open $rpt_file r]
    set content [read $fp]
    close $fp
    # 仅打印资源利用率部分
    set lines [split $content "\n"]
    set in_util 0
    foreach line $lines {
        if {[string match "*Utilization Estimates*" $line]} {
            set in_util 1
        }
        if {$in_util} {
            puts $line
        }
        if {$in_util && [string match "*\+----*" $line] && $in_util > 1} {
            break
        }
        if {$in_util} { incr in_util }
        if {$in_util > 30} { break }
    }
} else {
    puts "\[HLS\] 综合报告文件未找到: $rpt_file"
}

# ------------------------------------------------------------
# Step 9: RTL 仿真（可选；默认注释掉节省时间）
# 如需开启，取消下方注释
# ------------------------------------------------------------
# puts "\n\[HLS\] 开始 RTL 仿真（cosim）..."
# cosim_design -O -rtl verilog
# puts "\[HLS\] RTL 仿真完成"

# ------------------------------------------------------------
# Step 10: 导出 IP Catalog
# 生成可在 Vivado Block Design 中直接插入的 IP 包
# ------------------------------------------------------------
puts "\n\[HLS\] 导出 IP Catalog..."
export_design -format ip_catalog -output "./ip_export" -version "1.0" -description "PA-3HDA L1 ROI CNN INT8 Accelerator"
puts "\[HLS\] IP Catalog 导出完成 → ./ip_export"

# ------------------------------------------------------------
# 完成
# ------------------------------------------------------------
puts "\n============================================"
puts " HLS 流程全部完成！"
puts "  综合报告: ./${::PROJ_NAME}/${::SOL_NAME}/syn/report/"
puts "  IP 导出 : ./ip_export"
puts "============================================"

exit
