"""
run_fpga_flow.py
PA-3HDA FPGA 部署一键全流程脚本

流程：
  Step 0 : 环境检查 (PyTorch / onnx / onnxruntime / Vivado / Vitis HLS)
  Step 1 : ONNX 导出
  Step 2 : INT8 量化 + 权重提取
  Step 3 : HLS C 仿真 (csim_design)
  Step 4 : HLS C 综合 (csynth_design)
  Step 5 : Vivado 综合 + 实现 + 比特流生成
  Step 6 : 资源报告汇总 (DSP / BRAM / LUT)

特性：
  - 彩色进度输出
  - 断点续跑 (--resume)，通过 state.json 记录各步状态
  - --export-only 仅执行 Step 0~2，无需 Vivado
  - --check-env  仅做环境检查后退出

用法：
  # 完整流程（需 Vivado 2023.2+）
  python fpga/run_fpga_flow.py --model l1 --checkpoint checkpoints/l1_best.pth

  # 只做导出和量化
  python fpga/run_fpga_flow.py --model l1 --checkpoint checkpoints/l1_best.pth --export-only

  # 检查环境
  python fpga/run_fpga_flow.py --check-env

  # 断点续跑
  python fpga/run_fpga_flow.py --model l1 --checkpoint checkpoints/l1_best.pth --resume

依赖：
  pip install torch onnx onnxruntime numpy
  Vivado 2023.2 / Vitis HLS 2023.2（可选）
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# 路径配置
# ---------------------------------------------------------------------------
SCRIPT_DIR   = Path(__file__).resolve().parent
FPGA_DIR     = SCRIPT_DIR
EXPORT_DIR   = FPGA_DIR / "01_export"
HLS_DIR      = FPGA_DIR / "02_hls"
VIVADO_DIR   = FPGA_DIR / "03_vivado"
WEIGHTS_DIR  = HLS_DIR  / "weights"
STATE_FILE   = FPGA_DIR / "fpga_flow_state.json"

# ---------------------------------------------------------------------------
# 颜色定义（ANSI 终端颜色码）
# ---------------------------------------------------------------------------
class C:
    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    RED    = "\033[91m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    BLUE   = "\033[94m"
    CYAN   = "\033[96m"
    WHITE  = "\033[97m"
    GRAY   = "\033[90m"


# ---------------------------------------------------------------------------
# 打印工具
# ---------------------------------------------------------------------------

def header(text: str) -> None:
    w = 60
    bar = "═" * w
    print(f"\n{C.BOLD}{C.CYAN}╔{bar}╗{C.RESET}")
    print(f"{C.BOLD}{C.CYAN}║  {text:<{w-2}}║{C.RESET}")
    print(f"{C.BOLD}{C.CYAN}╚{bar}╝{C.RESET}\n")


def step_header(n: int, total: int, title: str) -> None:
    pct = int(n / total * 100)
    bar_len = 30
    filled = int(bar_len * n / total)
    bar = "█" * filled + "░" * (bar_len - filled)
    print(
        f"\n{C.BOLD}{C.BLUE}[Step {n}/{total}]{C.RESET} "
        f"{C.WHITE}{title}{C.RESET}"
    )
    print(f"  {C.CYAN}[{bar}] {pct}%{C.RESET}")


def ok(msg: str) -> None:
    print(f"  {C.GREEN}✓{C.RESET}  {msg}")


def warn(msg: str) -> None:
    print(f"  {C.YELLOW}⚠{C.RESET}  {msg}")


def fail(msg: str) -> None:
    print(f"  {C.RED}✗{C.RESET}  {msg}")


def info(msg: str) -> None:
    print(f"  {C.GRAY}·{C.RESET}  {msg}")


def section(title: str) -> None:
    print(f"\n{C.BOLD}{C.YELLOW}── {title} ──{C.RESET}")


# ---------------------------------------------------------------------------
# 状态管理（断点续跑）
# ---------------------------------------------------------------------------

def load_state() -> Dict:
    """加载流程状态。"""
    if STATE_FILE.exists():
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    return {}


def save_state(state: Dict) -> None:
    """保存流程状态。"""
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def step_done(state: Dict, step_name: str) -> bool:
    """检查某步骤是否已完成。"""
    return state.get(step_name, {}).get("done", False)


def mark_done(state: Dict, step_name: str, info_dict: Optional[Dict] = None) -> None:
    """标记步骤完成。"""
    state[step_name] = {
        "done": True,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    if info_dict:
        state[step_name].update(info_dict)
    save_state(state)


# ---------------------------------------------------------------------------
# 环境检查工具
# ---------------------------------------------------------------------------

def check_python_pkg(pkg: str) -> Tuple[bool, str]:
    """检查 Python 包是否已安装。

    Returns:
        (is_installed, version_string)
    """
    try:
        import importlib
        mod = importlib.import_module(pkg)
        ver = getattr(mod, "__version__", "unknown")
        return True, ver
    except ImportError:
        return False, ""


def check_cmd(cmd: str) -> Tuple[bool, str]:
    """检查命令行工具是否存在。

    Returns:
        (exists, first_line_of_output)
    """
    if shutil.which(cmd) is None:
        return False, ""
    try:
        result = subprocess.run(
            [cmd, "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        out = (result.stdout + result.stderr).strip().split("\n")[0]
        return True, out
    except Exception:
        return False, ""


def check_vivado() -> Tuple[bool, str]:
    """检查 Vivado 是否可用。"""
    if shutil.which("vivado") is None:
        return False, ""
    try:
        result = subprocess.run(
            ["vivado", "-version"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        out = (result.stdout + result.stderr).strip().split("\n")[0]
        return True, out
    except Exception:
        return False, ""


def check_vitis_hls() -> Tuple[bool, str]:
    """检查 Vitis HLS 是否可用。"""
    if shutil.which("vitis_hls") is not None:
        try:
            result = subprocess.run(
                ["vitis_hls", "-version"],
                capture_output=True, text=True, timeout=30,
            )
            out = (result.stdout + result.stderr).strip().split("\n")[0]
            return True, out
        except Exception:
            pass
    # 兼容旧版 HLS
    if shutil.which("vivado_hls") is not None:
        return True, "vivado_hls (legacy)"
    return False, ""


# ---------------------------------------------------------------------------
# Step 0: 环境检查
# ---------------------------------------------------------------------------

def step0_check_env(require_vivado: bool = False) -> bool:
    """执行环境检查。

    Args:
        require_vivado: 是否要求 Vivado 必须存在

    Returns:
        True 表示基本依赖满足
    """
    step_header(0, 6, "环境检查")

    all_ok = True
    section("Python 包检查")

    pkg_list = [
        ("torch",        "PyTorch"),
        ("onnx",         "ONNX"),
        ("onnxruntime",  "ONNX Runtime"),
        ("numpy",        "NumPy"),
    ]
    for pkg, name in pkg_list:
        installed, ver = check_python_pkg(pkg)
        if installed:
            ok(f"{name:<15s} {C.GRAY}v{ver}{C.RESET}")
        else:
            fail(f"{name:<15s} 未安装  →  pip install {pkg}")
            all_ok = False

    # 可选包
    for pkg, name in [("scipy", "SciPy"), ("hls4ml", "hls4ml")]:
        installed, ver = check_python_pkg(pkg)
        if installed:
            ok(f"{name:<15s} {C.GRAY}v{ver}{C.RESET} (可选)")
        else:
            warn(f"{name:<15s} 未安装（可选，不影响主流程）")

    section("FPGA 工具链检查")

    # Vivado
    vivado_ok, vivado_ver = check_vivado()
    if vivado_ok:
        ok(f"Vivado         {C.GRAY}{vivado_ver[:60]}{C.RESET}")
    else:
        if require_vivado:
            fail("Vivado 未找到！请将 Vivado bin 目录加入 PATH")
            all_ok = False
        else:
            warn("Vivado 未找到（仅 --export-only 时不影响流程）")

    # Vitis HLS
    hls_ok, hls_ver = check_vitis_hls()
    if hls_ok:
        ok(f"Vitis HLS      {C.GRAY}{hls_ver[:60]}{C.RESET}")
    else:
        if require_vivado:
            fail("Vitis HLS 未找到！请将 Vitis HLS bin 目录加入 PATH")
            all_ok = False
        else:
            warn("Vitis HLS 未找到（仅 --export-only 时不影响流程）")

    section("项目目录检查")
    dirs_to_check = [EXPORT_DIR, HLS_DIR, VIVADO_DIR]
    for d in dirs_to_check:
        if d.exists():
            ok(f"{d.relative_to(FPGA_DIR)}")
        else:
            warn(f"{d.relative_to(FPGA_DIR)} 不存在（将在运行时创建）")

    if all_ok:
        print(f"\n  {C.BOLD}{C.GREEN}环境检查通过 ✓{C.RESET}")
    else:
        print(f"\n  {C.BOLD}{C.RED}存在依赖未满足，请按提示安装后重试{C.RESET}")

    return all_ok


# ---------------------------------------------------------------------------
# Step 1: ONNX 导出
# ---------------------------------------------------------------------------

def step1_export_onnx(model: str, checkpoint: str, state: Dict, resume: bool) -> bool:
    """运行 export_onnx.py 导出 ONNX 模型。"""
    step_header(1, 6, f"ONNX 导出  [{model}]")

    if resume and step_done(state, f"step1_{model}"):
        ok(f"断点续跑：Step 1 ({model}) 已完成，跳过")
        return True

    export_script = EXPORT_DIR / "export_onnx.py"
    if not export_script.exists():
        fail(f"导出脚本不存在: {export_script}")
        return False

    cmd = [
        sys.executable, str(export_script),
        "--model", model,
        "--checkpoint", checkpoint,
    ]
    info(f"命令: {' '.join(cmd)}")

    t0 = time.time()
    result = subprocess.run(cmd, cwd=str(FPGA_DIR.parent), capture_output=False)
    elapsed = time.time() - t0

    if result.returncode == 0:
        ok(f"ONNX 导出成功  ({elapsed:.1f}s)")
        mark_done(state, f"step1_{model}", {"elapsed": elapsed})
        return True
    else:
        fail(f"ONNX 导出失败（返回码 {result.returncode}）")
        return False


# ---------------------------------------------------------------------------
# Step 2: INT8 量化
# ---------------------------------------------------------------------------

def step2_quantize_int8(model: str, checkpoint: str, state: Dict, resume: bool) -> bool:
    """运行 quantize_int8.py 进行 INT8 PTQ。"""
    step_header(2, 6, f"INT8 量化  [{model}]")

    if resume and step_done(state, f"step2_{model}"):
        ok(f"断点续跑：Step 2 ({model}) 已完成，跳过")
        return True

    quant_script = EXPORT_DIR / "quantize_int8.py"
    if not quant_script.exists():
        fail(f"量化脚本不存在: {quant_script}")
        return False

    cmd = [
        sys.executable, str(quant_script),
        "--model", model,
        "--checkpoint", checkpoint,
    ]
    info(f"命令: {' '.join(cmd)}")

    t0 = time.time()
    result = subprocess.run(cmd, cwd=str(FPGA_DIR.parent), capture_output=False)
    elapsed = time.time() - t0

    if result.returncode == 0:
        # 验证权重文件是否生成
        expected_files = [
            WEIGHTS_DIR / f"{model}_conv1_weight_int8.npy",
            WEIGHTS_DIR / f"{model}_scales.json",
        ]
        missing = [str(f) for f in expected_files if not f.exists()]
        if missing:
            warn(f"量化完成但部分权重文件缺失: {missing}")
        else:
            ok(f"INT8 权重文件生成成功 ({elapsed:.1f}s)")
            # 打印生成的权重文件列表
            wfiles = list(WEIGHTS_DIR.glob(f"{model}_*.npy"))
            wfiles += list(WEIGHTS_DIR.glob(f"{model}_*.json"))
            for wf in sorted(wfiles):
                size_kb = wf.stat().st_size / 1024
                info(f"  {wf.name:<40s} {size_kb:.1f} KB")
        mark_done(state, f"step2_{model}", {"elapsed": elapsed})
        return True
    else:
        fail(f"INT8 量化失败（返回码 {result.returncode}）")
        return False


# ---------------------------------------------------------------------------
# Step 3: HLS C 仿真
# ---------------------------------------------------------------------------

def step3_hls_csim(state: Dict, resume: bool) -> bool:
    """运行 Vitis HLS C 仿真。"""
    step_header(3, 6, "HLS C 仿真 (csim_design)")

    if resume and step_done(state, "step3_csim"):
        ok("断点续跑：Step 3 已完成，跳过")
        return True

    hls_ok, _ = check_vitis_hls()
    if not hls_ok:
        warn("Vitis HLS 未安装，跳过 C 仿真")
        mark_done(state, "step3_csim", {"skipped": True})
        return True

    tcl_script = VIVADO_DIR / "create_project.tcl"
    if not tcl_script.exists():
        fail(f"TCL 脚本不存在: {tcl_script}")
        return False

    # 创建临时 TCL 脚本（仅执行 csim，不做综合）
    csim_tcl_content = f"""
# 临时 HLS csim 脚本（仅运行 C 仿真）
open_project l1_roi_cnn_hls_csim
set_top l1_roi_cnn_top
add_files {{{str(HLS_DIR / 'l1_roi_cnn.cpp')} {str(HLS_DIR / 'l1_roi_cnn.h')}}} -cflags "-I{str(HLS_DIR)}"
add_files -tb {str(HLS_DIR / 'l1_roi_cnn_tb.cpp')} -cflags "-I{str(HLS_DIR)}"
open_solution "solution1"
set_part xczu9eg-ffvb1156-2-e
create_clock -period 5ns -name default
csim_design -O -clean
exit
"""
    csim_tcl = VIVADO_DIR / "_run_csim.tcl"
    with open(csim_tcl, "w") as f:
        f.write(csim_tcl_content)

    cmd = ["vitis_hls", "-f", str(csim_tcl)]
    info(f"命令: {' '.join(cmd)}")

    t0 = time.time()
    result = subprocess.run(cmd, cwd=str(VIVADO_DIR), capture_output=False)
    elapsed = time.time() - t0

    # 清理临时文件
    csim_tcl.unlink(missing_ok=True)

    if result.returncode == 0:
        ok(f"HLS C 仿真通过 ({elapsed:.1f}s)")
        mark_done(state, "step3_csim", {"elapsed": elapsed})
        return True
    else:
        fail(f"HLS C 仿真失败（返回码 {result.returncode}）")
        return False


# ---------------------------------------------------------------------------
# Step 4: HLS 综合
# ---------------------------------------------------------------------------

def step4_hls_csynth(state: Dict, resume: bool) -> Optional[Dict]:
    """运行 Vitis HLS C 综合，返回资源估算。

    Returns:
        资源字典 {'DSP': int, 'BRAM': int, 'LUT': int} 或 None（失败）
    """
    step_header(4, 6, "HLS C 综合 (csynth_design)")

    if resume and step_done(state, "step4_csynth"):
        ok("断点续跑：Step 4 已完成，跳过")
        return state.get("step4_csynth", {}).get("resources")

    hls_ok, _ = check_vitis_hls()
    if not hls_ok:
        warn("Vitis HLS 未安装，跳过 C 综合")
        mark_done(state, "step4_csynth", {"skipped": True})
        return None

    tcl_script = VIVADO_DIR / "create_project.tcl"
    cmd = ["vitis_hls", "-f", str(tcl_script)]
    info(f"命令: {' '.join(cmd)}")

    t0 = time.time()
    result = subprocess.run(cmd, cwd=str(VIVADO_DIR), capture_output=True, text=True)
    elapsed = time.time() - t0

    if result.returncode != 0:
        fail(f"HLS 综合失败（返回码 {result.returncode}）")
        print(result.stdout[-3000:])
        return None

    ok(f"HLS 综合完成 ({elapsed:.1f}s)")

    # 解析资源报告
    resources = _parse_hls_resources()
    if resources:
        section("HLS 资源估算")
        info(f"DSP   : {resources.get('DSP',  '?')}")
        info(f"BRAM18: {resources.get('BRAM', '?')}")
        info(f"LUT   : {resources.get('LUT',  '?')}")
        info(f"FF    : {resources.get('FF',   '?')}")
        mark_done(state, "step4_csynth", {"elapsed": elapsed, "resources": resources})
    else:
        mark_done(state, "step4_csynth", {"elapsed": elapsed})

    return resources


def _parse_hls_resources() -> Optional[Dict]:
    """从 HLS 综合报告中解析资源利用率。"""
    rpt_glob = list(VIVADO_DIR.glob("**/l1_roi_cnn_top_csynth.rpt"))
    if not rpt_glob:
        return None

    rpt = rpt_glob[0].read_text(encoding="utf-8", errors="ignore")
    res: Dict = {}

    patterns = {
        "DSP":  r"DSP.*?\|\s*(\d+)",
        "BRAM": r"BRAM_18K.*?\|\s*(\d+)",
        "LUT":  r"(?:LUT|Slice LUT).*?\|\s*(\d+)",
        "FF":   r"FF.*?\|\s*(\d+)",
    }
    for key, pat in patterns.items():
        m = re.search(pat, rpt, re.IGNORECASE)
        if m:
            res[key] = int(m.group(1))

    return res if res else None


# ---------------------------------------------------------------------------
# Step 5: Vivado 综合+实现
# ---------------------------------------------------------------------------

def step5_vivado_impl(state: Dict, resume: bool) -> bool:
    """运行 Vivado 综合、实现、生成比特流。"""
    step_header(5, 6, "Vivado 综合 + 实现 + 比特流生成")

    if resume and step_done(state, "step5_vivado"):
        ok("断点续跑：Step 5 已完成，跳过")
        return True

    vivado_ok, _ = check_vivado()
    if not vivado_ok:
        warn("Vivado 未安装，跳过 Vivado 综合实现")
        mark_done(state, "step5_vivado", {"skipped": True})
        return True

    tcl_script = VIVADO_DIR / "synth_impl.tcl"
    if not tcl_script.exists():
        fail(f"TCL 脚本不存在: {tcl_script}")
        return False

    cmd = ["vivado", "-mode", "batch", "-source", str(tcl_script)]
    info(f"命令: {' '.join(cmd)}")
    info("Vivado 实现通常需要 20~60 分钟，请耐心等待...")

    t0 = time.time()
    result = subprocess.run(cmd, cwd=str(VIVADO_DIR), capture_output=False)
    elapsed = time.time() - t0

    if result.returncode == 0:
        ok(f"Vivado 综合实现完成 ({elapsed/60:.1f} min)")
        mark_done(state, "step5_vivado", {"elapsed": elapsed})
        return True
    else:
        fail(f"Vivado 失败（返回码 {result.returncode}）")
        return False


# ---------------------------------------------------------------------------
# Step 6: 资源报告汇总
# ---------------------------------------------------------------------------

def step6_resource_report(state: Dict) -> None:
    """解析并打印最终资源利用率报告。"""
    step_header(6, 6, "资源报告汇总")

    section("FPGA 目标资源 (ZU9EG)")
    total = {"DSP": 2520, "BRAM18": 1080, "LUT": 522720}
    for k, v in total.items():
        info(f"  {k:<10s}: {v:>8,}")

    # 从 Vivado 报告读取
    util_rpt = VIVADO_DIR / "output_files" / "utilization.rpt"
    if util_rpt.exists():
        section("Vivado 实际资源利用率")
        rpt = util_rpt.read_text(encoding="utf-8", errors="ignore")
        vivado_res = _parse_vivado_resources(rpt)
        if vivado_res:
            _print_resource_table(vivado_res, total)
        else:
            warn("无法解析 Vivado 资源报告，请手动查看: utilization.rpt")
    else:
        section("HLS 资源估算（Vivado 未运行）")
        hls_res = state.get("step4_csynth", {}).get("resources", {})
        if hls_res:
            info("注意：以下为 HLS 估算值，实际 Vivado 结果会有差异")
            print(f"\n  {'资源':<12} {'使用量':>8} {'总量':>10} {'占比':>8}")
            print(f"  {'─'*42}")
            for key, total_val in [("DSP", 2520), ("BRAM", 1080), ("LUT", 522720)]:
                used = hls_res.get(key, "N/A")
                if isinstance(used, int):
                    pct = used / total_val * 100
                    print(f"  {key:<12} {used:>8,} {total_val:>10,} {pct:>7.1f}%")
                else:
                    print(f"  {key:<12} {'N/A':>8} {total_val:>10,} {'N/A':>8}")
        else:
            warn("未找到资源数据（步骤 4 可能被跳过）")

    # 输出文件位置
    section("输出文件")
    output_dir = VIVADO_DIR / "output_files"
    for fname in ["l1_roi_cnn.bit", "l1_roi_cnn.hwh", "utilization.rpt", "timing_summary.rpt"]:
        fpath = output_dir / fname
        if fpath.exists():
            size_kb = fpath.stat().st_size / 1024
            ok(f"{fname:<30s} {size_kb:>8.1f} KB")
        else:
            warn(f"{fname:<30s} 未生成")


def _parse_vivado_resources(rpt_text: str) -> Optional[Dict]:
    """从 Vivado utilization.rpt 解析资源利用率。"""
    res: Dict = {}
    patterns = {
        "LUT":    r"Slice LUTs\s*\|\s*(\d+)",
        "FF":     r"Slice Registers\s*\|\s*(\d+)",
        "BRAM18": r"RAMB18\s*\|\s*(\d+)",
        "DSP":    r"DSPs\s*\|\s*(\d+)",
    }
    for key, pat in patterns.items():
        m = re.search(pat, rpt_text, re.IGNORECASE)
        if m:
            res[key] = int(m.group(1))
    return res if res else None


def _print_resource_table(used: Dict, total: Dict) -> None:
    """打印资源利用率表格。"""
    # 统一键名
    key_map = {"BRAM": "BRAM18", "BRAM18": "BRAM18"}
    print(f"\n  {'资源':<12} {'使用量':>8} {'总量':>10} {'占比':>8}")
    print(f"  {'─'*42}")
    for key, total_val in sorted(total.items()):
        # 尝试几种可能的键名
        used_val = used.get(key) or used.get(key_map.get(key, key))
        if used_val is not None:
            pct = used_val / total_val * 100
            color = C.GREEN if pct < 50 else (C.YELLOW if pct < 80 else C.RED)
            print(
                f"  {key:<12} {used_val:>8,} {total_val:>10,} "
                f"{color}{pct:>7.1f}%{C.RESET}"
            )
        else:
            print(f"  {key:<12} {'N/A':>8} {total_val:>10,} {'N/A':>8}")
    print()


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def main() -> None:
    """主函数：解析参数并依序执行各步骤。"""
    parser = argparse.ArgumentParser(
        description="PA-3HDA FPGA 部署一键全流程脚本",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例：
  python fpga/run_fpga_flow.py --check-env
  python fpga/run_fpga_flow.py --model l1 --checkpoint checkpoints/l1_best.pth
  python fpga/run_fpga_flow.py --model l1 --checkpoint checkpoints/l1_best.pth --export-only
  python fpga/run_fpga_flow.py --model l1 --checkpoint checkpoints/l1_best.pth --resume
        """,
    )
    parser.add_argument("--model", type=str, choices=["l1", "l1_wide", "l2"],
                        help="目标模型名称")
    parser.add_argument("--checkpoint", type=str, default=None,
                        help="PyTorch checkpoint 路径 (.pth)")
    parser.add_argument("--check-env", action="store_true",
                        help="仅检查环境后退出")
    parser.add_argument("--export-only", action="store_true",
                        help="仅执行 Step 0~2（无需 Vivado）")
    parser.add_argument("--resume", action="store_true",
                        help="断点续跑（跳过已完成步骤）")
    parser.add_argument("--clean", action="store_true",
                        help="清除状态文件并重新开始")

    args = parser.parse_args()

    # 标题
    header("PA-3HDA FPGA 部署全流程")
    print(f"  {C.GRAY}工作目录: {FPGA_DIR}{C.RESET}")
    print(f"  {C.GRAY}时间    : {time.strftime('%Y-%m-%d %H:%M:%S')}{C.RESET}\n")

    # 清除状态
    if args.clean and STATE_FILE.exists():
        STATE_FILE.unlink()
        ok("已清除流程状态文件")

    # 加载状态
    state = load_state()

    # --check-env 模式
    if args.check_env:
        step0_check_env(require_vivado=False)
        return

    # 参数验证
    if not args.model:
        parser.error("请指定 --model")
    if not args.checkpoint:
        default_ckpt = f"checkpoints/{args.model}_best.pth"
        warn(f"未指定 --checkpoint，使用默认: {default_ckpt}")
        args.checkpoint = default_ckpt

    require_vivado = not args.export_only

    # Step 0: 环境检查
    env_ok = step0_check_env(require_vivado=require_vivado)
    if not env_ok:
        fail("基础环境检查不通过，终止")
        sys.exit(1)

    # Step 1: ONNX 导出
    if not step1_export_onnx(args.model, args.checkpoint, state, args.resume):
        fail("ONNX 导出失败，终止")
        sys.exit(2)

    # Step 2: INT8 量化
    if not step2_quantize_int8(args.model, args.checkpoint, state, args.resume):
        fail("INT8 量化失败，终止")
        sys.exit(3)

    if args.export_only:
        print(f"\n{C.BOLD}{C.GREEN}--export-only 模式完成！{C.RESET}")
        print(f"  ONNX 文件: {EXPORT_DIR / 'onnx' / f'{args.model}.onnx'}")
        print(f"  权重目录 : {WEIGHTS_DIR}")
        step6_resource_report(state)
        return

    # Step 3: HLS C 仿真
    step3_hls_csim(state, args.resume)

    # Step 4: HLS 综合
    step4_hls_csynth(state, args.resume)

    # Step 5: Vivado 实现
    step5_vivado_impl(state, args.resume)

    # Step 6: 资源报告
    step6_resource_report(state)

    # 完成
    print(f"\n{C.BOLD}{C.GREEN}{'='*60}{C.RESET}")
    print(f"{C.BOLD}{C.GREEN}  PA-3HDA FPGA 全流程完成！{C.RESET}")
    print(f"{C.BOLD}{C.GREEN}{'='*60}{C.RESET}\n")
    print(f"  状态文件: {STATE_FILE}")
    print(f"  输出目录: {VIVADO_DIR / 'output_files'}\n")


if __name__ == "__main__":
    main()
