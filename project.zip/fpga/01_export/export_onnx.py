"""
export_onnx.py
将训练好的 L1 / L1-Wide / L2 模型导出为 ONNX 格式

用法：
    python fpga/01_export/export_onnx.py --model l1 --checkpoint checkpoints/l1_best.pth
    python fpga/01_export/export_onnx.py --model l1_wide --checkpoint checkpoints/l1_wide_best.pth
    python fpga/01_export/export_onnx.py --model l2 --checkpoint checkpoints/l2_best.pth
    python fpga/01_export/export_onnx.py --all   # 导出全部三个模型（需要 --checkpoint 指定目录）

输出：
    fpga/01_export/onnx/l1.onnx
    fpga/01_export/onnx/l1_wide.onnx
    fpga/01_export/onnx/l2.onnx

依赖：
    pip install torch onnx onnxruntime numpy
"""

import argparse
import os
import sys
import logging
from pathlib import Path
from typing import Tuple, Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import onnx
import onnxruntime as ort

# ---------------------------------------------------------------------------
# 路径配置：将项目根目录加入 sys.path，使得可以 import models.l1_roi_cnn
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent          # fpga/01_export/
FPGA_DIR = SCRIPT_DIR.parent                          # fpga/
PROJECT_ROOT = FPGA_DIR.parent                        # PA3HDA_v4/
sys.path.insert(0, str(PROJECT_ROOT))

# ---------------------------------------------------------------------------
# 日志配置
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s][%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 模型定义（内联，以便在 models/l1_roi_cnn.py 不存在时仍可运行）
# ---------------------------------------------------------------------------


class L1_ROI_CNN(nn.Module):
    """
    PA-3HDA 使用的轻量 ROI 分类器，三模型共用相同架构。

    架构：
        Conv2d(1→8, 3×3, pad=1) → ReLU
        Conv2d(8→16, 3×3, pad=1) → ReLU
        AdaptiveAvgPool2d(1)
        Linear(16→1)
        Sigmoid

    参数量：1,265
    """

    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1, bias=True)
        self.relu1 = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1, bias=True)
        self.relu2 = nn.ReLU(inplace=True)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(16, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """前向推理。

        Args:
            x: 输入张量，形状 (N, 1, H, W)

        Returns:
            输出概率张量，形状 (N, 1)
        """
        x = self.relu1(self.conv1(x))
        x = self.relu2(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)   # (N, 16)
        x = self.sigmoid(self.fc(x))
        return x


# ---------------------------------------------------------------------------
# 模型配置表
# ---------------------------------------------------------------------------
MODEL_CONFIGS: Dict[str, Dict] = {
    "l1": {
        "input_shape": (1, 1, 17, 17),
        "default_ckpt": "checkpoints/l1_best.pth",
        "onnx_name": "l1.onnx",
    },
    "l1_wide": {
        "input_shape": (1, 1, 51, 51),
        "default_ckpt": "checkpoints/l1_wide_best.pth",
        "onnx_name": "l1_wide.onnx",
    },
    "l2": {
        "input_shape": (1, 1, 17, 17),
        "default_ckpt": "checkpoints/l2_best.pth",
        "onnx_name": "l2.onnx",
    },
}

# ONNX 输出目录
ONNX_OUTPUT_DIR = SCRIPT_DIR / "onnx"


def count_parameters(model: nn.Module) -> int:
    """统计模型可训练参数总量。

    Args:
        model: PyTorch 模型

    Returns:
        参数总量（整数）
    """
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def print_model_summary(
    model: nn.Module,
    model_name: str,
    input_shape: Tuple[int, ...],
) -> None:
    """打印模型结构摘要。

    Args:
        model: PyTorch 模型
        model_name: 模型名称字符串
        input_shape: 输入张量形状
    """
    n_params = count_parameters(model)
    logger.info("=" * 60)
    logger.info(f"模型名称    : {model_name}")
    logger.info(f"输入形状    : {input_shape}")
    logger.info(f"可训练参数量: {n_params:,}")
    logger.info("层结构:")
    for name, module in model.named_modules():
        if len(list(module.children())) == 0:
            logger.info(f"  {name:<20s} {module}")
    logger.info("=" * 60)


def load_checkpoint(
    checkpoint_path: str,
    model: nn.Module,
) -> nn.Module:
    """加载 PyTorch checkpoint 到模型。

    自动处理 `module.` 前缀（DataParallel 包装模型）。

    Args:
        checkpoint_path: .pth 文件路径
        model: 已实例化但未赋权重的模型

    Returns:
        加载权重后的模型（eval 模式）
    """
    logger.info(f"加载 checkpoint: {checkpoint_path}")
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint 不存在: {checkpoint_path}")

    state_dict = torch.load(checkpoint_path, map_location="cpu")

    # 兼容 {'model': state_dict, ...} 格式
    if isinstance(state_dict, dict):
        if "model" in state_dict:
            state_dict = state_dict["model"]
        elif "state_dict" in state_dict:
            state_dict = state_dict["state_dict"]

    # 去掉 module. 前缀
    cleaned: Dict[str, torch.Tensor] = {}
    for key, val in state_dict.items():
        new_key = key.replace("module.", "", 1)
        cleaned[new_key] = val

    model.load_state_dict(cleaned, strict=True)
    model.eval()
    logger.info("Checkpoint 加载完毕（eval 模式）")
    return model


def export_single_model(
    model_name: str,
    checkpoint_path: str,
    output_dir: Optional[Path] = None,
    opset: int = 11,
    verify: bool = True,
    tol: float = 1e-3,
) -> Path:
    """将单个模型导出为 ONNX 格式。

    Args:
        model_name: 模型类型，取值 "l1" / "l1_wide" / "l2"
        checkpoint_path: .pth checkpoint 路径
        output_dir: ONNX 输出目录，默认 fpga/01_export/onnx/
        opset: ONNX opset 版本，默认 11
        verify: 是否验证 ONNX 推理结果与 PyTorch 一致
        tol: 最大绝对误差容忍值

    Returns:
        导出的 ONNX 文件路径
    """
    if model_name not in MODEL_CONFIGS:
        raise ValueError(f"不支持的模型名称: {model_name}，可选: {list(MODEL_CONFIGS.keys())}")

    cfg = MODEL_CONFIGS[model_name]
    input_shape: Tuple[int, ...] = cfg["input_shape"]
    onnx_filename: str = cfg["onnx_name"]

    if output_dir is None:
        output_dir = ONNX_OUTPUT_DIR
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 构建并加载模型
    model = L1_ROI_CNN()

    # 尝试从项目中导入（若存在）
    try:
        from models.l1_roi_cnn import L1_ROI_CNN as ProjectModel
        model = ProjectModel()
        logger.info("使用 models/l1_roi_cnn.py 中的 L1_ROI_CNN")
    except ImportError:
        logger.info("未找到 models/l1_roi_cnn.py，使用内联 L1_ROI_CNN 定义")

    model = load_checkpoint(checkpoint_path, model)
    print_model_summary(model, model_name, input_shape)

    # 生成随机输入（用于导出与验证）
    torch.manual_seed(42)
    dummy_input = torch.randn(*input_shape)

    # 获取 PyTorch 输出（用于验证）
    with torch.no_grad():
        pt_output: torch.Tensor = model(dummy_input)

    onnx_path = output_dir / onnx_filename

    # 导出 ONNX
    logger.info(f"导出 ONNX (opset={opset}): {onnx_path}")
    torch.onnx.export(
        model,
        dummy_input,
        str(onnx_path),
        opset_version=opset,
        input_names=["input"],
        output_names=["output"],
        dynamic_axes={
            "input": {0: "batch_size"},
            "output": {0: "batch_size"},
        },
        do_constant_folding=True,
        verbose=False,
    )

    # 验证 ONNX 图结构
    onnx_model = onnx.load(str(onnx_path))
    onnx.checker.check_model(onnx_model)
    logger.info("ONNX 图结构校验通过")

    # 打印 ONNX 图简要信息
    graph = onnx_model.graph
    logger.info(f"ONNX 图节点数: {len(graph.node)}")
    logger.info(f"ONNX 输入: {[inp.name for inp in graph.input]}")
    logger.info(f"ONNX 输出: {[out.name for out in graph.output]}")

    # 验证推理一致性
    if verify:
        logger.info("使用 onnxruntime 验证推理结果...")
        sess = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
        ort_inputs = {"input": dummy_input.numpy()}
        ort_output = sess.run(None, ort_inputs)[0]

        pt_np = pt_output.detach().numpy()
        max_abs_err = float(np.max(np.abs(pt_np - ort_output)))
        mean_abs_err = float(np.mean(np.abs(pt_np - ort_output)))

        logger.info(f"PyTorch 输出 : {pt_np.flatten()}")
        logger.info(f"ONNX 输出   : {ort_output.flatten()}")
        logger.info(f"最大绝对误差: {max_abs_err:.3e}")
        logger.info(f"平均绝对误差: {mean_abs_err:.3e}")

        if max_abs_err > tol:
            raise RuntimeError(
                f"ONNX 验证失败: 最大绝对误差 {max_abs_err:.3e} > 容忍值 {tol:.3e}"
            )
        logger.info("ONNX 验证通过 ✓")

    logger.info(f"ONNX 导出完成: {onnx_path}")
    return onnx_path


def main() -> None:
    """主函数：解析命令行参数并执行导出。"""
    parser = argparse.ArgumentParser(
        description="PA-3HDA L1/L1-Wide/L2 模型 ONNX 导出工具"
    )
    parser.add_argument(
        "--model",
        type=str,
        choices=list(MODEL_CONFIGS.keys()),
        help="指定导出的模型名称（l1 / l1_wide / l2）",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help="PyTorch checkpoint 路径（.pth 文件）",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="导出全部三个模型",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="ONNX 输出目录（默认 fpga/01_export/onnx/）",
    )
    parser.add_argument(
        "--opset",
        type=int,
        default=11,
        help="ONNX opset 版本（默认 11）",
    )
    parser.add_argument(
        "--no-verify",
        action="store_true",
        help="跳过 ONNX 推理验证",
    )
    parser.add_argument(
        "--checkpoint-dir",
        type=str,
        default="checkpoints",
        help="--all 模式下的 checkpoint 目录（默认 checkpoints/）",
    )

    args = parser.parse_args()

    if not args.model and not args.all:
        parser.error("请指定 --model 或 --all")

    output_dir = Path(args.output_dir) if args.output_dir else ONNX_OUTPUT_DIR
    verify = not args.no_verify

    if args.all:
        # 全量导出
        for name, cfg in MODEL_CONFIGS.items():
            ckpt = os.path.join(args.checkpoint_dir, os.path.basename(cfg["default_ckpt"]))
            if not os.path.exists(ckpt):
                logger.warning(f"Checkpoint 不存在，跳过 {name}: {ckpt}")
                continue
            export_single_model(
                model_name=name,
                checkpoint_path=ckpt,
                output_dir=output_dir,
                opset=args.opset,
                verify=verify,
            )
    else:
        if args.checkpoint is None:
            default_ckpt = MODEL_CONFIGS[args.model]["default_ckpt"]
            logger.warning(
                f"未指定 --checkpoint，使用默认路径: {default_ckpt}"
            )
            args.checkpoint = default_ckpt
        export_single_model(
            model_name=args.model,
            checkpoint_path=args.checkpoint,
            output_dir=output_dir,
            opset=args.opset,
            verify=verify,
        )

    logger.info("全部导出完成！")


if __name__ == "__main__":
    main()
