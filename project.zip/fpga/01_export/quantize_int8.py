"""
quantize_int8.py
对 PA-3HDA 的 L1 / L1-Wide / L2 模型进行 INT8 Post-Training Quantization (PTQ)。
同时提取 INT8/INT32 权重为 .npy 文件，供 Vivado HLS C++ 实现直接使用。

原理：
    对权重进行对称 INT8 量化：
        scale  = max(|W|) / 127
        W_int8 = clip(round(W / scale), -128, 127)
    对激活进行非对称 INT8 量化（使用校准样本统计范围）：
        scale_act  = (max_act - min_act) / 255
        zero_point = round(-min_act / scale_act)

用法：
    python fpga/01_export/quantize_int8.py --model l1 --checkpoint checkpoints/l1_best.pth
    python fpga/01_export/quantize_int8.py --model l1_wide --checkpoint checkpoints/l1_wide_best.pth
    python fpga/01_export/quantize_int8.py --all --checkpoint-dir checkpoints

输出（保存到 fpga/02_hls/weights/）：
    l1_conv1_weight_int8.npy   (8, 1, 3, 3)
    l1_conv1_bias_int8.npy     (8,)
    l1_conv2_weight_int8.npy   (16, 8, 3, 3)
    l1_conv2_bias_int32.npy    (16,)
    l1_fc_weight_int8.npy      (1, 16)
    l1_fc_bias_int32.npy       (1,)
    l1_scales.json             各层 scale 因子
    （l1_wide / l2 同理，前缀替换）

依赖：
    pip install torch numpy
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

# ---------------------------------------------------------------------------
# 路径配置
# ---------------------------------------------------------------------------
SCRIPT_DIR = Path(__file__).resolve().parent
FPGA_DIR = SCRIPT_DIR.parent
PROJECT_ROOT = FPGA_DIR.parent
WEIGHTS_DIR = FPGA_DIR / "02_hls" / "weights"
sys.path.insert(0, str(PROJECT_ROOT))

# ---------------------------------------------------------------------------
# 日志
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s][%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 内联模型定义（与 export_onnx.py 保持一致）
# ---------------------------------------------------------------------------


class L1_ROI_CNN(nn.Module):
    """PA-3HDA ROI 分类器，参数量 1,265。"""

    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1, bias=True)
        self.relu1 = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1, bias=True)
        self.relu2 = nn.ReLU(inplace=True)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(16, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.relu1(self.conv1(x))
        x = self.relu2(self.conv2(x))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.sigmoid(self.fc(x))
        return x


# ---------------------------------------------------------------------------
# 模型配置
# ---------------------------------------------------------------------------
MODEL_CONFIGS: Dict[str, Dict] = {
    "l1": {
        "input_shape": (1, 1, 17, 17),
        "default_ckpt": "checkpoints/l1_best.pth",
        "prefix": "l1",
    },
    "l1_wide": {
        "input_shape": (1, 1, 51, 51),
        "default_ckpt": "checkpoints/l1_wide_best.pth",
        "prefix": "l1_wide",
    },
    "l2": {
        "input_shape": (1, 1, 17, 17),
        "default_ckpt": "checkpoints/l2_best.pth",
        "prefix": "l2",
    },
}


# ---------------------------------------------------------------------------
# 量化工具函数
# ---------------------------------------------------------------------------


def symmetric_quantize_int8(
    tensor: np.ndarray,
) -> Tuple[np.ndarray, float]:
    """对称 INT8 量化（适用于权重）。

    公式：
        scale  = max(|W|) / 127
        W_int8 = clip(round(W / scale), -128, 127)

    Args:
        tensor: 浮点权重 numpy 数组

    Returns:
        (quantized_int8, scale) 量化后的 INT8 数组和 scale 因子
    """
    abs_max = float(np.max(np.abs(tensor)))
    if abs_max < 1e-8:
        # 全零张量
        return np.zeros_like(tensor, dtype=np.int8), 1.0

    scale = abs_max / 127.0
    quantized = np.round(tensor / scale).clip(-128, 127).astype(np.int8)
    return quantized, scale


def symmetric_quantize_int32(
    tensor: np.ndarray,
    scale: float,
) -> np.ndarray:
    """对偏置进行 INT32 量化（用于后续 INT8 × INT8 累加的偏置对齐）。

    公式：
        b_int32 = round(b / scale)

    Args:
        tensor: 浮点偏置数组
        scale: 对应层的 scale 因子

    Returns:
        INT32 量化后的偏置数组
    """
    return np.round(tensor / scale).astype(np.int32)


def collect_activation_stats(
    model: nn.Module,
    input_shape: Tuple[int, ...],
    n_samples: int = 512,
    seed: int = 42,
) -> Dict[str, Tuple[float, float]]:
    """收集各层激活统计量（min/max），用于激活量化参数确定。

    使用随机输入模拟校准数据集。在正式部署时应替换为真实校准样本。

    Args:
        model: eval 模式的 L1_ROI_CNN 模型
        input_shape: 单样本输入形状，如 (1, 1, 17, 17)
        n_samples: 校准样本数（默认 512）
        seed: 随机种子

    Returns:
        Dict[层名称, (min_activation, max_activation)]
    """
    rng = np.random.default_rng(seed)
    stats: Dict[str, List[float]] = {
        "input": [],
        "conv1_out": [],
        "conv2_out": [],
        "pool_out": [],
        "fc_out": [],
    }

    model.eval()
    with torch.no_grad():
        for _ in range(n_samples):
            # 使用 [0, 1] 均匀分布模拟归一化后的 ROI 输入
            x = torch.from_numpy(rng.uniform(0.0, 1.0, input_shape).astype(np.float32))

            stats["input"].extend(x.numpy().flatten().tolist())

            a1 = model.relu1(model.conv1(x))
            stats["conv1_out"].extend(a1.numpy().flatten().tolist())

            a2 = model.relu2(model.conv2(a1))
            stats["conv2_out"].extend(a2.numpy().flatten().tolist())

            a3 = model.pool(a2)
            stats["pool_out"].extend(a3.numpy().flatten().tolist())

            a4 = model.sigmoid(model.fc(a3.view(a3.size(0), -1)))
            stats["fc_out"].extend(a4.numpy().flatten().tolist())

    result: Dict[str, Tuple[float, float]] = {}
    for layer, values in stats.items():
        arr = np.array(values)
        result[layer] = (float(arr.min()), float(arr.max()))
        logger.info(
            f"激活统计 [{layer:12s}]: min={result[layer][0]:.4f}  max={result[layer][1]:.4f}"
        )

    return result


def compute_activation_scale(
    min_val: float,
    max_val: float,
) -> Tuple[float, int]:
    """根据激活 min/max 计算非对称量化 scale 和 zero_point。

    Args:
        min_val: 激活最小值
        max_val: 激活最大值

    Returns:
        (scale, zero_point)
    """
    scale = (max_val - min_val) / 255.0
    if scale < 1e-8:
        scale = 1.0
    zero_point = int(round(-min_val / scale))
    zero_point = int(np.clip(zero_point, 0, 255))
    return scale, zero_point


def load_checkpoint(checkpoint_path: str, model: nn.Module) -> nn.Module:
    """加载 checkpoint 权重，自动去除 module. 前缀。

    Args:
        checkpoint_path: .pth 文件路径
        model: 已实例化的模型

    Returns:
        加载权重后处于 eval 模式的模型
    """
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint 不存在: {checkpoint_path}")

    state_dict = torch.load(checkpoint_path, map_location="cpu")
    if isinstance(state_dict, dict):
        if "model" in state_dict:
            state_dict = state_dict["model"]
        elif "state_dict" in state_dict:
            state_dict = state_dict["state_dict"]

    cleaned = {k.replace("module.", "", 1): v for k, v in state_dict.items()}
    model.load_state_dict(cleaned, strict=True)
    model.eval()
    logger.info(f"Checkpoint 加载完毕: {checkpoint_path}")
    return model


# ---------------------------------------------------------------------------
# 精度评估
# ---------------------------------------------------------------------------


def evaluate_quantization_accuracy(
    model_fp32: nn.Module,
    weights_int8: Dict[str, np.ndarray],
    scales: Dict[str, float],
    input_shape: Tuple[int, ...],
    n_eval: int = 1000,
    seed: int = 0,
) -> Dict[str, float]:
    """评估量化前后模型输出的误差。

    使用随机输入比较浮点模型与量化仿真模型的输出差异。

    Args:
        model_fp32: 浮点参考模型
        weights_int8: INT8 量化后的权重字典
        scales: 各层 scale 因子字典
        input_shape: 输入形状
        n_eval: 评估样本数
        seed: 随机种子

    Returns:
        包含 max_abs_error、mean_abs_error、accuracy_loss 的字典
    """
    rng = np.random.default_rng(seed)
    errors: List[float] = []

    model_fp32.eval()

    # 构建量化仿真模型（将 INT8 权重反量化为浮点，模拟精度损失）
    model_quant = L1_ROI_CNN()
    model_quant.eval()

    # 用反量化权重填充模型
    with torch.no_grad():
        # conv1 weight
        w1 = weights_int8["conv1_weight"].astype(np.float32) * scales["conv1_weight"]
        b1 = weights_int8["conv1_bias"].astype(np.float32) * scales["conv1_bias"]
        model_quant.conv1.weight.copy_(torch.from_numpy(w1))
        model_quant.conv1.bias.copy_(torch.from_numpy(b1))

        # conv2 weight
        w2 = weights_int8["conv2_weight"].astype(np.float32) * scales["conv2_weight"]
        b2 = (
            weights_int8["conv2_bias"].astype(np.float32)
            * scales["conv2_weight"]
            * scales["conv1_weight"]
        )
        model_quant.conv2.weight.copy_(torch.from_numpy(w2))
        model_quant.conv2.bias.copy_(torch.from_numpy(b2))

        # fc weight
        wf = weights_int8["fc_weight"].astype(np.float32) * scales["fc_weight"]
        bf = (
            weights_int8["fc_bias"].astype(np.float32)
            * scales["fc_weight"]
            * scales["conv2_weight"]
        )
        model_quant.fc.weight.copy_(torch.from_numpy(wf))
        model_quant.fc.bias.copy_(torch.from_numpy(bf))

    with torch.no_grad():
        for _ in range(n_eval):
            x = torch.from_numpy(rng.uniform(0.0, 1.0, input_shape).astype(np.float32))
            out_fp32 = model_fp32(x).item()
            out_quant = model_quant(x).item()
            errors.append(abs(out_fp32 - out_quant))

    max_err = float(np.max(errors))
    mean_err = float(np.mean(errors))

    logger.info(f"量化精度对比 (n={n_eval}):")
    logger.info(f"  最大绝对误差: {max_err:.6f}")
    logger.info(f"  平均绝对误差: {mean_err:.6f}")

    # 阈值 0.5 下的分类准确率差异（粗略估计）
    return {
        "max_abs_error": max_err,
        "mean_abs_error": mean_err,
    }


# ---------------------------------------------------------------------------
# 核心量化入口
# ---------------------------------------------------------------------------


def quantize_single_model(
    model_name: str,
    checkpoint_path: str,
    output_dir: Optional[Path] = None,
    n_calib: int = 512,
) -> Path:
    """对指定模型执行 INT8 PTQ，并保存权重文件。

    Args:
        model_name: 模型名称 "l1" / "l1_wide" / "l2"
        checkpoint_path: .pth checkpoint 路径
        output_dir: 输出目录（默认 fpga/02_hls/weights/）
        n_calib: 校准样本数

    Returns:
        权重保存目录路径
    """
    if model_name not in MODEL_CONFIGS:
        raise ValueError(f"不支持的模型: {model_name}")

    cfg = MODEL_CONFIGS[model_name]
    prefix = cfg["prefix"]
    input_shape: Tuple[int, ...] = cfg["input_shape"]

    if output_dir is None:
        output_dir = WEIGHTS_DIR
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 加载模型
    model = L1_ROI_CNN()
    try:
        from models.l1_roi_cnn import L1_ROI_CNN as ProjectModel
        model = ProjectModel()
    except ImportError:
        pass

    model = load_checkpoint(checkpoint_path, model)
    model.eval()

    logger.info(f"\n{'='*60}")
    logger.info(f"量化模型: {model_name}  前缀: {prefix}")
    logger.info(f"{'='*60}")

    # ----------------------------------------------------------------
    # Step 1: 提取浮点权重
    # ----------------------------------------------------------------
    with torch.no_grad():
        conv1_w = model.features[0].weight.detach().cpu().numpy().copy()
        conv1_b = model.features[0].bias.detach().cpu().numpy().copy()
        conv2_w = model.features[3].weight.detach().cpu().numpy().copy()
        conv2_b = model.features[3].bias.detach().cpu().numpy().copy()
        fc_w = model.classifier.weight.detach().cpu().numpy().copy()
        fc_b = model.classifier.bias.detach().cpu().numpy().copy()


    logger.info("浮点权重范围:")
    for name, arr in [
        ("conv1_weight", conv1_w),
        ("conv1_bias",   conv1_b),
        ("conv2_weight", conv2_w),
        ("conv2_bias",   conv2_b),
        ("fc_weight",    fc_w),
        ("fc_bias",      fc_b),
    ]:
        logger.info(
            f"  {name:<20s}: shape={arr.shape}  "
            f"min={arr.min():.4f}  max={arr.max():.4f}  std={arr.std():.4f}"
        )

    # ----------------------------------------------------------------
    # Step 2: INT8 量化权重
    # ----------------------------------------------------------------
    conv1_w_int8, scale_conv1_w = symmetric_quantize_int8(conv1_w)
    conv1_b_int8, scale_conv1_b = symmetric_quantize_int8(conv1_b)
    conv2_w_int8, scale_conv2_w = symmetric_quantize_int8(conv2_w)
    fc_w_int8, scale_fc_w = symmetric_quantize_int8(fc_w)

    # 偏置使用 INT32（避免累加溢出）
    # conv2_bias: scale = scale_conv1_w * scale_conv2_w（输入和卷积核都量化了）
    # 这里对偏置统一按自身 scale 量化，实际 HLS 中需要对应好累加路径
    scale_conv2_b = scale_conv2_w * scale_conv1_w
    conv2_b_int32 = symmetric_quantize_int32(conv2_b, scale_conv2_b)

    scale_fc_b = scale_fc_w * scale_conv2_w
    fc_b_int32 = symmetric_quantize_int32(fc_b, scale_fc_b)

    # ----------------------------------------------------------------
    # Step 3: 收集激活统计
    # ----------------------------------------------------------------
    logger.info("\n收集激活统计量...")
    act_stats = collect_activation_stats(model, input_shape, n_samples=n_calib)

    scales_json: Dict[str, float] = {
        "conv1_weight": float(scale_conv1_w),
        "conv1_bias": float(scale_conv1_b),
        "conv2_weight": float(scale_conv2_w),
        "conv2_bias": float(scale_conv2_b),
        "fc_weight": float(scale_fc_w),
        "fc_bias": float(scale_fc_b),
    }

    # 激活量化参数
    for layer_name, (mn, mx) in act_stats.items():
        sc, zp = compute_activation_scale(mn, mx)
        scales_json[f"act_{layer_name}_scale"] = sc
        scales_json[f"act_{layer_name}_zero_point"] = zp

    # ----------------------------------------------------------------
    # Step 4: 保存权重文件
    # ----------------------------------------------------------------
    files_saved: List[str] = []

    def save(name: str, arr: np.ndarray) -> None:
        path = output_dir / f"{prefix}_{name}.npy"
        np.save(str(path), arr)
        files_saved.append(str(path))
        logger.info(f"  保存: {path}  shape={arr.shape}  dtype={arr.dtype}")

    logger.info("\n保存 INT8/INT32 权重文件:")
    save("conv1_weight_int8", conv1_w_int8)
    save("conv1_bias_int8", conv1_b_int8)
    save("conv2_weight_int8", conv2_w_int8)
    save("conv2_bias_int32", conv2_b_int32)
    save("fc_weight_int8", fc_w_int8)
    save("fc_bias_int32", fc_b_int32)

    # 保存 scales.json
    scales_path = output_dir / f"{prefix}_scales.json"
    with open(scales_path, "w", encoding="utf-8") as f:
        json.dump(scales_json, f, indent=2, ensure_ascii=False)
    logger.info(f"  保存: {scales_path}")

    # ----------------------------------------------------------------
    # Step 5: 精度评估
    # ----------------------------------------------------------------
    logger.info("\n量化精度评估...")
    weights_int8_dict = {
        "conv1_weight": conv1_w_int8,
        "conv1_bias": conv1_b_int8,
        "conv2_weight": conv2_w_int8,
        "conv2_bias": conv2_b_int32,
        "fc_weight": fc_w_int8,
        "fc_bias": fc_b_int32,
    }
    evaluate_quantization_accuracy(
        model_fp32=model,
        weights_int8=weights_int8_dict,
        scales=scales_json,
        input_shape=input_shape,
        n_eval=1000,
    )

    logger.info(f"\n量化完成，共保存 {len(files_saved)} 个权重文件到: {output_dir}")
    return output_dir


# ---------------------------------------------------------------------------
# 主函数
# ---------------------------------------------------------------------------


def main() -> None:
    """命令行入口。"""
    parser = argparse.ArgumentParser(
        description="PA-3HDA L1/L1-Wide/L2 INT8 PTQ 量化工具"
    )
    parser.add_argument(
        "--model",
        type=str,
        choices=list(MODEL_CONFIGS.keys()),
        help="模型名称",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help="PyTorch checkpoint 路径",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="量化全部三个模型",
    )
    parser.add_argument(
        "--checkpoint-dir",
        type=str,
        default="checkpoints",
        help="--all 模式下的 checkpoint 目录",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="权重输出目录（默认 fpga/02_hls/weights/）",
    )
    parser.add_argument(
        "--n-calib",
        type=int,
        default=512,
        help="校准样本数（默认 512）",
    )

    args = parser.parse_args()

    if not args.model and not args.all:
        parser.error("请指定 --model 或 --all")

    output_dir = Path(args.output_dir) if args.output_dir else WEIGHTS_DIR

    if args.all:
        for name, cfg in MODEL_CONFIGS.items():
            ckpt = os.path.join(
                args.checkpoint_dir,
                os.path.basename(cfg["default_ckpt"]),
            )
            if not os.path.exists(ckpt):
                logger.warning(f"Checkpoint 不存在，跳过 {name}: {ckpt}")
                continue
            quantize_single_model(
                model_name=name,
                checkpoint_path=ckpt,
                output_dir=output_dir,
                n_calib=args.n_calib,
            )
    else:
        if args.checkpoint is None:
            args.checkpoint = MODEL_CONFIGS[args.model]["default_ckpt"]
            logger.warning(f"未指定 --checkpoint，使用默认: {args.checkpoint}")
        quantize_single_model(
            model_name=args.model,
            checkpoint_path=args.checkpoint,
            output_dir=output_dir,
            n_calib=args.n_calib,
        )

    logger.info("INT8 量化全部完成！")


if __name__ == "__main__":
    main()
