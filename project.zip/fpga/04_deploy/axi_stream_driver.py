"""
axi_stream_driver.py
PA-3HDA AXI4-Stream DMA 底层驱动

功能：
  - 不依赖 PYNQ，适用于裸机 Linux 或自定义用户态驱动
  - 通过 /dev/mem + mmap 直接操作 DMA 寄存器
  - 支持 AXI DMA Simple 模式（无 Scatter-Gather）
  - 提供内存分配（CMA / hugepages）辅助工具
  - 提供高层 transfer() 接口供 pynq_inference.py 替换底层时使用

AXI DMA 寄存器偏移（Simple 模式）：
  MM2S_DMACR       = 0x00   # 控制寄存器（MM2S 方向：PS→PL）
  MM2S_DMASR       = 0x04   # 状态寄存器
  MM2S_SA          = 0x18   # 源地址（低 32 位）
  MM2S_SA_MSB      = 0x1C   # 源地址（高 32 位，64-bit 模式）
  MM2S_LENGTH      = 0x28   # 传输字节数

  S2MM_DMACR       = 0x30   # 控制寄存器（S2MM 方向：PL→PS）
  S2MM_DMASR       = 0x34   # 状态寄存器
  S2MM_DA          = 0x48   # 目标地址（低 32 位）
  S2MM_DA_MSB      = 0x4C   # 目标地址（高 32 位）
  S2MM_LENGTH      = 0x58   # 传输字节数

参考资料：
  Xilinx PG021 AXI DMA Product Guide

用法示例（需 root 或 /dev/mem 访问权限）：
  from axi_stream_driver import AxiDMADriver, CMABuffer

  dma = AxiDMADriver(base_addr=0xA0000000, addr_range=0x10000)
  src = CMABuffer.alloc(289)    # 289 字节输入
  dst = CMABuffer.alloc(1)      # 1 字节输出
  src[:] = quantized_input
  dma.transfer(src, dst)
  prob = dst[0] / 255.0

依赖：
  pip install numpy
  # /dev/mem 访问：需要 CONFIG_STRICT_DEVMEM=n 或使用 UIO/devmem2
"""

import ctypes
import mmap
import os
import struct
import time
from typing import Optional

import numpy as np


# ---------------------------------------------------------------------------
# AXI DMA 寄存器偏移（Simple Transfer 模式）
# ---------------------------------------------------------------------------

# MM2S (Memory-Map to Stream)：从内存读取，输出到 AXI4-Stream PL 端
_MM2S_DMACR     = 0x00   # 控制：bit0=RS(运行), bit2=Reset, bit12=IOC_IrqEn
_MM2S_DMASR     = 0x04   # 状态：bit1=Idle, bit12=IOC_Irq(完成中断)
_MM2S_SA        = 0x18   # 源物理地址（低 32 bit）
_MM2S_SA_MSB    = 0x1C   # 源物理地址（高 32 bit，仅 64-bit 地址模式）
_MM2S_LENGTH    = 0x28   # 传输字节数（写入此寄存器触发传输）

# S2MM (Stream to Memory-Map)：接收 AXI4-Stream 数据，写入内存
_S2MM_DMACR     = 0x30
_S2MM_DMASR     = 0x34
_S2MM_DA        = 0x48   # 目标物理地址（低 32 bit）
_S2MM_DA_MSB    = 0x4C
_S2MM_LENGTH    = 0x58

# 控制寄存器掩码
_DMACR_RS       = 0x00000001   # Run/Stop
_DMACR_RESET    = 0x00000004   # 软复位
_DMACR_IOC_IRQEN = 0x00001000  # 传输完成中断使能

# 状态寄存器掩码
_DMASR_IDLE     = 0x00000002   # 空闲
_DMASR_IOC_IRQ  = 0x00001000   # 传输完成中断标志

# 超时常量（秒）
_DEFAULT_TIMEOUT = 5.0
_POLL_INTERVAL   = 1e-4   # 100 μs


# ---------------------------------------------------------------------------
# CMABuffer：物理连续内存缓冲
# ---------------------------------------------------------------------------


class CMABuffer:
    """物理连续内存缓冲（Contiguous Memory Allocator）。

    在真实 PYNQ / Linux CMA 环境中，建议使用 pynq.allocate()。
    此类提供降级方案：使用 /dev/mem + mmap 或 numpy 数组模拟。

    Attributes:
        _buf: 内部 numpy int8 数组
        phys_addr: 物理地址（模拟环境下为虚拟地址，不可用于 DMA）
        nbytes: 缓冲区字节数
    """

    def __init__(self, size: int, dtype: np.dtype = np.dtype("int8")) -> None:
        """初始化 CMA 缓冲区。

        Args:
            size: 字节数
            dtype: numpy 数据类型
        """
        self.nbytes = size
        self._buf = np.zeros(size, dtype=dtype)
        # 获取 numpy 数组的（虚拟）内存地址
        self.phys_addr: int = self._buf.ctypes.data
        self._dtype = dtype

    @classmethod
    def alloc(cls, size: int, dtype: np.dtype = np.dtype("int8")) -> "CMABuffer":
        """分配 CMA 缓冲区。

        Args:
            size: 字节数
            dtype: numpy 数据类型

        Returns:
            CMABuffer 实例
        """
        return cls(size, dtype)

    def __setitem__(self, idx, val) -> None:
        self._buf[idx] = val

    def __getitem__(self, idx):
        return self._buf[idx]

    def as_numpy(self) -> np.ndarray:
        """返回底层 numpy 数组视图。"""
        return self._buf

    def flush(self) -> None:
        """刷新缓存（真实硬件环境需要；此处为空操作）。"""
        pass

    def invalidate(self) -> None:
        """使缓存行无效（真实硬件环境；此处为空操作）。"""
        pass


# ---------------------------------------------------------------------------
# AxiDMADriver：AXI DMA 寄存器操作驱动
# ---------------------------------------------------------------------------


class AxiDMADriver:
    """AXI DMA Simple 模式驱动。

    通过 /dev/mem 直接访问 AXI DMA 寄存器空间。
    支持 MM2S（发送）和 S2MM（接收）双向 DMA。

    Attributes:
        base_addr: AXI DMA 外设基地址（来自 Vivado Address Editor）
        addr_range: 地址空间大小（通常 0x10000）
    """

    def __init__(
        self,
        base_addr: int = 0xA0000000,
        addr_range: int = 0x10000,
        dev_mem: str = "/dev/mem",
    ) -> None:
        """初始化 AXI DMA 驱动。

        Args:
            base_addr: AXI DMA 基地址（十六进制整数）
            addr_range: 地址范围（字节）
            dev_mem: 内存设备文件路径

        Raises:
            PermissionError: 无法打开 /dev/mem
            OSError: mmap 失败
        """
        self.base_addr = base_addr
        self.addr_range = addr_range
        self._dev_mem_path = dev_mem
        self._mmap: Optional[mmap.mmap] = None
        self._fd: Optional[int] = None

        if os.path.exists(dev_mem):
            self._open_devmem()
        else:
            # 开发环境降级：使用模拟寄存器
            self._sim_regs = bytearray(addr_range)
            self._mmap = None
            print(f"[AxiDMADriver] /dev/mem 不存在，切换到仿真模式")

    def _open_devmem(self) -> None:
        """打开 /dev/mem 并映射 AXI DMA 寄存器空间。"""
        try:
            self._fd = os.open(self._dev_mem_path, os.O_RDWR | os.O_SYNC)
            self._mmap = mmap.mmap(
                self._fd,
                self.addr_range,
                mmap.MAP_SHARED,
                mmap.PROT_READ | mmap.PROT_WRITE,
                offset=self.base_addr,
            )
            print(
                f"[AxiDMADriver] 映射 AXI DMA 寄存器 "
                f"@0x{self.base_addr:08X}  range=0x{self.addr_range:X}"
            )
        except (PermissionError, OSError) as e:
            print(f"[AxiDMADriver] 无法映射 /dev/mem: {e}，切换到仿真模式")
            self._sim_regs = bytearray(self.addr_range)
            self._mmap = None
            if self._fd is not None:
                os.close(self._fd)
                self._fd = None

    def _write32(self, offset: int, value: int) -> None:
        """写 32-bit 寄存器。

        Args:
            offset: 相对基地址的偏移（字节）
            value: 32 位值
        """
        if self._mmap is not None:
            self._mmap.seek(offset)
            self._mmap.write(struct.pack("<I", value & 0xFFFFFFFF))
        else:
            struct.pack_into("<I", self._sim_regs, offset, value & 0xFFFFFFFF)

    def _read32(self, offset: int) -> int:
        """读 32-bit 寄存器。

        Args:
            offset: 相对基地址的偏移

        Returns:
            32 位寄存器值
        """
        if self._mmap is not None:
            self._mmap.seek(offset)
            return struct.unpack("<I", self._mmap.read(4))[0]
        else:
            return struct.unpack_from("<I", self._sim_regs, offset)[0]

    def reset(self) -> None:
        """软复位 MM2S 和 S2MM 两个通道。"""
        self._write32(_MM2S_DMACR, _DMACR_RESET)
        self._write32(_S2MM_DMACR, _DMACR_RESET)
        # 等待复位完成（RESET 位自动清零）
        deadline = time.time() + 1.0
        while time.time() < deadline:
            if (
                (self._read32(_MM2S_DMACR) & _DMACR_RESET) == 0 and
                (self._read32(_S2MM_DMACR) & _DMACR_RESET) == 0
            ):
                break
            time.sleep(1e-4)
        print("[AxiDMADriver] DMA 复位完成")

    def _run_mm2s(self, src_phys: int, length: int) -> None:
        """启动 MM2S 通道（内存→AXI4-Stream）。

        Args:
            src_phys: 源物理地址
            length: 传输字节数
        """
        # 使能中断 + Run
        self._write32(_MM2S_DMACR, _DMACR_RS | _DMACR_IOC_IRQEN)
        # 设置源地址
        self._write32(_MM2S_SA, src_phys & 0xFFFFFFFF)
        self._write32(_MM2S_SA_MSB, (src_phys >> 32) & 0xFFFFFFFF)
        # 写入长度寄存器（触发传输）
        self._write32(_MM2S_LENGTH, length)

    def _run_s2mm(self, dst_phys: int, length: int) -> None:
        """启动 S2MM 通道（AXI4-Stream→内存）。

        Args:
            dst_phys: 目标物理地址
            length: 传输字节数
        """
        self._write32(_S2MM_DMACR, _DMACR_RS | _DMACR_IOC_IRQEN)
        self._write32(_S2MM_DA, dst_phys & 0xFFFFFFFF)
        self._write32(_S2MM_DA_MSB, (dst_phys >> 32) & 0xFFFFFFFF)
        self._write32(_S2MM_LENGTH, length)

    def _wait_mm2s_done(self, timeout: float = _DEFAULT_TIMEOUT) -> None:
        """轮询等待 MM2S 传输完成。

        Args:
            timeout: 超时时间（秒）

        Raises:
            TimeoutError: 传输超时
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            sr = self._read32(_MM2S_DMASR)
            if sr & _DMASR_IOC_IRQ:
                # 清除中断标志（写 1 清零）
                self._write32(_MM2S_DMASR, sr | _DMASR_IOC_IRQ)
                return
            time.sleep(_POLL_INTERVAL)
        raise TimeoutError(f"MM2S DMA 超时（{timeout:.1f}s）")

    def _wait_s2mm_done(self, timeout: float = _DEFAULT_TIMEOUT) -> None:
        """轮询等待 S2MM 传输完成。

        Args:
            timeout: 超时时间（秒）

        Raises:
            TimeoutError: 传输超时
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            sr = self._read32(_S2MM_DMASR)
            if sr & _DMASR_IOC_IRQ:
                self._write32(_S2MM_DMASR, sr | _DMASR_IOC_IRQ)
                return
            time.sleep(_POLL_INTERVAL)
        raise TimeoutError(f"S2MM DMA 超时（{timeout:.1f}s）")

    def transfer(
        self,
        src_buf: CMABuffer,
        dst_buf: CMABuffer,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        """执行一次完整的 DMA 传输（发送 + 接收同步）。

        策略：先启动 S2MM（接收），再启动 MM2S（发送），
        避免 PL 输出无人接收造成 AXI4-Stream 反压死锁。

        Args:
            src_buf: 输入缓冲（PS→PL）
            dst_buf: 输出缓冲（PL→PS）
            timeout: 单通道超时时间（秒）
        """
        src_buf.flush()     # 确保写穿到物理内存

        # Step 1: 启动 S2MM（接收方向），准备好接收 PL 输出
        self._run_s2mm(dst_buf.phys_addr, dst_buf.nbytes)

        # Step 2: 启动 MM2S（发送方向），将输入数据推给 PL
        self._run_mm2s(src_buf.phys_addr, src_buf.nbytes)

        # Step 3: 等待 MM2S 完成
        self._wait_mm2s_done(timeout)

        # Step 4: 等待 S2MM 完成（PL 处理 + 返回数据）
        self._wait_s2mm_done(timeout)

        dst_buf.invalidate()  # 使目标缓存失效，确保读取到最新数据

    def read_mm2s_status(self) -> Dict:
        """读取 MM2S 通道状态寄存器。

        Returns:
            包含状态标志的字典
        """
        sr = self._read32(_MM2S_DMASR)
        return {
            "raw": hex(sr),
            "idle":    bool(sr & _DMASR_IDLE),
            "ioc_irq": bool(sr & _DMASR_IOC_IRQ),
            "error":   bool(sr & 0x0000000E),  # ORed 各错误位
        }

    def read_s2mm_status(self) -> Dict:
        """读取 S2MM 通道状态寄存器。"""
        sr = self._read32(_S2MM_DMASR)
        return {
            "raw": hex(sr),
            "idle":    bool(sr & _DMASR_IDLE),
            "ioc_irq": bool(sr & _DMASR_IOC_IRQ),
            "error":   bool(sr & 0x0000000E),
        }

    def close(self) -> None:
        """释放 mmap 和文件描述符。"""
        if self._mmap is not None:
            self._mmap.close()
            self._mmap = None
        if self._fd is not None:
            os.close(self._fd)
            self._fd = None
        print("[AxiDMADriver] 驱动已关闭")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# ---------------------------------------------------------------------------
# 类型补充（Dict 用到了 typing，需要导入）
# ---------------------------------------------------------------------------
from typing import Dict  # noqa: E402 (已在顶部导入，重复无害)


# ---------------------------------------------------------------------------
# 命令行自测（需要 /dev/mem 访问或仿真模式）
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=== AxiDMADriver 自测 ===")
    # 在仿真模式下（无 /dev/mem），验证寄存器读写
    dma = AxiDMADriver(base_addr=0xA0000000)

    # 测试复位
    dma.reset()

    # 测试 CMA 缓冲
    src = CMABuffer.alloc(289, dtype=np.dtype("int8"))
    dst = CMABuffer.alloc(1,   dtype=np.dtype("uint8"))

    # 填充测试数据
    src[:] = np.arange(289, dtype=np.int8) % 127

    # 执行传输（仿真模式，不真实传输）
    print("[TEST] 执行 DMA transfer（仿真）...")
    dma.transfer(src, dst)
    print(f"[TEST] 传输完成，dst={dst[0]}")

    # 读取状态
    print(f"[TEST] MM2S 状态: {dma.read_mm2s_status()}")
    print(f"[TEST] S2MM 状态: {dma.read_s2mm_status()}")

    dma.close()
    print("=== 自测完成 ===")
