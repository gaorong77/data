"""
pynq_inference.py
在 PYNQ 板上运行 PA-3HDA L1 / L1-Wide / L2 ROI 推理（PS 侧 Python 接口）

支持：
  - 加载比特流（.bit + .hwh）
  - AXI DMA 驱动（MM2S + S2MM）
  - 输入 float32 ROI → INT8 量化 → 发送到 PL → 接收结果 → 反量化为概率
  - 单张推理与批量推理
  - 延迟测量（精确到 ms）

依赖（在 PYNQ 板上运行）：
  pip install pynq numpy

用法（在 PYNQ Jupyter / 终端运行）：
  from fpga.deploy.pynq_inference import L1FPGAInference
  inf = L1FPGAInference('output_files/l1_roi_cnn.bit', model='l1')
  roi  = np.random.rand(17, 17).astype(np.float32)
  prob = inf.infer(roi)
  print(f'推理概率: {prob:.4f}')
"""

import json
import os
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np

# PYNQ 依赖（仅在 PYNQ 环境中可用；本地开发时 mock）
try:
    from pynq import Overlay, allocate
    import pynq.lib.dma  # noqa
    PYNQ_AVAILABLE = True
except ImportError:
    PYNQ_AVAILABLE = False
    print("[pynq_inference] 未找到 pynq 库，将使用 MockOverlay 进行仿真模式。")


# ---------------------------------------------------------------------------
# MockOverlay：在非 PYNQ 环境下用于本地开发调试
# ---------------------------------------------------------------------------

class _MockDMA:
    """DMA 接口模拟，不执行真实硬件操作。"""

    class _Channel:
        def transfer(self, buf: np.ndarray) -> None:
            pass
        def wait(self) -> None:
            pass

    def __init__(self) -> None:
        self.sendchannel = self._Channel()
        self.recvchannel = self._Channel()


class _MockOverlay:
    """Overlay 接口模拟，供非 PYNQ 环境调试。"""

    def __init__(self, bitfile: str, **kwargs) -> None:
        self._bitfile = bitfile
        self.axi_dma_0 = _MockDMA()
        print(f"[MockOverlay] 已加载（仿真）: {bitfile}")

    def __getattr__(self, name: str):
        return _MockDMA()


def _alloc_or_zeros(shape: Tuple[int, ...], dtype: np.dtype) -> np.ndarray:
    """在 PYNQ 环境申请连续内存缓冲，否则返回普通 ndarray。"""
    if PYNQ_AVAILABLE:
        return allocate(shape=shape, dtype=dtype)
    return np.zeros(shape, dtype=dtype)


# ---------------------------------------------------------------------------
# 模型配置（输入尺寸、量化参数文件路径等）
# ---------------------------------------------------------------------------

# 默认量化参数目录（相对本文件）
_DEFAULT_WEIGHTS_DIR = Path(__file__).resolve().parent.parent / "02_hls" / "weights"

MODEL_INPUT_SHAPES: Dict[str, Tuple[int, int]] = {
    "l1":       (17, 17),
    "l1_wide":  (51, 51),
    "l2":       (17, 17),
}


def load_scales(model: str, weights_dir: Optional[Path] = None) -> Dict[str, float]:
    """加载量化参数 scales.json。

    Args:
        model: 模型名称 "l1" / "l1_wide" / "l2"
        weights_dir: 权重目录路径

    Returns:
        包含 scale 和 zero_point 的字典
    """
    if weights_dir is None:
        weights_dir = _DEFAULT_WEIGHTS_DIR
    scales_path = weights_dir / f"{model}_scales.json"
    if not scales_path.exists():
        print(f"[pynq_inference] 量化参数文件不存在，使用默认 scale=1/127: {scales_path}")
        return {"act_input_scale": 1.0 / 127.0, "act_input_zero_point": 0}
    with open(scales_path, "r", encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# L1FPGAInference
# ---------------------------------------------------------------------------


class L1FPGAInference:
    """PA-3HDA L1 / L1-Wide / L2 FPGA 推理接口。

    在 PYNQ 板上通过 AXI DMA 将量化 ROI 图像发送到 PL，接收推理结果。

    Attributes:
        overlay: PYNQ Overlay 对象
        dma: AXI DMA 对象
        model: 模型名称
        input_h: 输入图像高度
        input_w: 输入图像宽度
        n_pixels: 总像素数
        input_scale: 输入量化 scale
        output_scale: 输出反量化 scale（1/255）
    """

    def __init__(
        self,
        bitfile: str,
        model: str = "l1",
        weights_dir: Optional[str] = None,
        dma_name: str = "axi_dma_0",
    ) -> None:
        """初始化 FPGA 推理实例。

        Args:
            bitfile: 比特流路径（.bit 文件；同目录下需有 .hwh）
            model: 模型类型 "l1" / "l1_wide" / "l2"
            weights_dir: 量化参数目录（默认 fpga/02_hls/weights/）
            dma_name: Block Design 中 AXI DMA IP 名称
        """
        if model not in MODEL_INPUT_SHAPES:
            raise ValueError(f"不支持的模型: {model}，可选: {list(MODEL_INPUT_SHAPES.keys())}")

        self.model = model
        self.input_h, self.input_w = MODEL_INPUT_SHAPES[model]
        self.n_pixels = self.input_h * self.input_w

        # 加载量化参数
        wd = Path(weights_dir) if weights_dir else None
        self.scales = load_scales(model, wd)
        self.input_scale: float = float(self.scales.get("act_input_scale", 1.0 / 127.0))
        self.input_zp: int = int(self.scales.get("act_input_zero_point", 0))
        # 输出反量化：HLS 输出 [0..255]，对应概率 [0..1]
        self.output_scale: float = 1.0 / 255.0

        # 加载比特流
        if PYNQ_AVAILABLE:
            print(f"[PYNQ] 加载比特流: {bitfile}")
            self.overlay = Overlay(bitfile)
        else:
            self.overlay = _MockOverlay(bitfile)

        # 获取 DMA 对象
        self.dma = getattr(self.overlay, dma_name)

        # 预分配 DMA 缓冲（连续物理内存，减少推理延迟）
        # 输入：n_pixels 个 INT8（每像素 1 字节）
        self.in_buf = _alloc_or_zeros(shape=(self.n_pixels,), dtype=np.int8)
        # 输出：1 字节（uint8 概率）
        self.out_buf = _alloc_or_zeros(shape=(1,), dtype=np.uint8)

        print(
            f"[L1FPGAInference] 初始化完成\n"
            f"  模型    : {model}\n"
            f"  输入尺寸: {self.input_h}×{self.input_w} = {self.n_pixels} pixels\n"
            f"  input_scale: {self.input_scale:.6f}  input_zp: {self.input_zp}\n"
            f"  DMA     : {dma_name}"
        )

    def _quantize_input(self, roi: np.ndarray) -> np.ndarray:
        """将 float32 ROI 图像量化为 INT8。

        Args:
            roi: 输入图像，形状 (H, W) 或 (1, H, W) 或 (1, 1, H, W)，float32

        Returns:
            量化后的 INT8 数组，形状 (H*W,)，行优先排列
        """
        # 归一化到 [0, 1] 范围（若已归一化，此处为无操作）
        roi = roi.squeeze().astype(np.float32)
        if roi.shape != (self.input_h, self.input_w):
            raise ValueError(
                f"输入形状不匹配: 期望 ({self.input_h}, {self.input_w})，实际 {roi.shape}"
            )

        # 非对称量化：q = clip(round(x / scale) + zero_point, 0, 127)
        q = np.round(roi / self.input_scale).astype(np.int32) + self.input_zp
        q = np.clip(q, -128, 127).astype(np.int8)
        return q.flatten()

    def _dequantize_output(self, out_bytes: int) -> float:
        """将 PL 返回的 [0..255] 字节反量化为浮点概率。

        Args:
            out_bytes: HLS 输出的 uint8 值 [0..255]

        Returns:
            浮点概率 [0.0, 1.0]
        """
        return float(out_bytes) * self.output_scale

    def _dma_transfer(self) -> None:
        """执行一次 DMA 双向传输（MM2S + S2MM）。

        in_buf 发送到 PL，PL 处理完毕后结果写回 out_buf。
        使用先发后收策略，减少握手等待。
        """
        # 先启动接收通道（S2MM：PL→PS），防止 PL 输出无人接收造成反压
        self.dma.recvchannel.transfer(self.out_buf)
        # 启动发送通道（MM2S：PS→PL）
        self.dma.sendchannel.transfer(self.in_buf)
        # 等待发送完成
        self.dma.sendchannel.wait()
        # 等待接收完成
        self.dma.recvchannel.wait()

    def infer(self, roi: np.ndarray) -> float:
        """对单张 ROI 图像进行推理。

        Args:
            roi: (H, W) float32 图像，取值范围 [0, 1]

        Returns:
            概率值 float [0.0, 1.0]
        """
        # 量化输入
        q_input = self._quantize_input(roi)
        np.copyto(self.in_buf, q_input)

        # DMA 传输
        self._dma_transfer()

        # 反量化输出
        prob = self._dequantize_output(int(self.out_buf[0]))
        return prob

    def infer_batch(
        self,
        rois: List[np.ndarray],
        verbose: bool = False,
    ) -> List[float]:
        """批量推理。

        Args:
            rois: ROI 图像列表，每个元素形状 (H, W) float32
            verbose: 是否打印每张延迟

        Returns:
            概率列表 float [0.0, 1.0]
        """
        results: List[float] = []
        latencies: List[float] = []

        for i, roi in enumerate(rois):
            t0 = time.perf_counter()
            prob = self.infer(roi)
            t1 = time.perf_counter()
            lat_ms = (t1 - t0) * 1000.0

            results.append(prob)
            latencies.append(lat_ms)

            if verbose:
                print(f"  [Sample {i:4d}] prob={prob:.4f}  latency={lat_ms:.2f} ms")

        if latencies:
            print(
                f"\n[批量推理完成] n={len(rois)}\n"
                f"  平均延迟: {np.mean(latencies):.2f} ms\n"
                f"  最大延迟: {np.max(latencies):.2f} ms\n"
                f"  最小延迟: {np.min(latencies):.2f} ms\n"
                f"  吞吐量  : {1000.0 / np.mean(latencies):.1f} FPS"
            )

        return results

    def benchmark(self, n_runs: int = 100) -> Dict[str, float]:
        """运行推理延迟基准测试。

        Args:
            n_runs: 运行次数（默认 100）

        Returns:
            包含延迟统计信息的字典（ms）
        """
        print(f"[Benchmark] 运行 {n_runs} 次推理...")
        dummy_roi = np.random.rand(self.input_h, self.input_w).astype(np.float32)

        # 预热（5 次）
        for _ in range(5):
            self.infer(dummy_roi)

        latencies: List[float] = []
        for _ in range(n_runs):
            t0 = time.perf_counter()
            self.infer(dummy_roi)
            t1 = time.perf_counter()
            latencies.append((t1 - t0) * 1000.0)

        stats = {
            "mean_ms":   float(np.mean(latencies)),
            "std_ms":    float(np.std(latencies)),
            "min_ms":    float(np.min(latencies)),
            "max_ms":    float(np.max(latencies)),
            "p50_ms":    float(np.percentile(latencies, 50)),
            "p95_ms":    float(np.percentile(latencies, 95)),
            "p99_ms":    float(np.percentile(latencies, 99)),
            "fps":       float(1000.0 / np.mean(latencies)),
        }

        print(
            f"\n[Benchmark 结果] 模型={self.model}  n={n_runs}\n"
            f"  平均延迟: {stats['mean_ms']:.3f} ms\n"
            f"  P50     : {stats['p50_ms']:.3f} ms\n"
            f"  P95     : {stats['p95_ms']:.3f} ms\n"
            f"  P99     : {stats['p99_ms']:.3f} ms\n"
            f"  吞吐量  : {stats['fps']:.1f} FPS"
        )
        return stats

    def close(self) -> None:
        """释放 DMA 缓冲区（在 PYNQ 环境中调用）。"""
        if PYNQ_AVAILABLE:
            if hasattr(self.in_buf, "freebuffer"):
                self.in_buf.freebuffer()
            if hasattr(self.out_buf, "freebuffer"):
                self.out_buf.freebuffer()
        print("[L1FPGAInference] 资源已释放")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# ---------------------------------------------------------------------------
# 命令行入口（快速测试）
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="PA-3HDA PYNQ FPGA 推理测试")
    parser.add_argument("--bit", type=str, required=True, help="比特流路径 (.bit)")
    parser.add_argument("--model", type=str, default="l1", choices=list(MODEL_INPUT_SHAPES.keys()))
    parser.add_argument("--n-bench", type=int, default=100, help="基准测试次数")
    args = parser.parse_args()

    with L1FPGAInference(args.bit, model=args.model) as inf:
        # 单样本测试
        h, w = MODEL_INPUT_SHAPES[args.model]
        roi = np.random.rand(h, w).astype(np.float32)
        prob = inf.infer(roi)
        print(f"\n单样本推理结果: {prob:.6f}")

        # 基准测试
        inf.benchmark(n_runs=args.n_bench)
