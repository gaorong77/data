/*
 * l1_roi_cnn_tb.cpp
 * PA-3HDA  L1_ROI_CNN  Vivado HLS Testbench
 *
 * 功能：
 *   1. 生成随机 17×17 INT8 输入
 *   2. 调用 l1_roi_cnn_top（通过 AXI4-Stream 接口）
 *   3. 从参考文件（ref_output.txt）读取预期输出（可选）
 *   4. 打印误差统计
 *
 * 参考文件格式（ref_output.txt）：
 *   每行一个整数 [0..255]，对应每个测试样本的参考输出
 *
 * 编译运行（C 仿真）：
 *   vitis_hls -f create_project.tcl  -> csim_design
 */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

#include "l1_roi_cnn.h"

/* =========================================================
 *  测试参数
 * ========================================================= */
/* 测试样本数（C 仿真建议不超过 100，否则耗时较长） */
#define N_TEST_SAMPLES   20

/* 随机种子 */
#define RAND_SEED        42

/* 参考输出文件（由 Python 预先生成；不存在时跳过精度验证） */
#define REF_OUTPUT_FILE  "ref_output.txt"

/* 允许误差（INT8 量化后最大可接受绝对误差）*/
#define MAX_ALLOWED_ERR  10   /* 单位：[0..255] LUT 输出空间 */

/* =========================================================
 *  辅助函数
 * ========================================================= */

/**
 * pack_stream - 将 INT8 数组打包成 AXI4-Stream
 * @param buf     INT8 像素缓冲
 * @param n       像素总数（17×17=289）
 * @param stream  输出 AXI4-Stream
 */
static void pack_stream(
    const data_int8_t* buf,
    int n,
    hls::stream<axis_word_t>& stream
) {
    for (int i = 0; i < n; i++) {
        axis_word_t beat;
        beat.data = (ap_uint<8>)((unsigned char)buf[i]);
        beat.keep = 1;
        beat.strb = 1;
        beat.last = (i == n - 1) ? 1 : 0;
        stream.write(beat);
    }
}

/**
 * unpack_stream - 从 AXI4-Stream 读取结果
 * @param stream  输入 AXI4-Stream
 * @return        读取到的第一个 uint8 值
 */
static unsigned int unpack_stream(
    hls::stream<axis_word_t>& stream
) {
    axis_word_t beat = stream.read();
    return (unsigned int)(beat.data);
}

/**
 * load_ref_outputs - 从文本文件加载参考输出
 * @param filename 文件路径
 * @param refs     输出：参考值向量（每个 [0..255]）
 * @return         是否成功
 */
static bool load_ref_outputs(
    const char* filename,
    std::vector<int>& refs
) {
    std::ifstream f(filename);
    if (!f.is_open()) {
        std::cerr << "[TB] 参考文件不存在，跳过精度验证: " << filename << std::endl;
        return false;
    }
    int v;
    while (f >> v) {
        refs.push_back(v);
    }
    std::cout << "[TB] 加载参考输出 " << refs.size() << " 条" << std::endl;
    return true;
}

/**
 * generate_random_input - 生成随机 INT8 输入
 * @param buf   输出缓冲 [1][17][17] 展平为 289 个
 * @param seed  随机种子（每次递增）
 */
static void generate_random_input(
    data_int8_t buf[L1_IN_C * L1_IN_H * L1_IN_W],
    int seed
) {
    srand(seed);
    for (int i = 0; i < L1_IN_C * L1_IN_H * L1_IN_W; i++) {
        /* 输入范围模拟量化后的 [0,127] 正值图像 */
        buf[i] = (data_int8_t)(rand() % 128);
    }
}

/* =========================================================
 *  main
 * ========================================================= */
int main(int argc, char* argv[]) {
    std::cout << "=======================================" << std::endl;
    std::cout << " PA-3HDA L1_ROI_CNN HLS Testbench" << std::endl;
    std::cout << " 测试样本数: " << N_TEST_SAMPLES << std::endl;
    std::cout << "=======================================" << std::endl;

    /* 加载参考输出（若存在） */
    std::vector<int> ref_outputs;
    bool has_ref = load_ref_outputs(REF_OUTPUT_FILE, ref_outputs);

    /* 统计变量 */
    int pass_count = 0;
    int fail_count = 0;
    double sum_err = 0.0;
    int    max_err = 0;

    /* ---- 逐样本测试 ---- */
    for (int sample = 0; sample < N_TEST_SAMPLES; sample++) {
        /* Step 1: 生成随机输入 */
        data_int8_t flat_input[L1_IN_C * L1_IN_H * L1_IN_W];
        generate_random_input(flat_input, RAND_SEED + sample);

        /* Step 2: 构建 AXI4-Stream */
        hls::stream<axis_word_t> in_stream("in_stream");
        hls::stream<axis_word_t> out_stream("out_stream");

        pack_stream(flat_input, L1_IN_C * L1_IN_H * L1_IN_W, in_stream);

        /* Step 3: 调用顶层函数 */
        l1_roi_cnn_top(in_stream, out_stream);

        /* Step 4: 读取输出 */
        unsigned int dut_output = unpack_stream(out_stream);

        /* Step 5: 与参考对比 */
        int err = 0;
        bool pass = true;

        if (has_ref && sample < (int)ref_outputs.size()) {
            int ref_val = ref_outputs[sample];
            err = abs((int)dut_output - ref_val);
            pass = (err <= MAX_ALLOWED_ERR);

            sum_err += err;
            if (err > max_err) max_err = err;

            if (pass) pass_count++;
            else      fail_count++;

            printf("[Sample %03d] DUT=%3u  REF=%3u  ERR=%3d  %s\n",
                   sample, dut_output, (unsigned)ref_val, err,
                   pass ? "PASS" : "FAIL");
        } else {
            /* 无参考时，仅打印输出 */
            printf("[Sample %03d] DUT=%3u  (无参考)\n", sample, dut_output);
            pass_count++;
        }

        /* 验证输出流为空（无多余 Beat） */
        if (!out_stream.empty()) {
            std::cerr << "[TB] 错误: out_stream 有剩余 Beat，样本 " << sample << std::endl;
            fail_count++;
        }

        /* 验证输入流已全部消费 */
        if (!in_stream.empty()) {
            std::cerr << "[TB] 错误: in_stream 未全部读取，样本 " << sample << std::endl;
            fail_count++;
        }
    }

    /* ---- 汇总报告 ---- */
    std::cout << std::endl;
    std::cout << "=======================================" << std::endl;
    std::cout << " 测试汇总" << std::endl;
    std::cout << "=======================================" << std::endl;
    std::cout << " 总样本数 : " << N_TEST_SAMPLES << std::endl;
    std::cout << " PASS     : " << pass_count << std::endl;
    std::cout << " FAIL     : " << fail_count << std::endl;

    if (has_ref && !ref_outputs.empty()) {
        int n_compared = std::min(N_TEST_SAMPLES, (int)ref_outputs.size());
        double mean_err = (n_compared > 0) ? sum_err / n_compared : 0.0;
        printf(" 平均误差 : %.2f / 255\n", mean_err);
        printf(" 最大误差 : %d / 255\n", max_err);
        printf(" 误差率   : %.2f%%\n", 100.0 * max_err / 255.0);
    }
    std::cout << "=======================================" << std::endl;

    if (fail_count > 0) {
        std::cerr << "[TB] 有 " << fail_count << " 个样本未通过，请检查权重或量化参数。" << std::endl;
        return 1;   /* 非零返回值让 HLS 标记 csim 失败 */
    }

    std::cout << "[TB] 所有测试通过！" << std::endl;
    return 0;
}
