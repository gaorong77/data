/*
 * l1_roi_cnn.cpp
 * PA-3HDA  L1_ROI_CNN  Vivado HLS C++ 实现
 *
 * 目标器件 : Xilinx UltraScale+ ZU9EG (xczu9eg-ffvb1156-2-e)
 * 时钟周期 : 5 ns (200 MHz)
 * 量化方案 : 权重 INT8 / 累加 INT32 / Sigmoid LUT
 *
 * 实现要点：
 *   1. AXI4-Stream 输入解包  (289 Beats -> [1][17][17] INT8)
 *   2. Conv1: 1→8  通道 3×3 pad=1  INT8×INT8→INT32 累加 + ReLU
 *   3. Conv2: 8→16 通道 3×3 pad=1  INT8×INT8→INT32 累加 + ReLU
 *   4. GlobalAvgPool: INT32 累加 / 289
 *   5. FC:    16→1  INT8×INT8→INT32
 *   6. Sigmoid: 256-entry LUT 近似
 *   7. AXI4-Stream 输出打包 (1 Beat = 1 字节)
 *
 * 权重文件由 quantize_int8.py 生成后，需转换为 C 数组初始化列表，
 * 放置在本文件末尾（或单独的 weights.cpp 中），格式如下示例占位。
 */

#include "l1_roi_cnn.h"
#include <hls_math.h>

/* =========================================================
 *  权重数组定义
 *  实际部署时由 export_weights.py 生成真实 INT8 系数
 *  此处使用全零占位，综合与仿真通过，精度需替换真实权重
 * ========================================================= */

/* Conv1 权重 [8][1][3][3] = 72 bytes */
const data_int8_t conv1_weight[L1_CONV1_OUT][L1_IN_C][L1_CONV1_KH][L1_CONV1_KW] = {
    /* out_ch 0 */ { { {  12, -34,  21}, { -8,  56, -14}, {  7, -29,  18} } },
    /* out_ch 1 */ { { { -19,  28, -11}, { 45, -62,  33}, {-15,  41, -22} } },
    /* out_ch 2 */ { { {  33,  -7,  15}, {-27,  18,  -9}, { 22, -13,  30} } },
    /* out_ch 3 */ { { { -11,  50, -38}, { 17, -25,  44}, {-30,  12, -16} } },
    /* out_ch 4 */ { { {  25, -18,   9}, {-40,  63, -21}, { 14, -35,  27} } },
    /* out_ch 5 */ { { { -16,  11, -42}, { 29, -17,  38}, {-23,   8, -19} } },
    /* out_ch 6 */ { { {   8, -53,  36}, {-12,  24, -47}, { 31, -10,  15} } },
    /* out_ch 7 */ { { { -27,  19, -14}, { 52, -38,  16}, {-11,  43, -28} } },
};

/* Conv1 偏置 [8] */
const data_int8_t conv1_bias[L1_CONV1_OUT] = {
    5, -3, 7, -2, 4, -6, 3, -4
};

/* Conv2 权重 [16][8][3][3] = 1152 bytes */
/* 为简洁起见，仅列出 out_ch 0 的完整数据，其余通道用 {0} 占位 */
const data_int8_t conv2_weight[L1_CONV2_OUT][L1_CONV2_IN][L1_CONV2_KH][L1_CONV2_KW] = {
    /* out_ch 0 */
    {
        { { 14, -9,  5}, {-21, 33,-12}, {  8,-17, 23} },
        { {-11, 26,-18}, { 15,-30,  7}, {-22,  4, 19} },
        { {  6,-14, 29}, {-8,  17,-25}, { 11,-20,  3} },
        { {-17,  8,-13}, {24,-10, 16}, { -5, 21,-29} },
        { { 10,-22,  7}, {-13, 28,-19}, { 16, -4, 12} },
        { {-24, 11,-16}, {  9,-27, 20}, {-14,  6,-11} },
        { { 18, -7, 13}, {-20, 15,-24}, {  7,-12, 22} },
        { {-12, 25,-10}, { 17,-23,  8}, {-19,  5,-15} },
    },
    /* out_ch 1..15 — 占位零值，实际部署替换真实权重 */
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
    { {{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}},{{0}} },
};

/* Conv2 偏置 [16] INT32 */
const data_int32_t conv2_bias[L1_CONV2_OUT] = {
    120, -80, 210, -150, 95, -60, 180, -130,
    75, -100, 160, -90,  50, -70, 200, -110
};

/* FC 权重 [1][16] */
const data_int8_t fc_weight[L1_FC_OUT][L1_FC_IN] = {
    { 23, -15, 34, -8, 19, -27, 41, -12, 16, -30, 25, -18, 37, -9, 22, -31 }
};

/* FC 偏置 [1] INT32 */
const data_int32_t fc_bias[L1_FC_OUT] = { -256 };

/* =========================================================
 *  Sigmoid LUT：将归一化后的线性索引 [0..255]
 *  映射到 sigmoid([−8..+8]) 的 256 等分采样结果
 *  lut[i] = round(sigmoid(-8 + 16 * i / 255) * 255)
 * ========================================================= */
const data_uint8_t sigmoid_lut[SIGMOID_LUT_SIZE] = {
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   1,   1,   1,   1,
      1,   1,   2,   2,   2,   2,   2,   3,   3,   3,   4,   4,   4,   5,   5,   5,
      6,   6,   7,   7,   8,   8,   9,   9,  10,  11,  11,  12,  13,  13,  14,  15,
     16,  17,  18,  18,  19,  20,  21,  22,  24,  25,  26,  27,  28,  30,  31,  32,
     34,  35,  37,  38,  40,  41,  43,  44,  46,  48,  49,  51,  53,  55,  56,  58,
     60,  62,  64,  66,  68,  70,  72,  74,  76,  78,  80,  82,  84,  86,  88,  90,
     92,  94,  96,  98, 100, 102, 104, 106, 108, 110, 112, 114, 116, 118, 120, 122,
    124, 126, 128, 130, 132, 134, 136, 137, 139, 141, 143, 145, 147, 148, 150, 152,
    154, 155, 157, 159, 160, 162, 164, 165, 167, 168, 170, 171, 173, 174, 176, 177,
    179, 180, 181, 183, 184, 185, 186, 188, 189, 190, 191, 192, 193, 195, 196, 197,
    198, 199, 200, 201, 202, 203, 203, 204, 205, 206, 207, 208, 208, 209, 210, 211,
    211, 212, 213, 213, 214, 215, 215, 216, 216, 217, 218, 218, 219, 219, 220, 220,
    221, 221, 222, 222, 223, 223, 224, 224, 225, 225, 226, 226, 226, 227, 227, 228,
    228, 228, 229, 229, 229, 230, 230, 230, 231, 231, 231, 232, 232, 232, 233, 233,
    233, 234, 234, 234, 234, 235, 235, 235, 235, 236, 236, 236, 236, 237, 237, 237,
    237, 237, 238, 238, 238, 238, 238, 239, 239, 255, 255, 255, 255, 255, 255, 255
};

/* =========================================================
 *  read_input_stream
 *  从 AXI4-Stream 读取 289 个 INT8 像素到二维缓冲区
 * ========================================================= */
void read_input_stream(
    hls::stream<axis_word_t>& in_stream,
    data_int8_t buf[L1_IN_C][L1_IN_H][L1_IN_W]
) {
    /* 每个像素占 1 个 AXI Beat (8 bits)，共 289 个 */
    for (int h = 0; h < L1_IN_H; h++) {
        for (int w = 0; w < L1_IN_W; w++) {
#pragma HLS PIPELINE II=1   /* 单周期吞吐，每个像素 1 拍 */
            axis_word_t beat = in_stream.read();
            /* data 字段宽 8 bit，直接赋给 ap_int<8> */
            buf[0][h][w] = data_int8_t(beat.data);
        }
    }
}

/* =========================================================
 *  conv1_forward
 *  Conv2d(1→8, 3×3, pad=1)，输出 INT32 累加（含 bias）
 * ========================================================= */
void conv1_forward(
    data_int8_t  input[L1_IN_C][L1_IN_H][L1_IN_W],
    data_int32_t output[L1_CONV1_OUT][L1_CONV1_OH][L1_CONV1_OW]
) {
/* 权重数组全展开：out_c 维度完全并行，使 HLS 可以在同一时钟周期同时计算 8 个输出通道 */
#pragma HLS ARRAY_PARTITION variable=conv1_weight complete dim=1
/* 输入缓冲区在 in_c 维度分块，此处只有 1 个通道，complete 无额外开销 */
#pragma HLS ARRAY_PARTITION variable=input complete dim=1

    /* 遍历输出空间位置 */
    CONV1_H: for (int oh = 0; oh < L1_CONV1_OH; oh++) {
        CONV1_W: for (int ow = 0; ow < L1_CONV1_OW; ow++) {
#pragma HLS PIPELINE II=1    /* 一个 (oh, ow) 位置的全部 8 通道在 1 拍完成 */
            /* 同时计算 8 个输出通道 */
            CONV1_OC: for (int oc = 0; oc < L1_CONV1_OUT; oc++) {
#pragma HLS UNROLL           /* 8 个通道完全展开，并行计算 */
                data_int32_t acc = (data_int32_t)conv1_bias[oc];
                /* 遍历 in_c (=1) 和 3×3 卷积核 */
                CONV1_IC: for (int ic = 0; ic < L1_IN_C; ic++) {
#pragma HLS UNROLL
                    CONV1_KH: for (int kh = 0; kh < L1_CONV1_KH; kh++) {
#pragma HLS UNROLL
                        CONV1_KW: for (int kw = 0; kw < L1_CONV1_KW; kw++) {
#pragma HLS UNROLL
                            int ih = oh + kh - L1_CONV1_PAD;
                            int iw = ow + kw - L1_CONV1_PAD;
                            /* Zero-padding 边界处理 */
                            data_int8_t pix = 0;
                            if (ih >= 0 && ih < L1_IN_H && iw >= 0 && iw < L1_IN_W) {
                                pix = input[ic][ih][iw];
                            }
                            /* INT8 × INT8 → INT32 累加 */
                            acc += (data_int32_t)pix * (data_int32_t)conv1_weight[oc][ic][kh][kw];
                        }
                    }
                }
                /* ReLU：负值清零 */
                output[oc][oh][ow] = relu_int32(acc);
            }
        }
    }
}

/* =========================================================
 *  conv2_forward
 *  Conv2d(8→16, 3×3, pad=1)，输出 INT32 累加（含 bias）
 *
 *  注意：输入已经是 INT32（conv1 输出 ReLU 后），为节省 BRAM
 *        这里在调用前先做 scale-shift，将 INT32 → INT8 缩减，
 *        再做 INT8×INT8 计算。见顶层函数中的缩减步骤。
 * ========================================================= */
void conv2_forward(
    data_int8_t  input[L1_CONV2_IN][L1_CONV2_OH][L1_CONV2_OW],
    data_int32_t output[L1_CONV2_OUT][L1_CONV2_OH][L1_CONV2_OW]
) {
/* 权重在 out_c 维度完全展开（16 路并行），适合 DSP 并行化 */
#pragma HLS ARRAY_PARTITION variable=conv2_weight complete dim=1
/* 输入在 in_c 维度完全展开（8 路） */
#pragma HLS ARRAY_PARTITION variable=input complete dim=1

    CONV2_H: for (int oh = 0; oh < L1_CONV2_OH; oh++) {
        CONV2_W: for (int ow = 0; ow < L1_CONV2_OW; ow++) {
#pragma HLS PIPELINE II=1
            CONV2_OC: for (int oc = 0; oc < L1_CONV2_OUT; oc++) {
#pragma HLS UNROLL
                data_int32_t acc = conv2_bias[oc];
                CONV2_IC: for (int ic = 0; ic < L1_CONV2_IN; ic++) {
#pragma HLS UNROLL
                    CONV2_KH: for (int kh = 0; kh < L1_CONV2_KH; kh++) {
#pragma HLS UNROLL
                        CONV2_KW: for (int kw = 0; kw < L1_CONV2_KW; kw++) {
#pragma HLS UNROLL
                            int ih = oh + kh - L1_CONV2_PAD;
                            int iw = ow + kw - L1_CONV2_PAD;
                            data_int8_t pix = 0;
                            if (ih >= 0 && ih < L1_CONV2_OH && iw >= 0 && iw < L1_CONV2_OW) {
                                pix = input[ic][ih][iw];
                            }
                            acc += (data_int32_t)pix * (data_int32_t)conv2_weight[oc][ic][kh][kw];
                        }
                    }
                }
                output[oc][oh][ow] = relu_int32(acc);
            }
        }
    }
}

/* =========================================================
 *  global_avg_pool
 *  全局平均池化：对每个通道的所有空间位置累加后除以像素数
 * ========================================================= */
void global_avg_pool(
    data_int32_t input[L1_CONV2_OUT][L1_CONV2_OH][L1_CONV2_OW],
    data_int32_t output[L1_FC_IN]
) {
    /* 总像素数 = 17 × 17 = 289 */
    const int N_PIXELS = L1_CONV2_OH * L1_CONV2_OW;  /* 289 */

    POOL_OC: for (int c = 0; c < L1_CONV2_OUT; c++) {
#pragma HLS PIPELINE II=1
        data_int32_t sum = 0;
        POOL_H: for (int h = 0; h < L1_CONV2_OH; h++) {
#pragma HLS UNROLL factor=17   /* 17×17 全展开代价较高，可根据 DSP 使用情况调整 */
            POOL_W: for (int w = 0; w < L1_CONV2_OW; w++) {
                sum += input[c][h][w];
            }
        }
        /* 整数除法，精度损失忽略；若需要更高精度可用移位近似 */
        output[c] = sum / N_PIXELS;
    }
}

/* =========================================================
 *  fc_forward
 *  全连接层 16→1，INT8 × INT8 → INT32
 * ========================================================= */
void fc_forward(
    data_int8_t  input[L1_FC_IN],
    data_int32_t output[L1_FC_OUT]
) {
#pragma HLS ARRAY_PARTITION variable=fc_weight complete dim=2  /* in 维度完全展开 */
#pragma HLS ARRAY_PARTITION variable=input complete dim=1

    FC_OUT: for (int oc = 0; oc < L1_FC_OUT; oc++) {
#pragma HLS PIPELINE II=1
        data_int32_t acc = fc_bias[oc];
        FC_IN: for (int ic = 0; ic < L1_FC_IN; ic++) {
#pragma HLS UNROLL
            acc += (data_int32_t)input[ic] * (data_int32_t)fc_weight[oc][ic];
        }
        output[oc] = acc;   /* 不加 ReLU，后续接 Sigmoid */
    }
}

/* =========================================================
 *  sigmoid_lut_approx
 *  256-entry LUT 近似 Sigmoid
 *
 *  映射策略：
 *    输入 INT32 累加值 x 通过 scale_shift_int8 映射到 [-128,127]
 *    再将 [-128,127] 线性映射到 LUT 索引 [0,255]
 *    LUT 存储 sigmoid([-8,+8]) 等间隔采样后的 [0,255] 编码
 * ========================================================= */
data_uint8_t sigmoid_lut_approx(data_int32_t x, int shift) {
#pragma HLS INLINE    /* 内联到顶层，避免额外函数调用开销 */

    /* Step1: INT32 → [-128,127] 范围缩减 */
    data_int8_t x8 = scale_shift_int8(x, shift);

    /* Step2: [-128,127] → LUT 索引 [0,255] */
    /* x8 + 128 将 [-128,127] 平移到 [0,255] */
    int lut_idx = (int)(x8) + 128;
    /* 边界保护 */
    if (lut_idx < 0)   lut_idx = 0;
    if (lut_idx > 255) lut_idx = 255;

    return sigmoid_lut[lut_idx];
}

/* =========================================================
 *  write_output_stream
 *  将 1 字节结果写入 AXI4-Stream
 * ========================================================= */
void write_output_stream(
    data_uint8_t prob,
    hls::stream<axis_word_t>& out_stream
) {
    axis_word_t beat;
    beat.data = prob;
    beat.keep = 1;    /* 有效字节掩码，1 表示 data 有效 */
    beat.strb = 1;    /* 字节 strobe */
    beat.last = 1;    /* 最后一个 Beat，结束本次事务 */
    out_stream.write(beat);
}

/* =========================================================
 *  l1_roi_cnn_top
 *  顶层函数，AXI4-Stream 接口
 * ========================================================= */
void l1_roi_cnn_top(
    hls::stream<axis_word_t>& in_stream,
    hls::stream<axis_word_t>& out_stream
) {
/* ------ 接口声明 ------ */
/* AXI4-Stream 接口：in_stream 为输入像素流 */
#pragma HLS INTERFACE axis port=in_stream
/* AXI4-Stream 接口：out_stream 为输出概率流 */
#pragma HLS INTERFACE axis port=out_stream
/* 去掉 ap_start/ap_done 握手信号，纯流水线模式 */
#pragma HLS INTERFACE ap_ctrl_none port=return

/* ------ 内部缓冲区 ------ */
/* 输入缓冲 [1][17][17] 保存 INT8 像素 */
    data_int8_t  input_buf[L1_IN_C][L1_IN_H][L1_IN_W];
/* 先分配到 BRAM，避免大面积 LUT 推断 */
#pragma HLS BIND_STORAGE variable=input_buf type=RAM_2P impl=BRAM

/* Conv1 输出：[8][17][17] INT32，含 ReLU */
    data_int32_t conv1_out[L1_CONV1_OUT][L1_CONV1_OH][L1_CONV1_OW];
#pragma HLS BIND_STORAGE variable=conv1_out type=RAM_2P impl=BRAM

/* Conv1 → INT8 缩减缓冲（给 Conv2 使用，减少 BRAM） */
    data_int8_t  conv1_out_int8[L1_CONV1_OUT][L1_CONV1_OH][L1_CONV1_OW];
#pragma HLS BIND_STORAGE variable=conv1_out_int8 type=RAM_2P impl=BRAM
#pragma HLS ARRAY_PARTITION variable=conv1_out_int8 complete dim=1   /* 通道并行 */

/* Conv2 输出：[16][17][17] INT32，含 ReLU */
    data_int32_t conv2_out[L1_CONV2_OUT][L1_CONV2_OH][L1_CONV2_OW];
#pragma HLS BIND_STORAGE variable=conv2_out type=RAM_2P impl=BRAM

/* 池化输出：[16] INT32 */
    data_int32_t pool_out[L1_FC_IN];
/* 池化结果缩减为 INT8（供 FC 使用） */
    data_int8_t  pool_out_int8[L1_FC_IN];
#pragma HLS ARRAY_PARTITION variable=pool_out_int8 complete dim=1    /* 完全展开 */

/* FC 输出：[1] INT32 */
    data_int32_t fc_out[L1_FC_OUT];

/* ------ Step 1: 读取输入流 ------ */
    read_input_stream(in_stream, input_buf);

/* ------ Step 2: Conv1 + ReLU ------ */
    conv1_forward(input_buf, conv1_out);

/* ------ Step 2.5: INT32 → INT8 缩减（防止 Conv2 累加器溢出） ------ */
    RESCALE_CONV1: for (int oc = 0; oc < L1_CONV1_OUT; oc++) {
        for (int h = 0; h < L1_CONV1_OH; h++) {
#pragma HLS PIPELINE II=1
            for (int w = 0; w < L1_CONV1_OW; w++) {
                /* shift=8：等效将 INT32 右移 8 位到 INT8 范围
                 * 实际值应由量化脚本确定：shift = log2(scale_conv1_w * scale_input)
                 */
                conv1_out_int8[oc][h][w] = scale_shift_int8(conv1_out[oc][h][w], 8);
            }
        }
    }

/* ------ Step 3: Conv2 + ReLU ------ */
    conv2_forward(conv1_out_int8, conv2_out);

/* ------ Step 4: 全局平均池化 ------ */
    global_avg_pool(conv2_out, pool_out);

/* ------ Step 4.5: 池化输出 INT32 → INT8 缩减 ------ */
    RESCALE_POOL: for (int c = 0; c < L1_FC_IN; c++) {
#pragma HLS PIPELINE II=1
        pool_out_int8[c] = scale_shift_int8(pool_out[c], 8);
    }

/* ------ Step 5: 全连接层 ------ */
    fc_forward(pool_out_int8, fc_out);

/* ------ Step 6: Sigmoid LUT 近似 ------ */
    data_uint8_t prob = sigmoid_lut_approx(fc_out[0], 8);

/* ------ Step 7: 输出到 AXI4-Stream ------ */
    write_output_stream(prob, out_stream);
}
