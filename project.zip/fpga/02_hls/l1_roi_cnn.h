/*
 * l1_roi_cnn.h
 * PA-3HDA  L1_ROI_CNN  Vivado HLS 头文件
 *
 * 目标器件 : Xilinx UltraScale+ ZU9EG (xczu9eg-ffvb1156-2-e)
 * 时钟周期 : 5 ns (200 MHz)
 * 量化精度 : INT8 (权重) / INT32 (累加器) / Sigmoid 近似输出
 * 接口类型 : AXI4-Stream (ap_axiu<8,0,0,0>)
 *
 * 网络结构:
 *   输入   : (1, 17, 17) INT8 像素流
 *   Conv1  : 1→8  通道, 3×3, pad=1, INT8×INT8→INT32
 *   ReLU   : INT32 正值保留
 *   Conv2  : 8→16 通道, 3×3, pad=1, INT8×INT8→INT32
 *   ReLU   : INT32 正值保留
 *   AvgPool: 全局平均池化 (INT32 累加 / 像素数)
 *   FC     : 16→1, INT8×INT8→INT32
 *   Sigmoid: 查找表近似 (256-entry LUT)
 *   输出   : 1 字节概率 [0..255] -> float 0.0~1.0
 */

#ifndef L1_ROI_CNN_H
#define L1_ROI_CNN_H

#include <ap_int.h>
#include <ap_fixed.h>
#include <hls_stream.h>
#include <ap_axi_sdata.h>

/* =========================================================
 *  基本数据类型定义
 * ========================================================= */

/* INT8：存储量化权重与量化输入 */
typedef ap_int<8>    data_int8_t;

/* UINT8：存储无符号量化数据（ReLU 后激活值范围 [0,127]，用 uint8 存） */
typedef ap_uint<8>   data_uint8_t;

/* INT32：卷积累加寄存器 */
typedef ap_int<32>   data_int32_t;

/* INT16：中间缩减后的中等精度值 */
typedef ap_int<16>   data_int16_t;

/* 定点输出：16位总位宽，8位整数位，8位小数位 */
typedef ap_fixed<16, 8> data_fixed_t;

/* AXI4-Stream 数据单元：8-bit 宽，无用户位/目标位/最后位 */
typedef ap_axiu<8, 0, 0, 0> axis_word_t;

/* =========================================================
 *  网络参数 —— 编译时常量
 * ========================================================= */

/* 输入特征图尺寸（L1 / L2 使用 17×17；L1-Wide 使用 51×51 —— 需换头文件） */
#define L1_IN_H         17
#define L1_IN_W         17
#define L1_IN_C         1         /* 输入通道数 */

/* Conv1 参数 */
#define L1_CONV1_KH     3
#define L1_CONV1_KW     3
#define L1_CONV1_PAD    1
#define L1_CONV1_OUT    8         /* 输出通道数 */
#define L1_CONV1_OH     (L1_IN_H)   /* 因为 pad=1，输出与输入等尺寸 */
#define L1_CONV1_OW     (L1_IN_W)

/* Conv2 参数 */
#define L1_CONV2_KH     3
#define L1_CONV2_KW     3
#define L1_CONV2_PAD    1
#define L1_CONV2_IN     L1_CONV1_OUT    /* = 8 */
#define L1_CONV2_OUT    16
#define L1_CONV2_OH     (L1_CONV1_OH)
#define L1_CONV2_OW     (L1_CONV1_OW)

/* 全局平均池化输出尺寸（1×1） */
#define L1_POOL_OUT_H   1
#define L1_POOL_OUT_W   1

/* 全连接层参数 */
#define L1_FC_IN        L1_CONV2_OUT    /* = 16 */
#define L1_FC_OUT       1

/* 总像素数 */
#define L1_TOTAL_PIXELS (L1_IN_H * L1_IN_W)      /* 289 */
#define L1_CONV1_TOTAL  (L1_CONV1_OH * L1_CONV1_OW)  /* 289 */

/* Sigmoid LUT 大小 */
#define SIGMOID_LUT_SIZE 256

/* =========================================================
 *  权重数组声明
 *  均放在 ROM 中（const），编译器会自动推断；
 *  可以配合 #pragma HLS RESOURCE variable=xxx core=ROM_2P_BRAM 指定存储类型
 * ========================================================= */

/* Conv1 权重: [out_c][in_c][kh][kw] = [8][1][3][3] */
extern const data_int8_t conv1_weight[L1_CONV1_OUT][L1_IN_C][L1_CONV1_KH][L1_CONV1_KW];

/* Conv1 偏置: [out_c] = [8] */
extern const data_int8_t conv1_bias[L1_CONV1_OUT];

/* Conv2 权重: [out_c][in_c][kh][kw] = [16][8][3][3] */
extern const data_int8_t conv2_weight[L1_CONV2_OUT][L1_CONV2_IN][L1_CONV2_KH][L1_CONV2_KW];

/* Conv2 偏置: INT32，用于与累加结果直接相加 */
extern const data_int32_t conv2_bias[L1_CONV2_OUT];

/* FC 权重: [out][in] = [1][16] */
extern const data_int8_t fc_weight[L1_FC_OUT][L1_FC_IN];

/* FC 偏置: INT32 */
extern const data_int32_t fc_bias[L1_FC_OUT];

/* Sigmoid 近似 LUT：将 INT32 输出映射到 [0,255] */
extern const data_uint8_t sigmoid_lut[SIGMOID_LUT_SIZE];

/* =========================================================
 *  中间缓冲区类型声明（在 .cpp 中局部定义，这里声明尺寸供注释参考）
 *
 *  input_buf    : [L1_IN_C][L1_IN_H][L1_IN_W]    = [1][17][17]
 *  conv1_out    : [L1_CONV1_OUT][L1_CONV1_OH][L1_CONV1_OW] = [8][17][17]
 *  conv2_out    : [L1_CONV2_OUT][L1_CONV2_OH][L1_CONV2_OW] = [16][17][17]
 *  pool_out     : [L1_CONV2_OUT]                  = [16]
 *  fc_out       : [L1_FC_OUT]                     = [1]
 * ========================================================= */

/* =========================================================
 *  辅助内联函数
 * ========================================================= */

/**
 * relu_int32 - INT32 ReLU（等效于 max(x, 0)）
 * @param x 输入 INT32 值
 * @return  max(x, 0) 以 INT32 返回
 */
inline data_int32_t relu_int32(data_int32_t x) {
#pragma HLS INLINE
    return (x > 0) ? x : data_int32_t(0);
}

/**
 * scale_shift_int8 - 将 INT32 累加结果右移缩放到 INT8 范围
 * @param acc    INT32 累加值
 * @param shift  右移位数（根据量化 scale 确定）
 * @return       INT8 缩放结果，clip 到 [-128, 127]
 *
 * 注意：实际 shift 值由量化脚本的 scale 因子推导：
 *   shift = round(log2(scale_in * scale_w / scale_out))
 */
inline data_int8_t scale_shift_int8(data_int32_t acc, int shift = 8) {
#pragma HLS INLINE
    data_int32_t shifted = acc >> shift;
    if (shifted > 127)  return data_int8_t(127);
    if (shifted < -128) return data_int8_t(-128);
    return data_int8_t(shifted);
}

/* =========================================================
 *  顶层函数声明
 *
 *  接口：
 *    in_stream   AXI4-Stream 输入，每 Beat 1 字节 INT8 像素
 *                共 L1_IN_H × L1_IN_W = 289 Beats，行优先排列
 *    out_stream  AXI4-Stream 输出，1 Beat = 1 字节概率 [0..255]
 *
 *  综合指令：
 *    INTERFACE axis      — 暴露为 AXI4-Stream 端口，由 HLS 自动生成握手
 *    INTERFACE ap_ctrl_none — 去掉 ap_start/ap_done 控制信号（纯流接口）
 * ========================================================= */
void l1_roi_cnn_top(
    hls::stream<axis_word_t>& in_stream,
    hls::stream<axis_word_t>& out_stream
);

/* =========================================================
 *  子函数声明（在 .cpp 中实现）
 * ========================================================= */

/**
 * read_input_stream - 从 AXI4-Stream 读取像素到内部缓冲区
 * @param in_stream  输入流
 * @param buf        输出：[1][17][17] INT8 缓冲区
 */
void read_input_stream(
    hls::stream<axis_word_t>& in_stream,
    data_int8_t buf[L1_IN_C][L1_IN_H][L1_IN_W]
);

/**
 * conv2d_int8 - INT8 卷积（含 padding 和 bias）
 * @param input    输入特征图 [in_c][ih][iw]
 * @param weight   卷积核 [out_c][in_c][kh][kw]
 * @param bias     偏置（INT32）[out_c]
 * @param output   输出特征图 [out_c][oh][ow]（INT32 累加）
 * @param IN_C     输入通道数
 * @param OUT_C    输出通道数
 * @param IH/IW    输入尺寸
 * @param KH/KW    卷积核尺寸
 * @param PAD      padding
 */
void conv1_forward(
    data_int8_t  input[L1_IN_C][L1_IN_H][L1_IN_W],
    data_int32_t output[L1_CONV1_OUT][L1_CONV1_OH][L1_CONV1_OW]
);

void conv2_forward(
    data_int8_t  input[L1_CONV1_OUT][L1_CONV1_OH][L1_CONV1_OW],
    data_int32_t output[L1_CONV2_OUT][L1_CONV2_OH][L1_CONV2_OW]
);

/**
 * global_avg_pool - 全局平均池化
 * @param input   输入 [C][H][W] INT32
 * @param output  输出 [C] INT32
 */
void global_avg_pool(
    data_int32_t input[L1_CONV2_OUT][L1_CONV2_OH][L1_CONV2_OW],
    data_int32_t output[L1_FC_IN]
);

/**
 * fc_forward - 全连接层
 * @param input   输入向量 [16] INT8
 * @param output  输出 [1] INT32
 */
void fc_forward(
    data_int8_t  input[L1_FC_IN],
    data_int32_t output[L1_FC_OUT]
);

/**
 * sigmoid_lut_approx - Sigmoid 查找表近似
 * @param x       INT32 累加结果
 * @param shift   定标右移位数
 * @return        [0..255] 量化概率
 */
data_uint8_t sigmoid_lut_approx(data_int32_t x, int shift = 8);

/**
 * write_output_stream - 将结果写入 AXI4-Stream
 * @param prob       量化概率 [0..255]
 * @param out_stream 输出流
 */
void write_output_stream(
    data_uint8_t prob,
    hls::stream<axis_word_t>& out_stream
);

#endif /* L1_ROI_CNN_H */
