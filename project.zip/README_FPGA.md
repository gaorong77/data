# PA-3HDA 神经网络 FPGA 部署全流程文档

## 1. 流程总览

```text
PyTorch (.pth)
     ↓ export_onnx.py
ONNX (.onnx)
     ↓ quantize_int8.py
INT8 权重 (.npy) + 量化参数
     ↓ HLS C++ 实现
RTL (Verilog/VHDL)
     ↓ Vivado 综合+实现
比特流 (.bit)
     ↓ PYNQ/部署
实时推理
```

## 2. 项目目标

本文档描述 PA-3HDA 系统中 `L1 / L1-Wide / L2` 三个模型在 **Xilinx UltraScale+ ZU9EG** FPGA 上的完整部署流程。三者核心网络结构相同，均基于 `L1_ROI_CNN`：

- `Conv2d(1→8, 3×3, pad=1)`
- `ReLU`
- `Conv2d(8→16, 3×3, pad=1)`
- `ReLU`
- `AdaptiveAvgPool2d(1)`
- `Linear(16→1)`
- `Sigmoid`

其中：
- `L1 / L2` 输入尺寸：`(1, 1, 17, 17)`
- `L1-Wide` 输入尺寸：`(1, 1, 51, 51)`
- 输出尺寸统一为：`(1, 1)`
- 推理接口：**AXI4-Stream**
- 量化方式：**INT8 Post-Training Quantization (PTQ)**

## 3. 目录结构

```text
PA3HDA_v4/fpga/
├── README_FPGA.md
├── 01_export/
│   ├── export_onnx.py
│   ├── quantize_int8.py
│   └── onnx/
├── 02_hls/
│   ├── l1_roi_cnn.h
│   ├── l1_roi_cnn.cpp
│   ├── l1_roi_cnn_tb.cpp
│   └── weights/
├── 03_vivado/
│   ├── create_project.tcl
│   └── synth_impl.tcl
├── 04_deploy/
│   ├── pynq_inference.py
│   └── axi_stream_driver.py
└── run_fpga_flow.py
```

## 4. 环境依赖

### 4.1 FPGA 工具链

建议版本：

- **Vivado 2023.2** 或兼容版本
- **Vitis HLS 2023.2** 或兼容版本
- 目标器件：`xczu9eg-ffvb1156-2-e`
- 默认时钟：`200 MHz`（`5 ns`）

### 4.2 Python 依赖

建议 Python 3.10+，安装以下包：

```bash
pip install torch torchvision onnx onnxruntime numpy scipy
```

可选安装：

```bash
pip install hls4ml
```

说明：
- 本项目默认提供手写 HLS C++ 实现，不依赖 hls4ml。
- 若后续需要自动网络转换或做结构探索，可以使用 hls4ml 做辅助验证。

## 5. 模型信息与部署约束

### 5.1 模型参数量

每个模型参数量约为 **1,265**，拆分如下：

- Conv1：`8 × 1 × 3 × 3 + 8 = 80`
- Conv2：`16 × 8 × 3 × 3 + 16 = 1,168`
- FC：`1 × 16 + 1 = 17`
- 合计：`80 + 1,168 + 17 = 1,265`

### 5.2 FPGA 资源预估

以下为保守估算，实际结果以 HLS 综合与 Vivado 实现报告为准。

| 模型 | 输入尺寸 | 估计 DSP | DSP 占比 | 估计 BRAM18 | BRAM18 占比 | 估计 LUT | LUT 占比 |
|---|---:|---:|---:|---:|---:|---:|---:|
| L1 | 17×17 | 64 | 2.54% | 12 | 1.11% | 12000 | 2.30% |
| L1-Wide | 51×51 | 64 | 2.54% | 20 | 1.85% | 15000 | 2.87% |
| L2 | 17×17 | 64 | 2.54% | 12 | 1.11% | 12000 | 2.30% |

目标 FPGA 总资源：
- DSP：2520
- BRAM18：1080
- LUT：522720

说明：
- 三个模型结构一致，主要资源差异来自输入缓存和中间特征图缓存大小。
- 若采用更激进的并行展开，DSP/LUT 可能进一步上升。
- 若采用时分复用方案，可进一步降低资源占用，但吞吐率会下降。

## 6. 各步骤详细说明

---

### Step 1：PyTorch 模型导出 ONNX

脚本：`01_export/export_onnx.py`

#### 输入
- 训练完成的 `.pth` checkpoint
- `models/l1_roi_cnn.py` 中的 `L1_ROI_CNN` 模型定义

#### 输出
- `fpga/01_export/onnx/l1.onnx`
- `fpga/01_export/onnx/l1_wide.onnx`
- `fpga/01_export/onnx/l2.onnx`

#### 示例命令

```bash
python fpga/01_export/export_onnx.py --model l1 --checkpoint checkpoints/l1_best.pth
python fpga/01_export/export_onnx.py --model l1_wide --checkpoint checkpoints/l1_wide_best.pth
python fpga/01_export/export_onnx.py --model l2 --checkpoint checkpoints/l2_best.pth
python fpga/01_export/export_onnx.py --all
```

#### 关键功能
- 自动根据模型名称选择输入尺寸：
  - `l1 / l2 -> 17×17`
  - `l1_wide -> 51×51`
- 导出 ONNX，`opset=11`
- 使用 `onnxruntime` 校验 ONNX 推理输出与 PyTorch 输出一致
- 误差要求：`max_abs_error < 1e-5`
- 输出模型结构摘要、层数、参数量、输入输出形状

#### 注意事项
- 若 checkpoint 中包含 `module.` 前缀，脚本会自动剥离。
- 若模型定义路径与项目实际不一致，需要调整 `sys.path` 或导入路径。

---

### Step 2：INT8 PTQ 量化与权重提取

脚本：`01_export/quantize_int8.py`

#### 输入
- PyTorch checkpoint
- 可选校准数据（用于统计激活范围）

#### 输出
保存在 `fpga/02_hls/weights/`：

- `l1_conv1_weight_int8.npy`
- `l1_conv1_bias_int8.npy`
- `l1_conv2_weight_int8.npy`
- `l1_conv2_bias_int32.npy`
- `l1_fc_weight_int8.npy`
- `l1_fc_bias_int32.npy`
- `l1_scales.json`

#### 示例命令

```bash
python fpga/01_export/quantize_int8.py --model l1
python fpga/01_export/quantize_int8.py --all
```

#### 量化方法

对每一层权重：

```text
scale = max(|W|) / 127
W_int8 = round(W / scale).clip(-128, 127)
```

偏置处理：
- 第一层偏置可存为 `INT8` 或重新缩放后存储；本项目按需求输出 `conv1_bias_int8.npy`
- 后续卷积与全连接偏置使用 `INT32`，适配累加路径

激活量化：
- 使用校准数据或随机样本前向统计激活范围
- 将每层输入/输出激活 scale 保存到 `scales.json`

#### 精度对比
脚本会打印：
- 浮点模型输出
- 量化模拟输出
- 最大绝对误差
- 平均绝对误差

#### 注意事项
- 若没有真实校准集，可使用与训练分布一致的 ROI 随机切块作为近似校准输入。
- 校准数据分布应尽量覆盖实际部署场景，否则量化精度会下降。

---

### Step 3：HLS C++ 实现

文件：
- `02_hls/l1_roi_cnn.h`
- `02_hls/l1_roi_cnn.cpp`
- `02_hls/l1_roi_cnn_tb.cpp`

#### 输入
- INT8 量化权重 `.npy` 对应生成的权重数组
- AXI4-Stream 输入图像流

#### 输出
- HLS 综合生成的 RTL
- IP Catalog 可导入 IP

#### 网络计算流程
1. 从 AXI4-Stream 读取 `17×17=289` 个 INT8 输入像素
2. 第一层卷积：`1→8`，`3×3`，pad=1
3. ReLU
4. 第二层卷积：`8→16`，`3×3`，pad=1
5. 全局平均池化
6. 全连接 `16→1`
7. Sigmoid LUT 近似
8. 输出 1 字节定点概率

#### HLS 实现要点
- 使用 `#pragma HLS INTERFACE axis` 暴露流接口
- 使用 `#pragma HLS PIPELINE II=1` 提升吞吐
- 对权重数组采用 `ARRAY_PARTITION` 优化并行访问
- Sigmoid 用 `256` 项 LUT 近似，平衡面积与精度
- 采用定点/整数路径减少 DSP 与逻辑开销

#### Testbench
- 自动产生随机输入
- 从 `.npy` 或文本参考结果文件读取参考输出
- 打印误差统计

#### 注意事项
- HLS C 仿真环境通常不直接解析 `.npy`，如需直接运行 testbench，可先将 `.npy` 转为 `.txt`/`.bin`
- 当前代码提供了 `std::ifstream` 文本读取接口，可作为 Python 预处理后的配套格式

---

### Step 4：Vitis HLS 综合

脚本：`03_vivado/create_project.tcl`

#### 主要动作
- 创建 HLS 项目
- 设置顶层函数 `l1_roi_cnn_top`
- 添加设计文件与 testbench
- 设定器件为 `xczu9eg-ffvb1156-2-e`
- 创建 `5ns` 时钟
- 运行：
  - `csim_design`
  - `csynth_design`
  - `export_design -format ip_catalog`

#### 示例命令

```bash
vitis_hls -f fpga/03_vivado/create_project.tcl
```

#### 输出
- HLS 工程目录
- C 仿真结果
- 综合报告
- IP Catalog 导出结果

---

### Step 5：Vivado 综合、实现与比特流生成

脚本：`03_vivado/synth_impl.tcl`

#### 主要动作
- 创建 Vivado 工程
- 添加 Zynq MPSoC PS
- 添加 HLS 生成的 IP 核
- 添加 AXI DMA
- 连接 AXI4-Lite / AXI Memory Mapped / AXI4-Stream
- 运行综合、实现
- 导出 `.bit` 和 `.hwh`
- 生成资源利用率报告

#### 示例命令

```bash
vivado -mode batch -source fpga/03_vivado/synth_impl.tcl
```

#### 输出
- `*.bit`
- `*.hwh`
- `utilization.rpt`
- `timing_summary.rpt`

#### 注意事项
- 若用于 PYNQ，建议同时保留 `.bit + .hwh`
- PS 端 DDR 地址、中断和 DMA 参数需结合实际板卡约束调整

---

### Step 6：PYNQ / 部署侧推理

文件：
- `04_deploy/pynq_inference.py`
- `04_deploy/axi_stream_driver.py`

#### 功能
- 在 PYNQ 板上加载比特流
- 使用 DMA 发送量化后的 ROI 图像到 PL
- 接收 PL 返回的 1 字节概率结果
- 反量化为浮点概率值
- 支持批量推理和时延统计

#### PYNQ 示例

```python
from fpga.deploy.pynq_inference import L1FPGAInference

inf = L1FPGAInference('l1_roi_cnn.bit')
prob = inf.infer(roi_image)
print(prob)
```

#### 注意事项
- 输入图像应与训练前处理一致
- 必须使用与量化脚本一致的输入 scale
- 若使用不同板卡或不同 overlay 命名，需要修改 IP 和 DMA 名称

## 7. 一键运行说明

主脚本：`run_fpga_flow.py`

### 7.1 完整流程

```bash
python fpga/run_fpga_flow.py --model l1 --checkpoint checkpoints/l1_best.pth
```

### 7.2 仅导出和量化

```bash
python fpga/run_fpga_flow.py --model l1 --checkpoint checkpoints/l1_best.pth --export-only
```

### 7.3 检查环境

```bash
python fpga/run_fpga_flow.py --check-env
```

### 7.4 断点续跑

```bash
python fpga/run_fpga_flow.py --model l1 --checkpoint checkpoints/l1_best.pth --resume
```

## 8. 推荐完整执行顺序

```bash
# 1) 环境检查
python fpga/run_fpga_flow.py --check-env

# 2) 导出 ONNX
python fpga/01_export/export_onnx.py --model l1 --checkpoint checkpoints/l1_best.pth

# 3) INT8 量化
python fpga/01_export/quantize_int8.py --model l1 --checkpoint checkpoints/l1_best.pth

# 4) HLS 仿真与综合
vitis_hls -f fpga/03_vivado/create_project.tcl

# 5) Vivado 工程综合实现
vivado -mode batch -source fpga/03_vivado/synth_impl.tcl
```

## 9. 工程建议

1. **先以 L1 (17×17) 跑通全流程**，确认 HLS、Vivado、PYNQ 一致性。  
2. **L1-Wide 使用相同架构扩展输入缓存**，优先验证中间特征图 BRAM 增量。  
3. **如果时序压力过大**，优先从以下方向优化：
   - 降低并行度
   - 增加流水级
   - 使用更严格的资源绑定策略
   - 对第二层卷积做部分展开而非完全展开
4. **如果精度下降明显**：
   - 增大校准样本数
   - 对激活 scale 使用更稳健统计方式（如 percentile）
   - 考虑 sigmoid 输出保留更高精度定点格式

## 10. 文件说明补充

### 权重生成链路
实际部署时建议增加一个辅助脚本，例如：
- `export_weights.py`

它负责把 `.npy` 再转成 HLS 头文件数组，或者生成 `.dat/.txt` 供 testbench 与 C 仿真读取。

### 多模型支持建议
当前 HLS 示例主实现以 `L1 17×17` 为基础。若要同时支持 `L1-Wide / L2`：
- 可以采用编译期宏切换输入尺寸
- 或者维护三份权重+三份顶层配置
- 或者做统一大输入版，17×17 输入时对中心区域写入、其余补零

## 11. 总结

本目录提供了从 **PyTorch 模型导出 → INT8 量化 → HLS 实现 → Vivado 生成 IP/比特流 → PYNQ 部署** 的完整参考流程。对于 PA-3HDA 中参数规模很小的 `L1_ROI_CNN`，该方案在 ZU9EG 上具有非常充足的资源余量，适合低时延实时推理场景。
