"""
scripts/peek_dataset.py
数据集可视化抽查工具

用法:
  # 随机抽取 4 帧（只看图，不看标签）
  python scripts/peek_dataset.py --data-dir data/datasets/dataset_v4 --n 4

  # 指定帧索引
  python scripts/peek_dataset.py --data-dir data/datasets/dataset_v4 --idx 0 5 10

  # 查看长曝光
  python scripts/peek_dataset.py --data-dir data/datasets/dataset_v4 --long

  # 同时显示格点标注
  python scripts/peek_dataset.py --data-dir data/datasets/dataset_v4 --show-labels
"""

import argparse
import sys
import numpy as np
import matplotlib
matplotlib.use('TkAgg')   # Windows 用 TkAgg，如报错改为 'Qt5Agg' 或 'Agg'
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from pathlib import Path

# ── Windows 中文字体自动配置 ──────────────────────────────────────────
def _setup_cjk_font():
    """自动检测并配置支持中文的字体（Windows / macOS / Linux）"""
    candidates = [
        'Microsoft YaHei',   # Windows 微软雅黑
        'SimHei',            # Windows 黑体
        'STHeiti',           # macOS 黑体-简
        'Heiti SC',          # macOS
        'Noto Sans CJK SC',  # Linux
        'WenQuanYi Micro Hei',
    ]
    available = {f.name for f in fm.fontManager.ttflist}
    for name in candidates:
        if name in available:
            plt.rcParams['font.family'] = name
            plt.rcParams['axes.unicode_minus'] = False
            return
    # 找不到中文字体时，把中文换成英文（不报错）
    plt.rcParams['axes.unicode_minus'] = False

_setup_cjk_font()

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))


def peek(data_path, indices, use_long=False, show_labels=False, save_path=None):
    data    = np.load(data_path, allow_pickle=True)
    key     = 'images_long' if use_long else 'images_short'
    images  = data[key].astype(np.float32)
    labels  = data['labels'].astype(np.int32)   # (N, K)
    centers = data['centers']                    # (K, 2)

    N = images.shape[0]
    indices = [i % N for i in indices]

    ncols = min(len(indices), 4)
    nrows = (len(indices) + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols,
                             figsize=(ncols * 4, nrows * 4))
    if len(indices) == 1:
        axes = np.array([[axes]])
    elif nrows == 1:
        axes = axes[np.newaxis, :]
    elif ncols == 1:
        axes = axes[:, np.newaxis]

    exp_str = '长曝光' if use_long else '短曝光'
    fig.suptitle(f'PA-3HDA 数据集抽查 ({exp_str})', fontsize=14)

    for i, idx in enumerate(indices):
        ax  = axes[i // ncols][i % ncols]
        img = images[idx]
        lbl = labels[idx]   # (K,)

        # 显示图像
        vmin, vmax = np.percentile(img, 1), np.percentile(img, 99)
        ax.imshow(img, cmap='inferno', vmin=vmin, vmax=vmax, origin='upper')

        n_atoms = int(lbl.sum())
        title   = f'帧 {idx}  有原子: {n_atoms}/{len(lbl)}'
        ax.set_title(title, fontsize=9)
        ax.axis('off')

        # 可选：叠加标注
        if show_labels:
            for (cy, cx), l in zip(centers, lbl):
                color = 'lime' if l == 1 else 'red'
                marker = 'o' if l == 1 else 'x'
                ax.plot(cx, cy, marker, color=color, ms=6, mew=1.5, alpha=0.8)

    # 隐藏多余子图
    for i in range(len(indices), nrows * ncols):
        axes[i // ncols][i % ncols].axis('off')

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f'图像已保存: {save_path}')
    else:
        plt.show()


def main():
    parser = argparse.ArgumentParser(description='数据集抽查')
    parser.add_argument('--data-dir',    required=True)
    parser.add_argument('--split',       default='train',
                        choices=['train', 'val', 'test'])
    parser.add_argument('--n',           type=int, default=4,
                        help='随机抽取帧数')
    parser.add_argument('--idx',         type=int, nargs='+', default=None,
                        help='指定帧索引（优先于 --n）')
    parser.add_argument('--long',        action='store_true',
                        help='查看长曝光图像')
    parser.add_argument('--show-labels', action='store_true',
                        help='叠加格点标注（绿=有原子，红=无原子）')
    parser.add_argument('--save',        default=None,
                        help='保存图像路径（不指定则弹窗显示）')
    args = parser.parse_args()

    data_path = Path(args.data_dir) / f'{args.split}.npz'
    assert data_path.exists(), f'数据集不存在: {data_path}'

    data   = np.load(data_path, allow_pickle=True)
    N      = data['images_short'].shape[0]
    print(f'数据集: {data_path}  共 {N} 帧')

    if args.idx is not None:
        indices = args.idx
    else:
        rng = np.random.default_rng()
        indices = rng.choice(N, size=min(args.n, N), replace=False).tolist()

    print(f'抽查帧索引: {indices}')
    peek(str(data_path), indices,
         use_long=args.long, show_labels=args.show_labels,
         save_path=args.save)


if __name__ == '__main__':
    main()
