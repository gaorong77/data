"""
scripts/generate_data.py
PA-3HDA 仿真数据生成脚本

用法 (在工程根目录下运行):
  python scripts/generate_data.py --config configs/default.yaml --output-dir data/datasets/dataset_v4

可选参数:
  --n-train  训练帧数 (默认 2000)
  --n-val    验证帧数 (默认 200)
  --n-test   测试帧数 (默认 200)
  --n-rows   原子阵列行数 (覆盖配置文件)
  --n-cols   原子阵列列数 (覆盖配置文件)
  --fill-prob 填充概率 (默认 0.85)
  --seed     随机种子 (默认 42)
"""

import argparse
import sys
import os
import numpy as np
from pathlib import Path

# 确保从工程根目录导入
sys.path.insert(0, str(Path(__file__).parent.parent))

import yaml
from data.simulate import AtomArraySimulator


def build_simulator(cfg: dict, n_rows=None, n_cols=None) -> AtomArraySimulator:
    arr = cfg['array']
    sim = cfg['simulation']
    return AtomArraySimulator(
        n_rows               = n_rows or arr['n_rows'],
        n_cols               = n_cols or arr['n_cols'],
        grid_spacing         = arr['grid_spacing'],
        # PSF
        psf_sigma            = sim['psf_sigma'],
        light_source_stdev   = sim.get('light_source_stdev', 1.0),
        # 新增：真实效应
        atom_position_jitter = sim.get('atom_position_jitter', 0.35),
        psf_ellipticity      = sim.get('psf_ellipticity', 0.10),
        psf_drift_stdev      = sim.get('psf_drift_stdev', 0.15),
        hot_pixel_rate       = sim.get('hot_pixel_rate', 1e-5),
        hot_pixel_amp        = sim.get('hot_pixel_amp', 500.0),
        # 散射率 & 曝光时间
        scattering_rate      = sim.get('scattering_rate', 35000.0),
        exposure_time_l1     = sim.get('exposure_time_l1', 0.020),
        exposure_time_l2     = sim.get('exposure_time_l2', 0.060),
        survival_probability = sim.get('survival_probability', 1.0),
        # 背景
        stray_light_rate     = sim.get('stray_light_rate', 200.0),
        # 量子效率
        quantum_efficiency   = sim.get('quantum_efficiency', 0.72),
        # 暗电流
        dark_current_alpha   = sim.get('dark_current_alpha', 0.003),
        dark_current_beta    = sim.get('dark_current_beta', 1.0),
        # 偏置
        bias_clamp           = sim.get('bias_clamp', 100.0),
        bias_stdev           = sim.get('bias_stdev', 0.5),
        # 空间噪声
        row_noise_stdev      = sim.get('row_noise_stdev', 0.01),
        column_noise_scale   = sim.get('column_noise_scale', 0.005),
        flicker_noise_scale  = sim.get('flicker_noise_scale', 0.005),
        # 读出噪声
        readout_stdev        = sim.get('readout_stdev', 0.35),
        # 串扰
        crosstalk            = sim.get('crosstalk', 0.01),
    )


def save_split(out_dir: Path, name: str, simulator: AtomArraySimulator,
               n_frames: int, fill_prob: float, seed: int):
    print(f'  生成 {name} 集: {n_frames} 帧, fill_prob={fill_prob} ...',
          end='', flush=True)
    images_short, images_long, labels = simulator.generate_dataset(
        n_frames=n_frames, fill_prob=fill_prob, rng_seed=seed)

    out_file = out_dir / f'{name}.npz'
    np.savez_compressed(
        out_file,
        images_short = images_short,
        images_long  = images_long,
        labels       = labels,
        centers      = simulator.centers,
    )
    size_mb = out_file.stat().st_size / 1024 / 1024
    print(f' 完成 → {out_file} ({size_mb:.1f} MB)')
    print(f'    图像尺寸: {images_short.shape}  '
          f'标签尺寸: {labels.shape}  '
          f'原子数 K={simulator.K}')


def main():
    parser = argparse.ArgumentParser(description='PA-3HDA 数据生成')
    parser.add_argument('--config',     default='configs/default.yaml')
    parser.add_argument('--output-dir', default=None)
    parser.add_argument('--n-train',    type=int, default=None)
    parser.add_argument('--n-val',      type=int, default=None)
    parser.add_argument('--n-test',     type=int, default=None)
    parser.add_argument('--n-rows',     type=int, default=None)
    parser.add_argument('--n-cols',     type=int, default=None)
    parser.add_argument('--fill-prob',  type=float, default=None)
    parser.add_argument('--seed',       type=int, default=42)
    args = parser.parse_args()

    # 读取配置
    with open(args.config, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    ds_cfg = cfg['dataset']
    n_train   = args.n_train    or ds_cfg['n_train']
    n_val     = args.n_val      or ds_cfg['n_val']
    n_test    = args.n_test     or ds_cfg['n_test']
    fill_prob = args.fill_prob  or cfg['array']['fill_prob']
    out_dir   = Path(args.output_dir or
                     os.path.join(ds_cfg['root'], ds_cfg['name']))

    out_dir.mkdir(parents=True, exist_ok=True)
    print(f'输出目录: {out_dir}')

    # 构建仿真器
    sim = build_simulator(cfg, n_rows=args.n_rows, n_cols=args.n_cols)
    print(f'原子阵列: {sim.n_rows}×{sim.n_cols} = {sim.K} 个原子')
    print(f'图像尺寸: {sim.image_h}×{sim.image_w} px')
    print(f'格点间距: {sim.grid_spacing} px  PSF sigma: {sim.psf_sigma} px')
    print(f'短曝光信号: {sim.atom_signal:.0f} 光子  '
          f'长曝光信号: {sim.atom_signal_l2:.0f} 光子')

    # 生成均衡数据集（fill_prob=0.5，用于训练）
    print('\n[1/3] 生成训练集（均衡，fill_prob=0.5）...')
    save_split(out_dir, 'train', sim, n_train, 0.5, args.seed)

    print('\n[2/3] 生成验证集（均衡，fill_prob=0.5）...')
    save_split(out_dir, 'val', sim, n_val, 0.5, args.seed + 1)

    print('\n[3/3] 生成测试集（真实分布，fill_prob=0.85）...')
    save_split(out_dir, 'test', sim, n_test, 0.85, args.seed + 2)

    # 保存元数据
    import json
    meta = {
        'n_rows': sim.n_rows, 'n_cols': sim.n_cols,
        'K': sim.K, 'image_h': sim.image_h, 'image_w': sim.image_w,
        'grid_spacing': sim.grid_spacing, 'psf_sigma': sim.psf_sigma,
        'atom_signal_l1': sim.atom_signal, 'atom_signal_l2': sim.atom_signal_l2,
        'fill_prob_train': 0.5, 'fill_prob_test': 0.85,
        'centers_shape': list(sim.centers.shape),
    }
    with open(out_dir / 'metadata.json', 'w') as f:
        json.dump(meta, f, indent=2)
    print(f'\n元数据已保存: {out_dir}/metadata.json')
    print('\n数据生成完成！')
    print(f'训练命令示例:')
    print(f'  python scripts/run_train.py --model l1 --data-dir {out_dir}')


if __name__ == '__main__':
    main()
