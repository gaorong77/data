"""
scripts/calibrate_l2.py
PA-3HDA  L2 独立曝光时间标定（基于 auto_search.py 直接改写）

改进点（v2）：
  1. 移植 auto_search 的失败案例保存逻辑（含图片输出）
  2. n_test 默认 500（200k样本，上界≈1.5e-5），可用 --n-test 2000 达到接近6个9
  3. 可配置精度目标 --target（默认 1e-4 匹配 n_test=500 的统计能力）
  4. 评估前打印统计说明，明确当前样本量对应的上界下限

用法:
  python scripts/calibrate_l2.py
  python scripts/calibrate_l2.py --t-min 5 --t-start 15
  python scripts/calibrate_l2.py --n-test 2000 --target 1e-5
  python scripts/calibrate_l2.py --resume
"""

import argparse
import datetime
import io
import json
import math
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml

from data.dataset    import L1Dataset, _extract_roi
from data.simulate   import AtomArraySimulator
from models.l1_roi_cnn import L1_ROI_CNN
from train.trainer   import Trainer

SEARCH_DIR = ROOT / 'l2_calibration'


# ── Tee（与 auto_search.py 完全一致）──────────────────────────
class _Tee(io.TextIOBase):
    def __init__(self, primary, secondary):
        self._primary = primary; self._secondary = secondary; self._buf = ''
    @staticmethod
    def _ts():
        return datetime.datetime.now().strftime('[%H:%M:%S.%f')[:-3] + '] '
    def _write_to_file(self, s):
        data = self._buf + s; lines = data.split('\n'); self._buf = lines[-1]
        for line in lines[:-1]:
            self._secondary.write(('\n' if line == '' else self._ts() + line + '\n'))
        self._secondary.flush()
    def write(self, s):
        self._primary.write(s); self._primary.flush()
        self._write_to_file(s); return len(s)
    def flush(self):
        self._primary.flush()
        if self._buf:
            self._secondary.write(self._ts() + self._buf); self._buf = ''
        self._secondary.flush()
    def fileno(self): return self._primary.fileno()
    def isatty(self): return self._primary.isatty()

def _start_tee(log_path: Path):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    fh = open(log_path, 'a', encoding='utf-8', buffering=1)
    fh.write(f'\n{"="*64}\n  Run: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n{"="*64}\n')
    sys.stdout = _Tee(sys.__stdout__, fh)
    sys.stderr = _Tee(sys.__stderr__, fh)
    return fh

def _stop_tee(fh):
    sys.stdout = sys.__stdout__; sys.stderr = sys.__stderr__; fh.close()


# ── 工具 ──────────────────────────────────────────────────────
def tag(t_ms): return f't{t_ms:.2f}ms'
def load_cfg(path):
    with open(path, encoding='utf-8') as f: return yaml.safe_load(f)
def get_device():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        free, total = torch.cuda.mem_get_info(0)
        print(f'  [GPU] {torch.cuda.get_device_name(0)} ({free//1024**2}/{total//1024**2} MB)')
        return torch.device('cuda')
    print('  [CPU] 无 GPU，使用 CPU'); return torch.device('cpu')
def hline(ch='─', n=64): print(ch * n)


# ── CP 置信上界 ────────────────────────────────────────────────
def cp_upper(n_err, n_total, conf=0.95):
    if n_total == 0: return 1.0
    if n_err == 0:   return 1.0 - (1.0 - conf) ** (1.0 / n_total)
    try:
        from scipy.stats import beta
        return float(beta.ppf(conf, n_err + 1, n_total - n_err))
    except ImportError:
        p = n_err / n_total
        return min(1.0, p + 1.645 * math.sqrt(p * (1 - p) / max(n_total, 1)))


# ── Step 1: 数据生成（与 auto_search.py 完全一致）─────────────
def generate_dataset(cfg, t_l2, out_dir, n_train=400, n_val=100, n_test=500):
    flag = out_dir / '.done'
    if flag.exists():
        print(f'  [跳过] 数据集已存在: {out_dir}'); return

    out_dir.mkdir(parents=True, exist_ok=True)
    arr = cfg['array']; sim = cfg['simulation']

    simulator = AtomArraySimulator(
        n_rows=arr['n_rows'], n_cols=arr['n_cols'],
        grid_spacing=arr['grid_spacing'],
        psf_sigma=sim['psf_sigma'],
        light_source_stdev=sim.get('light_source_stdev', 1.0),
        atom_position_jitter=sim.get('atom_position_jitter', 0.35),
        psf_ellipticity=sim.get('psf_ellipticity', 0.10),
        psf_drift_stdev=sim.get('psf_drift_stdev', 0.15),
        hot_pixel_rate=sim.get('hot_pixel_rate', 1e-5),
        hot_pixel_amp=sim.get('hot_pixel_amp', 500.0),
        scattering_rate=sim.get('scattering_rate', 35000.0),
        exposure_time_l1=t_l2,
        exposure_time_l2=t_l2,
        survival_probability=sim.get('survival_probability', 1.0),
        stray_light_rate=sim.get('stray_light_rate', 200.0),
        quantum_efficiency=sim.get('quantum_efficiency', 0.72),
        dark_current_alpha=sim.get('dark_current_alpha', 0.003),
        dark_current_beta=sim.get('dark_current_beta', 1.0),
        bias_clamp=sim.get('bias_clamp', 100.0),
        bias_stdev=sim.get('bias_stdev', 0.5),
        row_noise_stdev=sim.get('row_noise_stdev', 0.01),
        column_noise_scale=sim.get('column_noise_scale', 0.005),
        flicker_noise_scale=sim.get('flicker_noise_scale', 0.005),
        readout_stdev=sim.get('readout_stdev', 0.35),
        crosstalk=sim.get('crosstalk', 0.01),
    )

    print(f'  [仿真] t_l2={t_l2*1000:.1f}ms → 信号={simulator.atom_signal:.0f}ph')

    for split, n, fp, seed in [('train', n_train, 0.5,  42),
                                ('val',   n_val,   0.5,  43),
                                ('test',  n_test,  0.85, 44)]:
        imgs_s, imgs_l, labels = simulator.generate_dataset(
            n_frames=n, fill_prob=fp, rng_seed=seed)
        np.savez_compressed(out_dir / f'{split}.npz',
                            images_short=imgs_s, images_long=imgs_l,
                            labels=labels, centers=simulator.centers)
        print(f'  [数据] {split}: {n}帧')

    tr = np.load(str(out_dir / 'train.npz'), allow_pickle=True)
    norm = {
        'gmax_s': float(np.percentile(tr['images_short'][:20], 99.9)) + 1e-6,
        'gmax_l': float(np.percentile(tr['images_long'][:20],  99.9)) + 1e-6,
    }
    (out_dir / 'normalization.json').write_text(json.dumps(norm, indent=2))
    del tr
    flag.touch()


# ── Step 2: 训练 L2（与 auto_search.train_one 完全一致）────────
def _build_l2(m_cfg):
    return L1_ROI_CNN(**{k: m_cfg['l2'][k]
                         for k in ['in_channels', 'hidden_channels', 'out_channels']})

def train_l2(cfg, data_dir, ckpt_dir, device, epochs_override=None):
    ckpt_path  = ckpt_dir / 'l2_best.pth'
    done_flag  = ckpt_dir / 'l2.done'
    score_file = ckpt_dir / 'l2_score.json'

    if done_flag.exists() and ckpt_path.exists():
        try:   score = json.loads(score_file.read_text())['best']
        except Exception: score = 0.0
        print(f'  [跳过] l2 已训练，score={score:.4f}'); return score

    ckpt_dir.mkdir(parents=True, exist_ok=True)
    roi_n  = cfg['roi']['n']
    tr_cfg = dict(cfg['training']['l2'])
    if epochs_override: tr_cfg['epochs'] = epochs_override

    train_ds = L1Dataset(str(data_dir / 'train.npz'), roi_n=roi_n, augment=True)
    val_ds   = L1Dataset(str(data_dir / 'val.npz'),   roi_n=roi_n, augment=False)

    trainer = Trainer(_build_l2(cfg['model']), train_ds, val_ds, tr_cfg,
                      str(ckpt_path), device,
                      model_type='l2', use_balanced_sampler=True)
    best, _ = trainer.train()

    score_file.write_text(json.dumps({'best': best}))
    done_flag.touch()
    print(f'  l2 完成, score={best:.4f}')
    return best


# ── Step 3: L2 独立评估（移植 auto_search 失败案例逻辑）────────
@torch.no_grad()
def evaluate_l2(cfg, data_dir, ckpt_dir, device, target):
    roi_n      = cfg['roi']['n']
    roi_n_wide = roi_n * cfg['roi']['k_wide']

    # 加载模型
    ckpt = ckpt_dir / 'l2_best.pth'
    if not ckpt.exists():
        raise FileNotFoundError(f'L2 checkpoint 不存在: {ckpt}')
    if ckpt.stat().st_size < 256:
        raise RuntimeError(f'L2 checkpoint 疑似损坏: {ckpt}')
    try:
        model = _build_l2(cfg['model'])
        model.load_state_dict(torch.load(ckpt, map_location=device, weights_only=True))
        model = model.eval().to(device)
    except EOFError:
        raise RuntimeError(f'EOFError，请删除后重训: {ckpt}')

    # 加载测试集
    data    = np.load(str(data_dir / 'test.npz'), allow_pickle=True)
    imgs_s  = data['images_short'].astype(np.float32)
    labels  = data['labels'].astype(np.int32)
    centers = data['centers']
    N, K    = labels.shape

    ns     = json.loads((data_dir / 'normalization.json').read_text())
    gmax_s = ns['gmax_s']
    print(f'  [归一化] gmax_s={gmax_s:.1f}')
    n_total = N * K
    print(f'  [评估规模] {N}帧×{K}格点={n_total:,}样本  '
          f'零错误上界≈{cp_upper(0, n_total):.2e}  目标≤{target:.0e}')

    def infer(roi):
        x   = torch.from_numpy(roi).unsqueeze(0).unsqueeze(0).to(device)
        out = model(x)
        if out.dim() == 2: out = out.squeeze(1)
        return float(torch.sigmoid(out).item())

    # ── 推理 + 收集结果（与 auto_search.evaluate_system 相同结构）
    all_preds, all_gts = [], []
    records = []   # (p_l2, pred, gt, frame_i, atom_k)

    for i in range(N):
        img = imgs_s[i] / gmax_s
        for k in range(K):
            cy, cx = centers[k]; gt = int(labels[i, k])
            p      = infer(_extract_roi(img, cy, cx, roi_n))
            pred   = 1 if p > 0.5 else 0
            all_preds.append(pred); all_gts.append(gt)
            records.append((p, pred, gt, i, k))

    preds = np.array(all_preds); gts = np.array(all_gts)
    neg   = gts == 0;            pos = gts == 1
    fa    = int((preds[neg] == 1).sum())
    md    = int((preds[pos] == 0).sum())
    n_atom  = int(pos.sum()); n_empty = int(neg.sum())

    # ── 失败案例（与 auto_search.evaluate_system 完全一致）──────
    frame_preds = preds.reshape(N, K); frame_gts = gts.reshape(N, K)
    atom_errors = frame_preds != frame_gts
    frame_ok    = (~atom_errors).all(axis=1)
    n_bad_frames = int((~frame_ok).sum())
    n_bad_atoms  = int(atom_errors.sum())
    per_site_err = atom_errors.mean(axis=0)
    worst_sites  = np.argsort(per_site_err)[-5:][::-1]

    failure_dir = ckpt_dir.parent / 'failure_cases'
    meta_list   = []

    if n_bad_atoms > 0:
        failure_dir.mkdir(exist_ok=True)
        try:
            import matplotlib; matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            matplotlib.rcParams['font.family']        = 'DejaVu Sans'
            matplotlib.rcParams['axes.unicode_minus'] = False
            _has_mpl = True
        except ImportError:
            _has_mpl = False

        case_id = 0
        for fi in np.where(~frame_ok)[0]:
            for ak in np.where(atom_errors[fi])[0]:
                p_l2, rpred, rgt, _, _ = records[fi * K + ak]
                cy, cx = centers[ak]
                etype  = 'FA' if (rpred == 1 and rgt == 0) else 'MD'

                roi_s = _extract_roi(imgs_s[fi] / gmax_s, cy, cx, roi_n)
                roi_w = _extract_roi(imgs_s[fi] / gmax_s, cy, cx, roi_n_wide)

                meta = {
                    'case_id': case_id, 'error_type': etype,
                    'frame': int(fi),   'atom_k': int(ak),
                    'cy': float(cy),    'cx': float(cx),
                    'gt': int(rgt),     'pred': int(rpred),
                    'p_l2': round(float(p_l2), 6),
                }
                meta_list.append(meta)

                np.savez_compressed(
                    failure_dir / f'case_{case_id:04d}_{etype}_f{fi:03d}_k{ak:03d}.npz',
                    roi_short=roi_s, roi_wide=roi_w,
                    meta=np.array([meta], dtype=object))

                if _has_mpl:
                    import matplotlib.patches as patches
                    fig, axes = plt.subplots(1, 2, figsize=(9, 4))
                    fig.patch.set_facecolor('#0D0D0D')

                    # 左图：n×n ROI 原图
                    ax0 = axes[0]
                    ax0.imshow(roi_s, cmap='inferno', interpolation='nearest')
                    ax0.set_title(f'ROI {roi_n}×{roi_n} px\np_l2={p_l2:.4f}  gt={rgt}  pred={rpred}',
                                  fontsize=8, color='white')
                    ax0.axis('off')
                    for sp in ax0.spines.values():
                        sp.set_edgecolor('#FF5555' if etype=='FA' else '#FFB300')
                        sp.set_linewidth(2)

                    # 右图：3n×3n Wide ROI，框出 n×n 中心区域
                    ax1 = axes[1]
                    ax1.imshow(roi_w, cmap='inferno', interpolation='nearest')
                    # 计算 n×n 在 3n×3n 中的位置（居中）
                    offset = roi_n  # 3n//2 - n//2 = n
                    rect = patches.Rectangle(
                        (offset - 0.5, offset - 0.5), roi_n, roi_n,
                        linewidth=2, edgecolor='#00FFD4',
                        facecolor='none', linestyle='--')
                    ax1.add_patch(rect)
                    # 四角标记
                    for cx_, cy_ in [(offset-0.5, offset-0.5),
                                     (offset+roi_n-0.5, offset-0.5),
                                     (offset-0.5, offset+roi_n-0.5),
                                     (offset+roi_n-0.5, offset+roi_n-0.5)]:
                        ax1.plot(cx_, cy_, 's', ms=4, color='#00FFD4', zorder=5)
                    ax1.set_title(f'Wide {roi_n*3}×{roi_n*3} px（虚线框=ROI）',
                                  fontsize=8, color='#AAAAAA')
                    ax1.axis('off')
                    for sp in ax1.spines.values():
                        sp.set_edgecolor('#444444'); sp.set_linewidth(1)

                    fig.suptitle(
                        f'[{etype}] Frame#{fi:03d} Atom#{ak:03d}  '
                        f'gt={rgt} pred={rpred}  p_l2={p_l2:.4f}',
                        fontsize=9, color='#FF5555' if etype=='FA' else '#FFB300')
                    plt.tight_layout()
                    plt.savefig(
                        failure_dir / f'case_{case_id:04d}_{etype}_f{fi:03d}_k{ak:03d}.png',
                        dpi=130, bbox_inches='tight', facecolor='#0D0D0D')
                    plt.close(fig)
                case_id += 1

        (failure_dir / 'failure_summary.json').write_text(
            json.dumps({'n_bad_frames': n_bad_frames, 'n_bad_atoms': n_bad_atoms,
                        'worst_sites': worst_sites.tolist(), 'cases': meta_list},
                       indent=2, ensure_ascii=False))

    # ── 诊断打印（与 auto_search 完全一致）─────────────────────
    atom_acc = float((preds == gts).mean())
    print(f'\n  [原子级] 准确率={atom_acc:.6f}  '
          f'错误格点={n_bad_atoms}/{n_total}  失败帧={n_bad_frames}/{N}')
    if n_bad_atoms > 0:
        for si in worst_sites:
            if per_site_err[si] > 0:
                print(f'    格点#{si:03d}: {per_site_err[si]:.4%}  '
                      f'(y={centers[si][0]:.0f} x={centers[si][1]:.0f})')
        print(f'  [失败案例库] → {failure_dir}  ({len(meta_list)} 条)')
        for fi in np.where(~frame_ok)[0][:5]:
            for ak in np.where(atom_errors[fi])[0][:5]:
                p_l2, rpred, rgt, _, _ = records[fi * K + ak]
                etype = 'FA(误报)' if rpred == 1 else 'MD(漏检)'
                print(f'    帧#{fi:03d} 格点#{ak:03d} [{etype}]'
                      f'  p_l2={p_l2:.4f}  gt={rgt}  pred={rpred}')
    else:
        print('  [诊断] 所有帧完全正确，无失败案例 ✓')

    # ── CP 置信上界 ────────────────────────────────────────────
    far_u  = cp_upper(fa, n_empty)
    mdr_u  = cp_upper(md, n_atom)
    passed = far_u <= target and mdr_u <= target

    print(f'\n  ┌─ L2 独立评估 ──────────────────────────────')
    print(f'  │  FA={fa}  MD={md}  (原子{n_atom:,} / 空{n_empty:,})')
    print(f'  │  FAR 95%上界 = {far_u:.3e}  {"✓" if far_u<=target else "✗"} (目标≤{target:.0e})')
    print(f'  │  MDR 95%上界 = {mdr_u:.3e}  {"✓" if mdr_u<=target else "✗"} (目标≤{target:.0e})')
    print(f'  │  {"【PASS】" if passed else "【FAIL】"}')
    print(f'  └────────────────────────────────────────────')

    return {'fa': fa, 'md': md, 'n_atom': n_atom, 'n_empty': n_empty,
            'n_total': n_total, 'atom_accuracy': atom_acc,
            'n_bad_frames': n_bad_frames, 'n_bad_atoms': n_bad_atoms,
            'far_upper': far_u, 'mdr_upper': mdr_u,
            'target': target, 'pass': passed}


# ── run_point（与 auto_search.run_point 结构完全一致）──────────
def run_point(t_ms, cfg, device, args):
    t_l2        = t_ms / 1000.0
    point_dir   = SEARCH_DIR / tag(t_ms)
    data_dir    = point_dir / 'data'
    ckpt_dir    = point_dir / 'checkpoints'
    result_file = point_dir / 'result.json'

    if args.resume and result_file.exists():
        try:
            r = json.loads(result_file.read_text())
            if r.get('pass', False):
                print(f'  [跳过-已通过] t_L2={t_ms:.2f}ms  '
                      f"FAR_u={r['system']['far_upper']:.2e}  ✓")
                return r
        except Exception: pass

    hline('─')
    print(f'\n▶ 评估 t_L2={t_ms:.2f}ms  (~{int(35000*t_l2*0.72)}ph)')
    t0 = time.time()

    print('\n[1/3] 生成仿真数据集...')
    generate_dataset(cfg, t_l2, data_dir,
                     n_train=args.n_train, n_val=args.n_val, n_test=args.n_test)

    print('\n[2/3] 训练 L2 模型...')
    score = train_l2(cfg, data_dir, ckpt_dir, device, epochs_override=args.epochs)

    print('\n[3/3] L2 独立评估...')
    try:
        sys_metrics = evaluate_l2(cfg, data_dir, ckpt_dir, device, target=args.target)
    except (EOFError, RuntimeError) as e:
        print(f'\n  [错误] {e}')
        for pth in ckpt_dir.glob('*.pth'):
            if pth.stat().st_size < 256:
                pth.unlink(); print(f'  [清理] {pth.name}')
        sys_metrics = {'fa': -1, 'md': -1, 'n_total': 0, 'atom_accuracy': 0.0,
                       'n_bad_frames': -1, 'n_bad_atoms': -1,
                       'far_upper': 1.0, 'mdr_upper': 1.0, 'pass': False}

    elapsed = time.time() - t0
    ok      = sys_metrics['pass']
    result  = {
        't_l2_ms':   t_ms,
        'n_photons': int(35000 * t_l2 * 0.72),
        'score':     round(float(score), 4),
        'system':    sys_metrics,
        'pass':      ok,
        'elapsed_s': round(elapsed, 1),
    }
    point_dir.mkdir(parents=True, exist_ok=True)
    result_file.write_text(json.dumps(result, indent=2))

    flag = '✓ 通过' if ok else '✗ 未通过'
    print(f'\n  结果: FAR_u={sys_metrics["far_upper"]:.3e}  '
          f'MDR_u={sys_metrics["mdr_upper"]:.3e}  {flag}')
    print(f'  耗时: {elapsed/60:.1f} 分钟')
    return result


# ── 绘图（与 auto_search.plot_summary 结构一致）────────────────
def plot_summary(all_results, save_path):
    try:
        import matplotlib; matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        matplotlib.rcParams['font.family']        = 'DejaVu Sans'
        matplotlib.rcParams['axes.unicode_minus'] = False

        ts    = [r['t_l2_ms']             for r in all_results]
        far_u = [r['system']['far_upper'] for r in all_results]
        mdr_u = [r['system']['mdr_upper'] for r in all_results]
        n_phs = [r['n_photons']           for r in all_results]

        fig, axes = plt.subplots(1, 3, figsize=(14, 5))
        fig.suptitle('PA-3HDA L2 Calibration Curve', fontsize=13)
        for ax, vals, name, color in [
            (axes[0], far_u, 'FAR 95% Upper Bound', 'tab:orange'),
            (axes[1], mdr_u, 'MDR 95% Upper Bound', 'tab:red'),
        ]:
            ax.semilogy(ts, vals, 'o-', color=color, linewidth=2)
            ax.axhline(1e-6, color='gray', linestyle='--', label='1e-6')
            ax.set_xlabel('t_L2 (ms)'); ax.set_ylabel(name)
            ax.set_title(name); ax.grid(True, alpha=0.3); ax.legend(fontsize=8)
        for r in all_results:
            c = 'green' if r['pass'] else 'red'
            for ax in axes[:2]:
                ax.axvline(r['t_l2_ms'], color=c, alpha=0.15, linewidth=8)
        axes[2].bar(ts, n_phs,
                    color=['green' if r['pass'] else 'red' for r in all_results],
                    alpha=0.7)
        axes[2].set_xlabel('t_L2 (ms)'); axes[2].set_ylabel('Photons/atom')
        axes[2].set_title('Photons vs Pass/Fail'); axes[2].grid(True, alpha=0.3)
        plt.tight_layout()
        save_path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f'\n[plot] saved: {save_path}'); plt.close()
    except Exception as e:
        print(f'[warning] plot failed: {e}')


# ── 主入口（与 auto_search.py 完全一致的结构）──────────────────
def main():
    parser = argparse.ArgumentParser(description='PA-3HDA L2 曝光时间标定')
    parser.add_argument('--config',    default='configs/default.yaml')
    parser.add_argument('--t-start',   type=float, default=15.0,  help='搜索上界 (ms)')
    parser.add_argument('--t-min',     type=float, default=5.0,   help='搜索下界 (ms)')
    parser.add_argument('--max-iters', type=int,   default=8)
    parser.add_argument('--n-train',   type=int,   default=400)
    parser.add_argument('--n-val',     type=int,   default=100)
    parser.add_argument('--n-test',    type=int,   default=500,
                        help='测试帧数（500帧→200k样本，上界≈1.5e-5；'
                             '2000帧→800k样本，上界≈3.7e-6）')
    parser.add_argument('--target',    type=float, default=1e-4,
                        help='FAR/MDR 95%%上界目标（默认1e-4匹配n-test=500；'
                             'n-test=2000时可设1e-5）')
    parser.add_argument('--epochs',    type=int,   default=None)
    parser.add_argument('--resume',    action='store_true')
    parser.add_argument('--clean',     action='store_true')
    args = parser.parse_args()

    if args.clean and SEARCH_DIR.exists():
        shutil.rmtree(SEARCH_DIR); print(f'[清理] 已删除 {SEARCH_DIR}')

    SEARCH_DIR.mkdir(parents=True, exist_ok=True)
    _log_fh = _start_tee(SEARCH_DIR / 'run.log')
    print(f'[日志] {SEARCH_DIR / "run.log"}')
    try:
        _run(args)
    finally:
        _stop_tee(_log_fh)


def _run(args):
    cfg    = load_cfg(args.config)
    device = get_device()
    n_samples = args.n_test * cfg['array']['n_rows'] * cfg['array']['n_cols']

    hline('═')
    print('  PA-3HDA L2 独立曝光时间标定')
    hline('═')
    print(f'  精度目标  FAR/MDR 95%上界 ≤ {args.target:.0e}')
    print(f'  搜索范围  [{args.t_min}ms, {args.t_start}ms]  最大迭代: {args.max_iters}')
    print(f'  每点数据  train={args.n_train} val={args.n_val} test={args.n_test}帧')
    print(f'  样本统计  {args.n_test}帧×400格点={n_samples:,}样本  '
          f'零错误上界≈{cp_upper(0, n_samples):.2e}')
    if cp_upper(0, n_samples) > args.target:
        print(f'\n  ⚠️  警告: 当前样本量({n_samples:,})即使零错误也无法达到目标{args.target:.0e}')
        print(f'     零错误上界={cp_upper(0,n_samples):.2e} > 目标{args.target:.0e}')
        needed = int(math.ceil(math.log(0.05) / math.log(1 - args.target))) // 400 + 1
        print(f'     建议: --n-test {needed}（约{needed*400//1000}k样本）\n')
    print(f'  结果目录  {SEARCH_DIR}')
    hline('═')

    all_results = []; t_lo = args.t_min; t_hi = args.t_start

    print('\n[初始化] 验证起始点...')
    r_start = run_point(args.t_start, cfg, device, args)
    all_results.append(r_start)
    if not r_start['pass']:
        print(f'\n[错误] 起始点 {args.t_start}ms 未通过！请增大 --t-start 或降低 --target。')
        return

    print(f'\n开始二分搜索: [{t_lo:.2f}ms, {t_hi:.2f}ms]')
    for i in range(args.max_iters):
        if t_hi - t_lo < 0.5:
            print('\n[收敛] 区间宽度 < 0.5ms，停止搜索'); break
        t_mid = (t_lo + t_hi) / 2.0
        print(f'\n=== 二分第{i+1}/{args.max_iters}轮 '
              f'[{t_lo:.2f},{t_hi:.2f}ms] 候选{t_mid:.2f}ms ===')
        r = run_point(t_mid, cfg, device, args)
        all_results.append(r)
        if r['pass']:
            t_hi = t_mid; print(f'  ↓ 通过，新上界={t_hi:.2f}ms')
        else:
            t_lo = t_mid; print(f'  ↑ 未通过，新下界={t_lo:.2f}ms')

    hline('═')
    print('\n  ★ 标定完成 ★')
    hline('═')
    print(f'  t_L2* = {t_hi:.2f} ms  (~{int(35000*(t_hi/1000)*0.72)} ph/atom)')
    print(f'  建议值 (×1.15裕量): {t_hi*1.15:.2f} ms')
    print(f'\n  {"t_L2(ms)":>10}  {"FAR上界":>12}  {"MDR上界":>12}  {"ph":>6}  {"结论":>6}')
    print('  ' + '─' * 56)
    for r in sorted(all_results, key=lambda x: x['t_l2_ms']):
        s = r['system']; ok = '✓' if r['pass'] else '✗'
        print(f"  {r['t_l2_ms']:>10.2f}  {s['far_upper']:>12.3e}  "
              f"{s['mdr_upper']:>12.3e}  {r['n_photons']:>6}  {ok:>6}")
    hline('═')
    print(f'\n  下一步: python calibration/calibrate_threshold.py --t-l2 {t_hi:.2f}')

    summary = {'t_l2_star_ms': t_hi,
               't_l2_recommend_ms': round(t_hi * 1.15, 2),
               'n_photons_star': int(35000*(t_hi/1000)*0.72),
               'target': args.target, 'all_results': all_results}
    sp = SEARCH_DIR / 'summary.json'
    sp.write_text(json.dumps(summary, indent=2))
    print(f'\n[保存] {sp}')

    plot_summary(sorted(all_results, key=lambda x: x['t_l2_ms']),
                 SEARCH_DIR / 'calibration_curve.png')


if __name__ == '__main__':
    main()
