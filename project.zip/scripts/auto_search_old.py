"""
scripts/auto_search.py
PA-3HDA 一键自适应最短曝光时间搜索脚本

流程:
  1. 从 t_l1=20ms 开始，二分递减搜索最短曝光时间
  2. 每个候选点: 生成数据 → 训练4个模型 → 整合评估
  3. 找到满足所有指标的最短曝光时间

用法:
  python scripts/auto_search.py
  python scripts/auto_search.py --fidelity 0.999 --far 0.001 --mdr 0.001
  python scripts/auto_search.py --t-start 20 --t-min 2 --max-iters 8
  python scripts/auto_search.py --resume   # 跳过已完成的点继续搜索
"""

import argparse
import datetime
import io
import json
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import yaml

from data.dataset    import L1Dataset, L2Dataset, L3Dataset, _extract_roi
from data.simulate   import AtomArraySimulator
from models.l1_roi_cnn import L1_ROI_CNN
from models.l3_unet  import L3_UNet
from train.trainer   import Trainer

# ─────────────────────────────────────────────────────────────
# 常量
# ─────────────────────────────────────────────────────────────
SEARCH_DIR = ROOT / 'search_results'


# ─────────────────────────────────────────────────────────────
# Tee: 同时将 stdout/stderr 输出到屏幕和日志文件
# ─────────────────────────────────────────────────────────────

class _Tee(io.TextIOBase):
    """写操作同时转发到屏幕和日志文件（日志每行加毫秒级时间戳）。"""

    def __init__(self, primary, secondary):
        self._primary   = primary
        self._secondary = secondary
        self._buf       = ''

    @staticmethod
    def _ts():
        return datetime.datetime.now().strftime('[%H:%M:%S.%f')[:-3] + '] '

    def _write_to_file(self, s):
        data  = self._buf + s
        lines = data.split('\n')
        self._buf = lines[-1]
        for line in lines[:-1]:
            self._secondary.write(('\n' if line == '' else self._ts() + line + '\n'))
        self._secondary.flush()

    def write(self, s):
        self._primary.write(s)
        self._primary.flush()
        self._write_to_file(s)
        return len(s)

    def flush(self):
        self._primary.flush()
        if self._buf:
            self._secondary.write(self._ts() + self._buf)
            self._buf = ''
        self._secondary.flush()

    def fileno(self):   return self._primary.fileno()
    def isatty(self):   return self._primary.isatty()


def _start_tee(log_path: Path):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    fh = open(log_path, 'a', encoding='utf-8', buffering=1)
    fh.write(f'\n{"="*64}\n'
             f'  Run: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n'
             f'{"="*64}\n')
    sys.stdout = _Tee(sys.__stdout__, fh)
    sys.stderr = _Tee(sys.__stderr__, fh)
    return fh


def _stop_tee(fh):
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    fh.close()


# ─────────────────────────────────────────────────────────────
# 工具
# ─────────────────────────────────────────────────────────────

def tag(t_ms: float) -> str:
    return f't{t_ms:.2f}ms'

def load_cfg(path: str) -> dict:
    with open(path, encoding='utf-8') as f:
        return yaml.safe_load(f)

def get_device() -> torch.device:
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        free, total = torch.cuda.mem_get_info(0)
        print(f'  [GPU] {torch.cuda.get_device_name(0)} '
              f'({free//1024**2}/{total//1024**2} MB)')
        return torch.device('cuda')
    print('  [CPU] 无 GPU，使用 CPU（训练会慢）')
    return torch.device('cpu')

def hline(ch='─', n=64):
    print(ch * n)


# ─────────────────────────────────────────────────────────────
# Step 1: 数据生成
# ─────────────────────────────────────────────────────────────

def generate_dataset(cfg: dict, t_l1: float, out_dir: Path,
                     n_train=400, n_val=100, n_test=100):
    """用指定曝光时间生成数据集，跳过已存在的。"""
    flag = out_dir / '.done'
    if flag.exists():
        print(f'  [跳过] 数据集已存在: {out_dir}')
        return

    out_dir.mkdir(parents=True, exist_ok=True)
    arr = cfg['array']
    sim = cfg['simulation']

    simulator = AtomArraySimulator(
        n_rows=arr['n_rows'], n_cols=arr['n_cols'],
        grid_spacing=arr['grid_spacing'],
        psf_sigma=sim['psf_sigma'],
        light_source_stdev=sim.get('light_source_stdev', 1.0),
        atom_position_jitter=sim.get('atom_position_jitter', 0.35),
        psf_ellipticity=sim.get('psf_ellipticity', 0.10),
        psf_drift_stdev=sim.get('psf_drift_stdev', 0.15),
        hot_pixel_rate=sim.get('hot_pixel_rate', 1e-5),
        hot_pixel_amp=sim.get('hot_pixel_amp', 500.0),
        scattering_rate=sim.get('scattering_rate', 35000.0),
        exposure_time_l1=t_l1,
        exposure_time_l2=t_l1 * 3.0,
        survival_probability=sim.get('survival_probability', 1.0),
        stray_light_rate=sim.get('stray_light_rate', 200.0),
        quantum_efficiency=sim.get('quantum_efficiency', 0.72),
        dark_current_alpha=sim.get('dark_current_alpha', 0.003),
        dark_current_beta=sim.get('dark_current_beta', 1.0),
        bias_clamp=sim.get('bias_clamp', 100.0),
        bias_stdev=sim.get('bias_stdev', 0.5),
        row_noise_stdev=sim.get('row_noise_stdev', 0.01),
        column_noise_scale=sim.get('column_noise_scale', 0.005),
        flicker_noise_scale=sim.get('flicker_noise_scale', 0.005),
        readout_stdev=sim.get('readout_stdev', 0.35),
        crosstalk=sim.get('crosstalk', 0.01),
    )

    print(f'  [仿真] t_l1={t_l1*1000:.1f}ms → '
          f'信号L1={simulator.atom_signal:.0f}ph  '
          f'L2={simulator.atom_signal_l2:.0f}ph')

    for split, n, fp, seed in [('train', n_train, 0.5,  42),
                                ('val',   n_val,   0.5,  43),
                                ('test',  n_test,  0.85, 44)]:
        imgs_s, imgs_l, labels = simulator.generate_dataset(
            n_frames=n, fill_prob=fp, rng_seed=seed)
        np.savez_compressed(out_dir / f'{split}.npz',
                            images_short=imgs_s, images_long=imgs_l,
                            labels=labels, centers=simulator.centers)
        print(f'  [数据] {split}: {n}帧')

    # 保存归一化基准（与 dataset.py 训练时完全一致）
    tr = np.load(str(out_dir / 'train.npz'), allow_pickle=True)
    norm = {
        'gmax_s': float(np.percentile(tr['images_short'][:20], 99.9)) + 1e-6,
        'gmax_l': float(np.percentile(tr['images_long'][:20],  99.9)) + 1e-6,
    }
    (out_dir / 'normalization.json').write_text(json.dumps(norm, indent=2))
    del tr

    flag.touch()


# ─────────────────────────────────────────────────────────────
# Step 2: 单模型训练
# ─────────────────────────────────────────────────────────────

def _build_l1_cnn(m_cfg, key):
    return L1_ROI_CNN(**{k: m_cfg[key][k]
                         for k in ['in_channels', 'hidden_channels', 'out_channels']})

def train_one(model_type: str, cfg: dict, data_dir: Path,
              ckpt_dir: Path, device: torch.device,
              epochs_override: int = None) -> float:
    """训练单个模型，返回最优分数。跳过已有权重。"""
    ckpt_path  = ckpt_dir / f'{model_type}_best.pth'
    done_flag  = ckpt_dir / f'{model_type}.done'
    score_file = ckpt_dir / f'{model_type}_score.json'

    if done_flag.exists() and ckpt_path.exists():
        try:
            score = json.loads(score_file.read_text())['best']
        except (json.JSONDecodeError, KeyError, FileNotFoundError):
            score = 0.0   # score 文件损坏或空，返回占位值，不影响评估
        print(f'  [跳过] {model_type} 已训练，score={score:.4f}')
        return score

    ckpt_dir.mkdir(parents=True, exist_ok=True)
    roi_n      = cfg['roi']['n']
    roi_n_wide = roi_n * cfg['roi']['k_wide']
    m_cfg      = cfg['model']
    tr_base    = cfg['training']
    train_npz  = str(data_dir / 'train.npz')
    val_npz    = str(data_dir / 'val.npz')

    if model_type == 'l1':
        tr_cfg   = dict(tr_base['l1'])
        train_ds = L1Dataset(train_npz, roi_n=roi_n,      augment=True)
        val_ds   = L1Dataset(val_npz,   roi_n=roi_n,      augment=False)
        model    = _build_l1_cnn(m_cfg, 'l1')
    elif model_type == 'l1_wide':
        tr_cfg   = dict(tr_base['l1_wide'])
        train_ds = L1Dataset(train_npz, roi_n=roi_n_wide, augment=True)
        val_ds   = L1Dataset(val_npz,   roi_n=roi_n_wide, augment=False)
        model    = _build_l1_cnn(m_cfg, 'l1_wide')
    elif model_type == 'l2':
        tr_cfg   = dict(tr_base['l2'])
        train_ds = L2Dataset(train_npz, roi_n=roi_n,      augment=True)
        val_ds   = L2Dataset(val_npz,   roi_n=roi_n,      augment=False)
        model    = _build_l1_cnn(m_cfg, 'l2')
    elif model_type == 'l3':
        tr_cfg   = dict(tr_base['l3'])
        sigma    = tr_cfg.get('gaussian_sigma', cfg['simulation']['psf_sigma'])
        # 强制训练和验证都使用裁剪模式，防止 8GB 显存处理 1350x1350 全图时 OOM
        train_ds = L3Dataset(train_npz, sigma=sigma, is_train=True)
        val_ds   = L3Dataset(val_npz,   sigma=sigma, is_train=True)
        model    = L3_UNet(in_channels=m_cfg['l3']['in_channels'],
                           base_channels=m_cfg['l3']['base_channels'])
    else:
        raise ValueError(f'未知模型类型: {model_type}')

    if epochs_override:
        tr_cfg['epochs'] = epochs_override

    trainer = Trainer(model, train_ds, val_ds, tr_cfg,
                      str(ckpt_path), device,
                      model_type=model_type,
                      use_balanced_sampler=(model_type == 'l2'))
    best, _ = trainer.train()

    score_file.write_text(json.dumps({'best': best}))
    done_flag.touch()
    return best


# ─────────────────────────────────────────────────────────────
# Step 3: 整合系统评估
# ─────────────────────────────────────────────────────────────

@torch.no_grad()
def evaluate_system(cfg: dict, data_dir: Path, ckpt_dir: Path,
                    device: torch.device) -> dict:
    """
    v9.1 路由评估（原子保护 + L1 双端快速判决）：
      p_l1 > theta_h (0.95)            -> A-accept: L1 高置信直接接受（有原子）
      p_l1 < theta_l (0.05)            -> A-reject: L1 极低置信直接拒绝（确定无原子）
      theta_l <= p_l1 <= theta_h（模糊区间）:
        邻居压力 > nbr_thr             ->   串扰嫌疑:
          p_wide > theta_wide          ->     B-xtalk-accept: L1-Wide 确认接受
          p_wide <= theta_wide         ->     B-xtalk-l2: 降级 L2 终裁
        邻居压力 <= nbr_thr            ->   B-weak: 弱信号/背景/边界 -> L2 终裁
      注: theta_l 极低(0.05)，原子保护原则确保最小漏检(MDR)。
    """
    roi_n      = cfg['roi']['n']
    roi_n_wide = roi_n * cfg['roi']['k_wide']
    m_cfg      = cfg['model']
    r_cfg      = cfg['routing']
    theta_h    = r_cfg['theta_h']
    theta_l    = r_cfg.get('theta_l', 0.05)
    theta_wide = r_cfg.get('theta_wide', 0.90)
    nbr_thr    = r_cfg.get('neighbor_pressure_thr', theta_h)

    # ── 加载模型（含文件完整性检查）──────────────────────────────
    def load_model(mtype, arch):
        ckpt = ckpt_dir / f'{mtype}_best.pth'
        if not ckpt.exists():
            raise FileNotFoundError(
                f'[load_model] checkpoint not found: {ckpt}\n'
                f'  -> Please re-run training for model: {mtype}')
        if ckpt.stat().st_size < 256:
            raise RuntimeError(
                f'[load_model] checkpoint too small ({ckpt.stat().st_size} bytes), '
                f'likely corrupted: {ckpt}\n'
                f'  -> Delete and re-run training for model: {mtype}')
        try:
            arch.load_state_dict(torch.load(ckpt, map_location=device,
                                            weights_only=True))
        except EOFError:
            raise RuntimeError(
                f'[load_model] EOFError reading checkpoint: {ckpt}\n'
                f'  -> File corrupted (training interrupted).\n'
                f'  -> Fix: delete {ckpt} and re-run training for model: {mtype}')
        return arch.eval().to(device)

    model_l1      = load_model('l1',      _build_l1_cnn(m_cfg, 'l1'))
    model_l1_wide = load_model('l1_wide', _build_l1_cnn(m_cfg, 'l1_wide'))
    model_l2      = load_model('l2',      _build_l1_cnn(m_cfg, 'l2'))

    # ── 加载测试集 & 归一化基准 ──────────────────────────────────
    data    = np.load(str(data_dir / 'test.npz'),  allow_pickle=True)
    imgs_s  = data['images_short'].astype(np.float32)
    imgs_l  = data['images_long'].astype(np.float32)
    labels  = data['labels'].astype(np.int32)
    centers = data['centers']
    N, K    = labels.shape

    norm_path = data_dir / 'normalization.json'
    if norm_path.exists():
        ns = json.loads(norm_path.read_text())
        gmax_s, gmax_l = ns['gmax_s'], ns['gmax_l']
    else:
        tr = np.load(str(data_dir / 'train.npz'), allow_pickle=True)
        gmax_s = float(np.percentile(tr['images_short'][:20], 99.9)) + 1e-6
        gmax_l = float(np.percentile(tr['images_long'][:20],  99.9)) + 1e-6
        del tr
        norm_path.write_text(json.dumps({'gmax_s': gmax_s, 'gmax_l': gmax_l}, indent=2))
    print(f'  [归一化] gmax_s={gmax_s:.1f}  gmax_l={gmax_l:.1f}')

    # ── 推理辅助 ─────────────────────────────────────────────────
    def infer(model, roi):
        x = torch.from_numpy(roi).unsqueeze(0).unsqueeze(0).to(device)
        out = model(x)
        if out.dim() == 2 and out.shape[1] == 1:
            out = out.squeeze(1)
        return float(torch.sigmoid(out).item())

    def infer_l2(img_l, cy, cx):
        return infer(model_l2, _extract_roi(img_l, cy, cx, roi_n))

    # ── 邻居压力（L1.5 串扰判据）────────────────────────────────
    def _neighbor_pressure(all_p: np.ndarray, k: int) -> float:
        """返回格点 k 的 8-邻域 L1 概率最大值。"""
        n_atoms = all_p.shape[0]
        side = int(round(n_atoms ** 0.5))
        if side * side != n_atoms:
            return 0.0
        row, col = divmod(k, side)
        nbrs = []
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if dr == 0 and dc == 0:
                    continue
                nr, nc = row + dr, col + dc
                if 0 <= nr < side and 0 <= nc < side:
                    nbrs.append(float(all_p[nr * side + nc]))
        return max(nbrs) if nbrs else 0.0

    # ── 路由计数器（v9.1：L1 双端快速判决）──────────────────────
    cnt = {
        'l1_accept':         0,  # A-accept: p > theta_h
        'l1_reject':         0,  # A-reject: p < theta_l
        'xtalk_wide_accept': 0,  # B-xtalk-accept: L1-Wide 确认
        'xtalk_wide_to_l2':  0,  # B-xtalk-l2: L1-Wide 不确定 -> L2
        'weak_to_l2':        0,  # B-weak: 弱信号/背景/边界 -> L2
    }

    all_preds, all_gts = [], []
    records = []  # (p_l1, p_wide|None, p_l2|None, pred, gt, route)

    for i in range(N):
        img_s = imgs_s[i] / gmax_s
        img_l = imgs_l[i] / gmax_l

        # 批量计算本帧所有格点 L1 概率（供邻居压力使用）
        p_l1_all = np.array([
            infer(model_l1, _extract_roi(img_s, centers[k][0], centers[k][1], roi_n))
            for k in range(K)
        ], dtype=np.float32)

        for k in range(K):
            cy, cx = centers[k]
            gt     = int(labels[i, k])
            p_l1   = float(p_l1_all[k])
            p_wide = None
            p_l2   = None

            # ── 路径 A-accept: L1 高置信直接接受 ─────────────────
            if p_l1 > theta_h:
                pred  = 1
                route = 'A_l1_accept'
                cnt['l1_accept'] += 1

            # ── 路径 A-reject: L1 极低置信直接拒绝 ───────────────
            # theta_l=0.05 极低，仅极确信"无原子"时触发，防漏检
            elif p_l1 < theta_l:
                pred  = 0
                route = 'A_l1_reject'
                cnt['l1_reject'] += 1

            else:
                # ── 路径 B: L1.5 物理诊断（模糊区间）────────────
                p_nbr = _neighbor_pressure(p_l1_all, k)

                if p_nbr > nbr_thr:
                    # 串扰嫌疑：邻格有高置信原子
                    p_wide = infer(model_l1_wide,
                                   _extract_roi(img_s, cy, cx, roi_n_wide))
                    if p_wide > theta_wide:
                        pred  = 1
                        route = 'B_xtalk_wide_accept'
                        cnt['xtalk_wide_accept'] += 1
                    else:
                        # L1-Wide 不确定 -> 降级 L2 终裁
                        p_l2  = infer_l2(img_l, cy, cx)
                        pred  = 1 if p_l2 > 0.5 else 0
                        route = 'B_xtalk_to_l2'
                        cnt['xtalk_wide_to_l2'] += 1
                else:
                    # 弱信号 / 背景 / 边界 -> L2 终裁
                    p_l2  = infer_l2(img_l, cy, cx)
                    pred  = 1 if p_l2 > 0.5 else 0
                    route = 'B_weak_to_l2'
                    cnt['weak_to_l2'] += 1

            all_preds.append(pred)
            all_gts.append(gt)
            records.append((p_l1, p_wide, p_l2, pred, gt, route))

    preds = np.array(all_preds)
    gts   = np.array(all_gts)

    # ── 指标计算 ─────────────────────────────────────────────────
    neg          = gts == 0
    pos          = gts == 1
    far          = float((preds[neg] == 1).mean()) if neg.any() else 0.0
    mdr          = float((preds[pos] == 0).mean()) if pos.any() else 0.0
    atom_acc     = float((preds == gts).mean())
    frame_preds  = preds.reshape(N, K)
    frame_gts    = gts.reshape(N, K)
    atom_errors  = frame_preds != frame_gts
    frame_ok     = (~atom_errors).all(axis=1)
    fidelity     = float(frame_ok.mean())
    n_bad_frames = int((~frame_ok).sum())
    n_bad_atoms  = int(atom_errors.sum())

    # ── 失败案例库 ───────────────────────────────────────────────
    failure_dir  = ckpt_dir.parent / 'failure_cases'
    meta_list    = []
    per_site_err = atom_errors.mean(axis=0)
    worst_sites  = np.argsort(per_site_err)[-5:][::-1]

    if n_bad_atoms > 0:
        failure_dir.mkdir(exist_ok=True)
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            matplotlib.rcParams['font.family']        = 'DejaVu Sans'
            matplotlib.rcParams['axes.unicode_minus'] = False
            _has_mpl = True
        except ImportError:
            _has_mpl = False

        case_id = 0
        for fi in np.where(~frame_ok)[0]:
            for ak in np.where(atom_errors[fi])[0]:
                rp1, rpw, rp2, rpred, rgt, rroute = records[fi * K + ak]
                cy, cx = centers[ak]
                etype  = 'FA' if (rpred == 1 and rgt == 0) else 'MD'

                roi_s = _extract_roi(imgs_s[fi], cy, cx, roi_n)
                roi_l = _extract_roi(imgs_l[fi], cy, cx, roi_n)
                roi_w = _extract_roi(imgs_s[fi], cy, cx, roi_n_wide)

                meta = {
                    'case_id': case_id, 'error_type': etype,
                    'frame': int(fi),   'atom_k': int(ak),
                    'cy': float(cy),    'cx': float(cx),
                    'gt': int(rgt),     'pred': int(rpred),
                    'p_l1':   round(float(rp1), 6),
                    'p_wide': round(float(rpw), 6) if rpw is not None else None,
                    'p_l2':   round(float(rp2), 6) if rp2 is not None else None,
                    'route':  rroute,
                }
                meta_list.append(meta)

                np.savez_compressed(
                    failure_dir / f'case_{case_id:04d}_{etype}_f{fi:03d}_k{ak:03d}.npz',
                    roi_short=roi_s, roi_long=roi_l, roi_wide=roi_w,
                    meta=np.array([meta], dtype=object))

                if _has_mpl:
                    fig, axes = plt.subplots(1, 3, figsize=(9, 3))
                    for ax, arr, title in zip(
                            axes, [roi_s, roi_w, roi_l],
                            ['L1 ROI (Short)', 'L1-Wide ROI', 'L2 ROI (Long)']):
                        ax.imshow(arr, cmap='inferno', interpolation='nearest')
                        ax.set_title(title, fontsize=9)
                        ax.axis('off')
                    pw_s = f'{rpw:.4f}' if rpw is not None else 'N/A'
                    p2_s = f'{rp2:.4f}' if rp2 is not None else 'N/A'
                    fig.suptitle(
                        f'[{etype}] Frame#{fi:03d} Atom#{ak:03d}'
                        f'  gt={rgt} pred={rpred}\n'
                        f'p_l1={rp1:.4f}  p_wide={pw_s}  p_l2={p2_s}'
                        f'  route={rroute}',
                        fontsize=8)
                    plt.tight_layout()
                    plt.savefig(
                        failure_dir / f'case_{case_id:04d}_{etype}_f{fi:03d}_k{ak:03d}.png',
                        dpi=120, bbox_inches='tight')
                    plt.close(fig)
                case_id += 1

        (failure_dir / 'failure_summary.json').write_text(
            json.dumps({'n_bad_frames': n_bad_frames, 'n_bad_atoms': n_bad_atoms,
                        'atom_accuracy': atom_acc,
                        'worst_sites': worst_sites.tolist(),
                        'cases': meta_list},
                       indent=2, ensure_ascii=False))

    # ── 诊断打印 ─────────────────────────────────────────────────
    print(f'\n  [原子级] 准确率={atom_acc:.6f}  '
          f'错误格点={n_bad_atoms}/{N*K}  失败帧={n_bad_frames}/{N}')
    if n_bad_atoms > 0:
        for si in worst_sites:
            if per_site_err[si] > 0:
                print(f'    格点#{si:03d}: {per_site_err[si]:.4%}  '
                      f'(y={centers[si][0]:.0f} x={centers[si][1]:.0f})')
        print(f'  [失败案例库] -> {failure_dir}  ({len(meta_list)} 条)')
        for fi in np.where(~frame_ok)[0][:5]:
            for ak in np.where(atom_errors[fi])[0][:5]:
                rp1, rpw, rp2, rpred, rgt, rroute = records[fi * K + ak]
                etype  = 'FA(误报)' if (rpred == 1 and rgt == 0) else 'MD(漏检)'
                pw_str = f'{rpw:.4f}' if rpw is not None else 'N/A'
                p2_str = f'{rp2:.4f}' if rp2 is not None else 'N/A'
                print(f'    帧#{fi:03d} 格点#{ak:03d} [{etype}]'
                      f'  p_l1={rp1:.4f}  p_wide={pw_str}  p_l2={p2_str}'
                      f'  route={rroute}')
    else:
        print('  [诊断] 所有帧完全正确，无失败案例 ✓')

    # ── 路由统计 ─────────────────────────────────────────────────
    total      = N * K
    n_l2_total = cnt['xtalk_wide_to_l2'] + cnt['weak_to_l2']
    routing    = {
        'l1_accept':         cnt['l1_accept'],
        'l1_reject':         cnt['l1_reject'],
        'xtalk_wide_accept': cnt['xtalk_wide_accept'],
        'xtalk_wide_to_l2':  cnt['xtalk_wide_to_l2'],
        'weak_to_l2':        cnt['weak_to_l2'],
        'l2_total':          n_l2_total,
        'l2_total_pct':      n_l2_total / total,
    }

    print('\n  ┌────────────────────────────────────────┬────────┬────────┐')
    print(  '  │ 路由路径 (v9.1 L1双端快速判决)          │   数量 │   占比 │')
    print(  '  ├────────────────────────────────────────┼────────┼────────┤')
    for name, n in [
        ('A-accept  L1 直接接受 (p > theta_h)',    cnt['l1_accept']),
        ('A-reject  L1 直接拒绝 (p < theta_l)',    cnt['l1_reject']),
        ('B-xtalk-accept  L1-Wide 确认接受',        cnt['xtalk_wide_accept']),
        ('B-xtalk-l2      L1-Wide 不确定->L2',      cnt['xtalk_wide_to_l2']),
        ('B-weak          弱信号/背景/边界->L2',     cnt['weak_to_l2']),
    ]:
        print(f'  │ {name:<38} │ {n:>6} │ {n/total:>6.1%} │')
    print(  '  ├────────────────────────────────────────┼────────┼────────┤')
    print(f'  │ {"L2 终裁总量 (模糊区唯一无原子出口)":<38} │ {n_l2_total:>6} │ {n_l2_total/total:>6.1%} │')
    print(f'  │ {"总计":<38} │ {total:>6} │ {"100.0%":>6} │')
    print(  '  └────────────────────────────────────────┴────────┴────────┘')

    return {
        'fidelity':      fidelity,
        'far':           far,
        'mdr':           mdr,
        'atom_accuracy': atom_acc,
        'n_bad_frames':  n_bad_frames,
        'n_bad_atoms':   n_bad_atoms,
        'l2_rate':       routing['l2_total_pct'],
        'routing':       routing,
    }


# ─────────────────────────────────────────────────────────────
# 主搜索循环
# ─────────────────────────────────────────────────────────────

def passes(metrics: dict, targets: dict) -> bool:
    return (metrics['fidelity'] >= targets['fidelity'] and
            metrics['far']      <= targets['far']      and
            metrics['mdr']      <= targets['mdr'])


def run_point(t_ms: float, cfg: dict, device: torch.device,
              args, targets: dict) -> dict:
    """
    对单个曝光时间点执行完整流程，返回结果字典。

    自动复用逻辑：
      - 数据集已存在（.done 标志）→ 跳过数据生成
      - 模型已存在（.done + .pth）→ 跳过训练
      - 始终重新执行评估（Step 3）
      --resume: 仅跳过已通过指标的点（pass=True），对未通过或缺失的点仍重新评估
    """
    t_l1        = t_ms / 1000.0
    point_dir   = SEARCH_DIR / tag(t_ms)
    data_dir    = point_dir / 'data'
    ckpt_dir    = point_dir / 'checkpoints'
    result_file = point_dir / 'result.json'

    # --resume: 仅跳过已通过的点，未通过或缺失的点强制重新评估
    if args.resume and result_file.exists():
        try:
            r = json.loads(result_file.read_text())
            if r.get('pass', False):
                ok = '✓'
                print(f'  [跳过-已通过] t={t_ms:.2f}ms  '
                      f"fidelity={r['system']['fidelity']:.4f}  "
                      f"FAR={r['system']['far']:.6f}  "
                      f"MDR={r['system']['mdr']:.6f}  {ok}")
                return r
        except Exception:
            pass  # result.json 损坏，继续重新评估

    hline('─')
    print(f'\n▶ 评估曝光时间: t_l1={t_ms:.2f}ms  t_l2={t_ms*2:.2f}ms')
    t0 = time.time()

    # Step 1: 数据生成（有 .done 标志则自动跳过）
    print('\n[1/3] 生成仿真数据集...')
    generate_dataset(cfg, t_l1, data_dir,
                     n_train=args.n_train, n_val=args.n_val, n_test=args.n_test)

    # Step 2: 模型训练（有 .done + .pth 则自动跳过）
    print('\n[2/3] 训练模型...')
    scores = {}
    for mtype in ['l1', 'l1_wide', 'l2', 'l3']:
        print(f'\n  ── {mtype.upper()} ──')
        scores[mtype] = train_one(mtype, cfg, data_dir, ckpt_dir, device,
                                  epochs_override=args.epochs)
        print(f'  {mtype.upper()} 完成, score={scores[mtype]:.4f}')

    print('\n[3/3] 整合系统评估...')
    try:
        sys_metrics = evaluate_system(cfg, data_dir, ckpt_dir, device)
    except (EOFError, RuntimeError) as e:
        msg = str(e)
        if 'EOFError' in msg or 'corrupted' in msg or 'too small' in msg:
            print(f'\n  [错误] Checkpoint 文件损坏，自动清理...')
            cleaned = []
            for pth in ckpt_dir.glob('*.pth'):
                if pth.stat().st_size < 256:
                    pth.unlink()
                    cleaned.append(pth.name)
            if cleaned:
                print(f'  [清理] 已删除损坏文件: {cleaned}')
                print(f'  [提示] 请重新运行 auto_search.py，将自动重训所有子模型。')
            else:
                print(f'  [提示] 未找到明显损坏文件，请手动删除 {ckpt_dir} 中全部 .pth 文件后重跑。')
        else:
            import traceback; traceback.print_exc()
            print(f'  [警告] 整合评估失败: {e}')
        sys_metrics = {'fidelity': 0.0, 'far': 1.0, 'mdr': 1.0,
                       'atom_accuracy': 0.0, 'n_bad_frames': -1, 'n_bad_atoms': -1,
                       'l2_rate': 0.0, 'routing': {}}
    except Exception as e:
        import traceback; traceback.print_exc()
        print(f'  [警告] 整合评估失败 (未知异常): {e}')
        sys_metrics = {'fidelity': 0.0, 'far': 1.0, 'mdr': 1.0,
                       'atom_accuracy': 0.0, 'n_bad_frames': -1, 'n_bad_atoms': -1,
                       'l2_rate': 0.0, 'routing': {}}

    elapsed = time.time() - t0
    ok      = passes(sys_metrics, targets)
    result  = {
        't_l1_ms':   t_ms,
        't_l2_ms':   t_ms * 3,
        'scores':    scores,
        'system':    sys_metrics,
        'pass':      ok,
        'elapsed_s': round(elapsed, 1),
    }
    point_dir.mkdir(parents=True, exist_ok=True)
    result_file.write_text(json.dumps(result, indent=2))

    flag = '✓ 通过' if ok else '✗ 未通过'
    print(f'\n  结果: fidelity={sys_metrics["fidelity"]:.4f}  '
          f"FAR={sys_metrics['far']:.6f}  MDR={sys_metrics['mdr']:.6f}  "
          f"L2路由率={sys_metrics['l2_rate']:.1%}  {flag}")
    print(f'  耗时: {elapsed/60:.1f} 分钟')
    return result


# ─────────────────────────────────────────────────────────────
# 结果绘图
# ─────────────────────────────────────────────────────────────

def plot_summary(all_results: list, targets: dict, save_path: Path):
    try:
        import matplotlib
        matplotlib.use('Agg')           # 无显示器后端，避免字体问题
        import matplotlib.pyplot as plt
        matplotlib.rcParams['font.family']        = 'DejaVu Sans'
        matplotlib.rcParams['axes.unicode_minus'] = False

        ts   = [r['t_l1_ms']              for r in all_results]
        fids = [r['system']['fidelity']   for r in all_results]
        fars = [r['system']['far']        for r in all_results]
        mdrs = [r['system']['mdr']        for r in all_results]
        l2rs = [r['system']['l2_rate']    for r in all_results]

        fig, axes = plt.subplots(2, 2, figsize=(12, 8))
        fig.suptitle('PA-3HDA Auto Exposure Search Results', fontsize=13)
        for ax, vals, thr, name, op, color in [
            (axes[0,0], fids, targets['fidelity'], 'Fidelity', '>=', 'tab:blue'),
            (axes[0,1], fars, targets['far'],       'FAR',      '<=', 'tab:orange'),
            (axes[1,0], mdrs, targets['mdr'],       'MDR',      '<=', 'tab:red'),
            (axes[1,1], l2rs, None,                 'L2 Rate',  None, 'tab:purple'),
        ]:
            ax.plot(ts, vals, 'o-', color=color, linewidth=2)
            if thr is not None:
                ax.axhline(thr, color='gray', linestyle='--',
                           label=f'Target {op}{thr}')
                ax.legend(fontsize=8)
            ax.set_xlabel('L1 Exposure (ms)')
            ax.set_ylabel(name)
            ax.set_title(name)
            ax.grid(True, alpha=0.3)
        for r in all_results:
            c = 'green' if r['pass'] else 'red'
            for ax in axes.flat[:3]:
                ax.axvline(r['t_l1_ms'], color=c, alpha=0.15, linewidth=8)

        plt.tight_layout()
        save_path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f'\n[plot] saved: {save_path}')
        plt.close()
    except Exception as e:
        print(f'[warning] plot failed: {e}')


# ─────────────────────────────────────────────────────────────
# 入口
# ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='PA-3HDA 一键曝光时间搜索')
    parser.add_argument('--config',    default='configs/default.yaml')
    parser.add_argument('--fidelity',  type=float, default=0.999)
    parser.add_argument('--far',       type=float, default=0.001)
    parser.add_argument('--mdr',       type=float, default=0.001)
    parser.add_argument('--t-start',   type=float, default=20.0,  help='起始 L1 曝光时间 (ms)')
    parser.add_argument('--t-min',     type=float, default=2.0,   help='搜索下界 (ms)')
    parser.add_argument('--max-iters', type=int,   default=8,     help='最大二分迭代次数')
    parser.add_argument('--n-train',   type=int,   default=400)
    parser.add_argument('--n-val',     type=int,   default=100)
    parser.add_argument('--n-test',    type=int,   default=100)
    parser.add_argument('--epochs',    type=int,   default=None,  help='覆盖训练 epoch 数')
    parser.add_argument('--resume',    action='store_true',
                        help='跳过已通过(pass=True)的点，对未通过或缺失的点重新评估')
    parser.add_argument('--clean',     action='store_true',       help='清除所有结果重新开始')
    args = parser.parse_args()

    if args.clean and SEARCH_DIR.exists():
        shutil.rmtree(SEARCH_DIR)
        print(f'[清理] 已删除 {SEARCH_DIR}')

    SEARCH_DIR.mkdir(parents=True, exist_ok=True)
    _log_fh = _start_tee(SEARCH_DIR / 'run.log')
    print(f'[日志] 输出同步写入: {SEARCH_DIR / "run.log"}')
    try:
        _run(args)
    finally:
        _stop_tee(_log_fh)


def _run(args):
    cfg     = load_cfg(args.config)
    device  = get_device()
    targets = {'fidelity': args.fidelity, 'far': args.far, 'mdr': args.mdr}

    hline('═')
    print('  PA-3HDA 自动曝光时间搜索')
    hline('═')
    print(f'  目标: Fidelity>={args.fidelity}  FAR<={args.far}  MDR<={args.mdr}')
    print(f'  搜索范围: [{args.t_min}ms, {args.t_start}ms]  最大迭代: {args.max_iters}')
    print(f'  每点数据: train={args.n_train} val={args.n_val} test={args.n_test} 帧')
    print(f'  结果目录: {SEARCH_DIR}')
    hline('═')

    all_results = []
    t_lo = args.t_min
    t_hi = args.t_start

    # ── 验证起始点 ──
    print('\n[初始化] 验证起始点...')
    r_start = run_point(args.t_start, cfg, device, args, targets)
    all_results.append(r_start)
    if not r_start['pass']:
        print(f'\n[错误] 起始点 {args.t_start}ms 就无法满足指标！')
        print('建议: 增大 --t-start，或降低目标指标。')
        return

    # ── 二分搜索 ──
    print(f'\n开始二分搜索: [{t_lo:.2f}ms, {t_hi:.2f}ms]')
    for i in range(args.max_iters):
        if t_hi - t_lo < 0.5:
            print('\n[收敛] 区间宽度 < 0.5ms，停止搜索')
            break
        t_mid = (t_lo + t_hi) / 2.0
        print(f'\n=== 二分第 {i+1}/{args.max_iters} 轮 '
              f'| [{t_lo:.2f}, {t_hi:.2f}ms] | 候选 {t_mid:.2f}ms ===')
        r = run_point(t_mid, cfg, device, args, targets)
        all_results.append(r)
        if r['pass']:
            t_hi = t_mid
            print(f'  ↓ 通过，新上界 t_hi={t_hi:.2f}ms')
        else:
            t_lo = t_mid
            print(f'  ↑ 未通过，新下界 t_lo={t_lo:.2f}ms')

    # ── 最终结果 ──
    t_recommend = t_hi * 1.15
    hline('═')
    print('\n  ★ 搜索完成 ★')
    hline('═')
    print(f'  实测最短曝光 (L1): {t_hi:.2f} ms  L2: {t_hi*2:.2f} ms')
    print(f'  建议值 (x1.15裕量): {t_recommend:.2f} ms  /  {t_recommend*2:.2f} ms')
    print(f'\n  {"t_l1(ms)":>10}  {"Fidelity":>10}  {"FAR":>12}  '
          f'{"MDR":>12}  {"L2率":>6}  {"结果":>4}')
    print('  ' + '─' * 62)
    for r in sorted(all_results, key=lambda x: x['t_l1_ms']):
        s  = r['system']
        ok = '✓' if r['pass'] else '✗'
        print(f"  {r['t_l1_ms']:>10.2f}  {s['fidelity']:>10.4f}  "
              f"{s['far']:>12.6f}  {s['mdr']:>12.6f}  "
              f"{s['l2_rate']:>6.1%}  {ok:>4}")
    hline('═')

    summary = {
        't_min_ms':       t_hi,
        't_l2_min_ms':    t_hi * 2,
        't_recommend_ms': t_recommend,
        'targets':        targets,
        'all_results':    all_results,
    }
    sp = SEARCH_DIR / 'summary.json'
    sp.write_text(json.dumps(summary, indent=2))
    print(f'\n[保存] 汇总结果: {sp}')

    plot_summary(sorted(all_results, key=lambda x: x['t_l1_ms']),
                 targets, SEARCH_DIR / 'search_curve.png')

    print(f'\n是否将建议值写回 {args.config}？(y/n): ', end='', flush=True)
    try:
        ans = input().strip().lower()
    except Exception:
        ans = 'n'
    if ans == 'y':
        cfg['simulation']['exposure_time_l1'] = round(t_recommend / 1000, 4)
        cfg['simulation']['exposure_time_l2'] = round(t_recommend * 2 / 1000, 4)
        with open(args.config, 'w', encoding='utf-8') as f:
            yaml.dump(cfg, f, allow_unicode=True, sort_keys=False)
        print(f'[写回] exposure_time_l1={t_recommend/1000:.4f}s')


if __name__ == '__main__':
    main()
