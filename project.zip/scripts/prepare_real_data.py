"""
PA3HDA_v4/scripts/prepare_real_data.py
========================================
真实数据预处理脚本（重构版）

数据组织逻辑
------------
同一组（如 data/1/）的6档曝光共享一套 Ground Truth（全档叠加推断）。
数据集按曝光时间分目录存储，训练/验证/测试的组编号划分在所有曝光时间
目录中完全一致，不同曝光时间之间不混用同一split文件。

输出目录结构
-----------
  datasets/real_v1/
    split.json              # 全局组编号划分（train/val/test）
    metadata.json           # 每组原子数等统计信息
    gt/                     # 每组的 GT（labels + centers），共1001个
      group_0001.npz
      group_0010.npz
      ...
    8ms/
      train.npz  val.npz  test.npz
    10ms/
      train.npz  val.npz  test.npz
    20ms/  40ms/  80ms/  160ms/  （同上）

每个曝光时间的 split NPZ 格式
-----------------------------
  images   : [N, H, W]  float32  — 当前曝光档位图像
  labels   : [N, K]     int32    — GT标签（K = n_rows × n_cols）
  centers  : [N, K, 2]  float32  — 格点中心 (y, x)
  group_ids: [N]        int32    — 对应组编号，便于追溯

用法
----
  python scripts/prepare_real_data.py \\
      --data-root D:/data \\
      --output-dir PA3HDA_v4/data/datasets/real_v1 \\
      --config     PA3HDA_v4/configs/default.yaml \\
      --val-ratio  0.1 \\
      --test-ratio 0.1 \\
      --seed       42
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import yaml
from PIL import Image

# ── 支持的曝光档位 ─────────────────────────────────────────────────────────────
EXPOSURES = [8, 10, 20, 40, 80, 160]


# ══════════════════════════════════════════════════════════════════════════════
# 底层 I/O
# ══════════════════════════════════════════════════════════════════════════════

def _load_tif(folder: Path, exp: int) -> Optional[np.ndarray]:
    """
    从 {folder}/{exp}ms/0001.tif 读取图像。

    目录结构固定为：
      {group_id}/{exp}ms/0001.tif
    例如：
      1/8ms/0001.tif
      1001/160ms/0001.tif
    """
    tif_path = folder / f"{exp}ms" / "0001.tif"
    if not tif_path.exists():
        return None
    try:
        img = Image.open(tif_path)
        return np.array(img).astype(np.float32)
    except Exception as e:
        print(f"  [警告] 读取 {tif_path} 失败: {e}")
        return None


def _find_groups(data_root: Path) -> List[int]:
    """返回排序后的全部组编号。"""
    return sorted(
        int(d.name) for d in data_root.iterdir()
        if d.is_dir() and d.name.isdigit()
    )


# ══════════════════════════════════════════════════════════════════════════════
# Ground Truth 计算
# ══════════════════════════════════════════════════════════════════════════════

def _auto_offset(stacked: np.ndarray, spacing: int) -> Tuple[int, int]:
    """用全图最亮点推算格点偏移量。"""
    y_max, x_max = np.unravel_index(np.argmax(stacked), stacked.shape)
    return int(y_max % spacing), int(x_max % spacing)


def compute_gt(group_dir: Path,
               n_rows: int, n_cols: int, spacing: int,
               sigma_thr: float = 5.0) -> Optional[Dict]:
    """
    计算单组 Ground Truth。

    Strategy
    --------
    将该组所有可用曝光档位叠加，在叠加图上做格点级峰值检测，
    阈值 = 背景中值 + sigma_thr × 背景标准差。

    Returns
    -------
    dict with keys:
      labels  : [n_rows, n_cols]  int32
      centers : [K, 2]            float32  (y, x) of each lattice site
      offset  : (offset_y, offset_x)
      n_atoms : int
    or None if no images found.
    """
    stacked: Optional[np.ndarray] = None
    for exp in EXPOSURES:
        img = _load_tif(group_dir, exp)
        if img is not None:
            stacked = img if stacked is None else stacked + img

    if stacked is None:
        return None

    off_y, off_x = _auto_offset(stacked, spacing)
    bg  = np.median(stacked)
    std = float(np.std(stacked - bg)) + 1e-6

    labels  = np.zeros((n_rows, n_cols), dtype=np.int32)
    centers = np.zeros((n_rows * n_cols, 2), dtype=np.float32)

    H, W = stacked.shape
    k = 0
    for r in range(n_rows):
        for c in range(n_cols):
            yc = off_y + r * spacing
            xc = off_x + c * spacing
            centers[k] = [yc, xc]
            if 0 <= yc < H and 0 <= xc < W:
                roi = stacked[max(0, yc-2):yc+3, max(0, xc-2):xc+3]
                if float(np.mean(roi)) - bg > sigma_thr * std:
                    labels[r, c] = 1
            k += 1

    return {
        "labels":  labels,
        "centers": centers,
        "offset":  (off_y, off_x),
        "n_atoms": int(np.sum(labels)),
    }


# ══════════════════════════════════════════════════════════════════════════════
# 数据集划分
# ══════════════════════════════════════════════════════════════════════════════

def make_split(group_ids: List[int],
               val_ratio: float = 0.1,
               test_ratio: float = 0.1,
               seed: int = 42) -> Dict[str, List[int]]:
    """
    按组编号做随机划分，返回 {'train': [...], 'val': [...], 'test': [...]}.
    同一组的所有曝光档位划分结果完全一致。
    """
    ids = np.array(sorted(group_ids))
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(ids))

    n_test = max(1, int(len(ids) * test_ratio))
    n_val  = max(1, int(len(ids) * val_ratio))
    n_train = len(ids) - n_val - n_test

    train_ids = sorted(ids[perm[:n_train]].tolist())
    val_ids   = sorted(ids[perm[n_train:n_train+n_val]].tolist())
    test_ids  = sorted(ids[perm[n_train+n_val:]].tolist())

    return {"train": train_ids, "val": val_ids, "test": test_ids}


# ══════════════════════════════════════════════════════════════════════════════
# 单曝光档位 NPZ 生成
# ══════════════════════════════════════════════════════════════════════════════

def build_exposure_split(
    exp: int,
    group_ids: List[int],
    data_root: Path,
    gt_cache: Dict[int, Dict],
    out_dir: Path,
    split_name: str,          # 'train' / 'val' / 'test'
) -> int:
    """
    为指定曝光档位的一个 split 构建 NPZ。

    只使用 group_ids 中的组、只读取 exp ms 的图像，
    GT labels 来自 gt_cache（由全档叠加计算，共享）。

    Returns
    -------
    实际写入的有效样本数（部分组可能缺少该档位图像）。
    """
    images_list  = []
    labels_list  = []
    centers_list = []
    gids_list    = []

    for gid in group_ids:
        gt = gt_cache.get(gid)
        if gt is None:
            continue                          # 该组无 GT（全档图像均缺失）

        img = _load_tif(data_root / str(gid), exp)
        if img is None:
            # 该组缺少此曝光档位，跳过（不影响其他档位）
            continue

        images_list.append(img)
        labels_list.append(gt["labels"].flatten().astype(np.int32))
        centers_list.append(gt["centers"].astype(np.float32))
        gids_list.append(gid)

    if not images_list:
        print(f"  [跳过] {exp}ms / {split_name}：无有效样本")
        return 0

    out_dir.mkdir(parents=True, exist_ok=True)
    save_path = out_dir / f"{split_name}.npz"

    np.savez_compressed(
        save_path,
        images   = np.stack(images_list),    # [N, H, W]
        labels   = np.stack(labels_list),    # [N, K]
        centers  = np.stack(centers_list),   # [N, K, 2]
        group_ids= np.array(gids_list, dtype=np.int32),  # [N]
    )
    print(f"  [写入] {save_path}  ({len(images_list)} 组)")
    return len(images_list)


# ══════════════════════════════════════════════════════════════════════════════
# 主流程
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="PA-3HDA Real Data Preprocessor  "
                    "(GT共享，按曝光时间分目录，组级划分一致)"
    )
    parser.add_argument("--data-root",   default="D:/data",
                        help="真实数据根目录（含 1/, 2/, ... 子目录）")
    parser.add_argument("--output-dir",  default="PA3HDA_v4/data/datasets/real_v1",
                        help="输出数据集根目录")
    parser.add_argument("--config",      default="PA3HDA_v4/configs/default.yaml",
                        help="配置文件路径")
    parser.add_argument("--val-ratio",   type=float, default=0.1,
                        help="验证集比例（默认 10%%）")
    parser.add_argument("--test-ratio",  type=float, default=0.1,
                        help="测试集比例（默认 10%%）")
    parser.add_argument("--seed",        type=int,   default=42,
                        help="随机种子（保证可复现）")
    parser.add_argument("--sigma-thr",   type=float, default=5.0,
                        help="GT 推断信噪比阈值（默认 5.0σ）")
    parser.add_argument("--exposures",   nargs="+",  type=int,
                        default=EXPOSURES,
                        help="要处理的曝光档位列表（默认 8 10 20 40 80 160）")
    parser.add_argument("--force-gt",    action="store_true",
                        help="强制重新计算 GT（忽略已有缓存）")
    args = parser.parse_args()

    # ── 1. 加载配置 ────────────────────────────────────────────────────────────
    with open(args.config) as f:
        cfg = yaml.safe_load(f)

    n_rows  = cfg["array"]["n_rows"]
    n_cols  = cfg["array"]["n_cols"]
    spacing = cfg["array"]["grid_spacing"]

    data_root  = Path(args.data_root)
    output_dir = Path(args.output_dir)
    gt_dir     = output_dir / "gt"

    if not data_root.exists():
        sys.exit(f"[错误] 数据根目录不存在: {data_root}")

    # ── 2. 发现所有组 ──────────────────────────────────────────────────────────
    all_groups = _find_groups(data_root)
    if not all_groups:
        sys.exit(f"[错误] 在 {data_root} 下未找到数字命名的组目录。")
    print(f"[发现] 共 {len(all_groups)} 组: {all_groups[0]} ~ {all_groups[-1]}")

    # ── 3. 计算或加载 GT ───────────────────────────────────────────────────────
    gt_dir.mkdir(parents=True, exist_ok=True)
    gt_cache: Dict[int, Dict] = {}
    metadata = []

    print("\n[阶段1] 计算 Ground Truth（全档叠加）...")
    for gid in all_groups:
        gt_path = gt_dir / f"group_{gid:04d}.npz"

        # 读缓存
        if gt_path.exists() and not args.force_gt:
            d = np.load(gt_path, allow_pickle=True)
            gt_cache[gid] = {
                "labels":  d["labels"],
                "centers": d["centers"],
                "offset":  tuple(d["offset"].tolist()),
                "n_atoms": int(d["n_atoms"]),
            }
            continue

        # 重新计算
        gt = compute_gt(data_root / str(gid), n_rows, n_cols,
                        spacing, args.sigma_thr)
        if gt is None:
            print(f"  [跳过] 组 {gid}：无可用图像")
            continue

        np.savez_compressed(
            gt_path,
            labels  = gt["labels"],
            centers = gt["centers"],
            offset  = np.array(gt["offset"], dtype=np.int32),
            n_atoms = np.array(gt["n_atoms"], dtype=np.int32),
        )
        gt_cache[gid] = gt

    for gid in sorted(gt_cache.keys()):
        metadata.append({
            "group_id": gid,
            "n_atoms":  gt_cache[gid]["n_atoms"],
        })

    print(f"  GT 完成: {len(gt_cache)}/{len(all_groups)} 组有效")

    # ── 4. 固定 train/val/test 组编号划分 ──────────────────────────────────────
    valid_groups = sorted(gt_cache.keys())
    split = make_split(valid_groups, args.val_ratio, args.test_ratio, args.seed)

    split_path = output_dir / "split.json"
    output_dir.mkdir(parents=True, exist_ok=True)
    with open(split_path, "w") as f:
        json.dump(split, f, indent=2)

    print(f"\n[阶段2] 组编号划分 -> {split_path}")
    print(f"  train={len(split['train'])}  val={len(split['val'])}"
          f"  test={len(split['test'])}")

    # ── 5. 按曝光档位逐一生成 NPZ ──────────────────────────────────────────────
    print("\n[阶段3] 按曝光档位生成数据集...")
    stats = {}
    for exp in args.exposures:
        exp_dir = output_dir / f"{exp}ms"
        print(f"\n  ── {exp}ms ──")
        cnts = {}
        for split_name, group_ids in split.items():
            cnts[split_name] = build_exposure_split(
                exp, group_ids, data_root, gt_cache, exp_dir, split_name
            )
        stats[f"{exp}ms"] = cnts

    # ── 6. 保存 metadata & 统计 ────────────────────────────────────────────────
    meta_path = output_dir / "metadata.json"
    with open(meta_path, "w") as f:
        json.dump({
            "n_groups":    len(valid_groups),
            "n_rows":      n_rows,
            "n_cols":      n_cols,
            "spacing":     spacing,
            "sigma_thr":   args.sigma_thr,
            "split_seed":  args.seed,
            "exposures":   args.exposures,
            "split_counts": stats,
            "groups":      metadata,
        }, f, indent=2)

    # ── 7. 打印汇总 ────────────────────────────────────────────────────────────
    print("\n" + "═" * 60)
    print("  数据集制作完成")
    print(f"  输出目录: {output_dir.resolve()}")
    print("  各曝光档位样本数（train / val / test）：")
    for exp_key, cnts in stats.items():
        print(f"    {exp_key:>6s}:  "
              f"train={cnts.get('train',0):4d}  "
              f"val={cnts.get('val',0):4d}  "
              f"test={cnts.get('test',0):4d}")
    print(f"\n  split.json   -> {split_path}")
    print(f"  metadata.json-> {meta_path}")
    print("═" * 60)


if __name__ == "__main__":
    main()
