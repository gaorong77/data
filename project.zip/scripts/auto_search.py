"""
scripts/auto_search.py
PA-3HDA 一键自适应最短曝光时间搜索

流程：
  1. 验证起始曝光时间（默认 20ms）能否通过指标
  2. 二分递减搜索满足所有指标的最短曝光时间
  3. 每个候选点：生成数据 → 训练4个模型 → 整合评估

用法：
  python scripts/auto_search.py
  python scripts/auto_search.py --fidelity 0.999 --far 0.001 --mdr 0.001
  python scripts/auto_search.py --t-start 20 --t-min 2 --max-iters 8
  python scripts/auto_search.py --resume      # 跳过已通过的点继续搜索
  python scripts/auto_search.py --clean       # 清空结果重新开始
"""

import argparse
import json
import shutil
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import yaml

# ── 从拆分子模块导入所有功能 ──────────────────────────────────
from search import (
    start_tee, stop_tee,
    tag, load_cfg, get_device, hline, passes,
    generate_dataset,
    train_one,
    evaluate_system,
    plot_summary,
)

SEARCH_DIR = ROOT / 'search_results'


# ─────────────────────────────────────────────────────────────
# 单点完整流程
# ─────────────────────────────────────────────────────────────

def run_point(t_ms: float, cfg: dict, device, args, targets: dict) -> dict:
    """
    对单个曝光时间候选点执行：数据生成 → 模型训练 → 系统评估。

    自动复用逻辑
    ------------
    - 数据集已存在（.done 标志） → 跳过生成
    - 模型已训练（.done + .pth） → 跳过训练
    - 评估始终重新执行
    - --resume：仅跳过已 pass=True 的点
    """
    t_l1        = t_ms / 1000.0
    l2_mult     = cfg['simulation'].get('l2_multiplier', 3.0)
    point_dir   = SEARCH_DIR / tag(t_ms)
    data_dir    = point_dir / 'data'
    ckpt_dir    = point_dir / 'checkpoints'
    result_file = point_dir / 'result.json'

    # --resume：已通过的点直接跳过
    if args.resume and result_file.exists():
        try:
            r = json.loads(result_file.read_text())
            if r.get('pass', False):
                s = r['system']
                print(f'  [跳过-已通过] t={t_ms:.2f}ms  '
                      f"fidelity={s['fidelity']:.4f}  "
                      f"FAR={s['far']:.6f}  MDR={s['mdr']:.6f}  ✓")
                return r
        except Exception:
            pass  # result.json 损坏，继续重新评估

    hline('─')
    l2_mult = cfg['simulation'].get('l2_multiplier', 3.0)
    print(f'\n▶ 评估 t_l1={t_ms:.2f}ms  t_l2={t_ms*l2_mult:.2f}ms  (x{l2_mult})')
    t0 = time.time()

    # Step 1: 数据生成
    print('\n[1/3] 生成仿真数据集...')
    generate_dataset(cfg, t_l1, data_dir,
                     n_train=args.n_train, n_val=args.n_val, n_test=args.n_test)

    # Step 2: 模型训练
    print('\n[2/3] 训练模型...')
    scores = {}
    for mtype in ['l1', 'l1_wide', 'l2', 'l3']:
        print(f'\n  ── 训练 {mtype.upper()} 模型...')
        scores[mtype] = train_one(mtype, cfg, data_dir, ckpt_dir, device,
                                  epochs_override=args.epochs)
        print(f'  {mtype.upper()} 完成, score={scores[mtype]:.4f}')

    # Step 3: 系统评估
    print('\n[3/3] 整合系统评估...')
    try:
        sys_metrics = evaluate_system(cfg, data_dir, ckpt_dir, device)
    except (EOFError, RuntimeError) as e:
        msg = str(e)
        print(f'\n  [错误] {msg}')
        if 'corrupted' in msg or 'too small' in msg or 'EOFError' in msg:
            cleaned = [p.name for p in ckpt_dir.glob('*.pth')
                       if p.stat().st_size < 256]
            for name in cleaned:
                (ckpt_dir / name).unlink()
            print(f'  [清理] 已删除损坏文件: {cleaned or "无"}')
            print('  [提示] 请重新运行 auto_search.py，将自动重训所有子模型。')
        sys_metrics = _empty_metrics()
    except Exception as e:
        traceback.print_exc()
        print(f'  [警告] 评估失败（未知异常）: {e}')
        sys_metrics = _empty_metrics()

    elapsed = time.time() - t0
    ok      = passes(sys_metrics, targets)
    result  = {
        't_l1_ms':   t_ms,
        't_l2_ms':   t_ms * l2_mult,
        'scores':    scores,
        'system':    sys_metrics,
        'pass':      ok,
        'elapsed_s': round(elapsed, 1),
    }
    point_dir.mkdir(parents=True, exist_ok=True)
    result_file.write_text(json.dumps(result, indent=2))

    flag = '✓ 通过' if ok else '✗ 未通过'
    print(f'\n  结果: fidelity={sys_metrics["fidelity"]:.4f}  '
          f"FAR={sys_metrics['far']:.6f}  MDR={sys_metrics['mdr']:.6f}  "
          f"L2路由率={sys_metrics['l2_rate']:.1%}  {flag}")
    print(f'  耗时: {elapsed/60:.1f} 分钟')
    return result


def _empty_metrics() -> dict:
    return {'fidelity': 0.0, 'far': 1.0, 'mdr': 1.0,
            'atom_accuracy': 0.0, 'n_bad_frames': -1, 'n_bad_atoms': -1,
            'l2_rate': 0.0, 'routing': {}}


# ─────────────────────────────────────────────────────────────
# 二分搜索主逻辑
# ─────────────────────────────────────────────────────────────

def _run(args):
    cfg     = load_cfg(args.config)
    device  = get_device()
    targets = {'fidelity': args.fidelity, 'far': args.far, 'mdr': args.mdr}

    hline('═')
    print('  PA-3HDA 自动曝光时间搜索')
    hline('═')
    print(f'  目标:      Fidelity>={args.fidelity}  FAR<={args.far}  MDR<={args.mdr}')
    print(f'  搜索范围:  [{args.t_min}ms, {args.t_start}ms]  最大迭代: {args.max_iters}')
    print(f'  每点数据:  train={args.n_train} val={args.n_val} test={args.n_test} 帧')
    print(f'  结果目录:  {SEARCH_DIR}')
    hline('═')

    all_results = []
    t_lo = args.t_min
    t_hi = args.t_start

    # ── 验证起始点 ──────────────────────────────────────────
    print('\n[初始化] 验证起始点...')
    r_start = run_point(args.t_start, cfg, device, args, targets)
    all_results.append(r_start)
    if not r_start['pass']:
        print(f'\n[错误] 起始点 {args.t_start}ms 无法满足指标！')
        print('建议: 增大 --t-start，或降低目标指标。')
        return

    # ── 二分搜索 ────────────────────────────────────────────
    print(f'\n开始二分搜索: [{t_lo:.2f}ms, {t_hi:.2f}ms]')
    for i in range(args.max_iters):
        if t_hi - t_lo < 0.5:
            print('\n[收敛] 区间宽度 < 0.5ms，停止搜索')
            break
        t_mid = (t_lo + t_hi) / 2.0
        print(f'\n=== 二分第 {i+1}/{args.max_iters} 轮 '
              f'| [{t_lo:.2f}, {t_hi:.2f}ms] | 候选 {t_mid:.2f}ms ===')
        r = run_point(t_mid, cfg, device, args, targets)
        all_results.append(r)
        if r['pass']:
            t_hi = t_mid
            print(f'  ↓ 通过，新上界 t_hi={t_hi:.2f}ms')
        else:
            t_lo = t_mid
            print(f'  ↑ 未通过，新下界 t_lo={t_lo:.2f}ms')

    # ── 最终结果打印 ─────────────────────────────────────────
    t_recommend = t_hi * 1.15
    hline('═')
    print('\n  ★ 搜索完成 ★')
    hline('═')
    l2_mult = cfg['simulation'].get('l2_multiplier', 3.0)
    print(f'  实测最短曝光 (L1): {t_hi:.2f} ms  |  L2: {t_hi*l2_mult:.2f} ms  (x{l2_mult})')
    print(f'  建议值 (×1.15裕量): {t_recommend:.2f} ms  |  {t_recommend*l2_mult:.2f} ms')
    print(f'\n  {"t_l1(ms)":>10}  {"Fidelity":>10}  {"FAR":>12}  '
          f'{"MDR":>12}  {"L2率":>6}  {"结果":>4}')
    print('  ' + '─' * 62)
    for r in sorted(all_results, key=lambda x: x['t_l1_ms']):
        s  = r['system']
        ok = '✓' if r['pass'] else '✗'
        print(f"  {r['t_l1_ms']:>10.2f}  {s['fidelity']:>10.4f}  "
              f"{s['far']:>12.6f}  {s['mdr']:>12.6f}  "
              f"{s['l2_rate']:>6.1%}  {ok:>4}")
    hline('═')

    # 保存汇总
    summary = {
        't_min_ms':       t_hi,
        't_l2_min_ms':    t_hi * 3,
        't_recommend_ms': t_recommend,
        'targets':        targets,
        'all_results':    all_results,
    }
    sp = SEARCH_DIR / 'summary.json'
    sp.write_text(json.dumps(summary, indent=2))
    print(f'\n[保存] 汇总结果: {sp}')

    # 绘图
    plot_summary(sorted(all_results, key=lambda x: x['t_l1_ms']),
                 targets, SEARCH_DIR / 'search_curve.png')

    # 可选写回配置
    print(f'\n是否将建议值写回 {args.config}？(y/n): ', end='', flush=True)
    try:
        ans = input().strip().lower()
    except Exception:
        ans = 'n'
    if ans == 'y':
        cfg['simulation']['exposure_time_l1'] = round(t_recommend / 1000, 4)
        cfg['simulation']['exposure_time_l2'] = round(t_recommend * l2_mult / 1000, 4)
        with open(args.config, 'w', encoding='utf-8') as f:
            yaml.dump(cfg, f, allow_unicode=True, sort_keys=False)
        print(f'[写回] exposure_time_l1={t_recommend/1000:.4f}s')


# ─────────────────────────────────────────────────────────────
# 命令行入口
# ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='PA-3HDA 一键曝光时间搜索')
    parser.add_argument('--config',    default='configs/default.yaml')
    parser.add_argument('--fidelity',  type=float, default=0.999,  help='Fidelity 目标')
    parser.add_argument('--far',       type=float, default=0.001,  help='FAR 目标上界')
    parser.add_argument('--mdr',       type=float, default=0.001,  help='MDR 目标上界')
    parser.add_argument('--t-start',   type=float, default=20.0,   help='起始 L1 曝光时间 (ms)')
    parser.add_argument('--t-min',     type=float, default=2.0,    help='搜索下界 (ms)')
    parser.add_argument('--max-iters', type=int,   default=8,      help='最大二分迭代次数')
    parser.add_argument('--n-train',   type=int,   default=400,    help='训练帧数')
    parser.add_argument('--n-val',     type=int,   default=100,    help='验证帧数')
    parser.add_argument('--n-test',    type=int,   default=100,    help='测试帧数')
    parser.add_argument('--epochs',    type=int,   default=None,   help='覆盖训练 epoch 数')
    parser.add_argument('--resume',    action='store_true',
                        help='跳过已通过(pass=True)的点，未通过或缺失的点重新评估')
    parser.add_argument('--clean',     action='store_true',
                        help='清除所有历史结果重新开始')
    args = parser.parse_args()

    if args.clean and SEARCH_DIR.exists():
        shutil.rmtree(SEARCH_DIR)
        print(f'[清理] 已删除 {SEARCH_DIR}')

    SEARCH_DIR.mkdir(parents=True, exist_ok=True)
    log_fh = start_tee(SEARCH_DIR / 'run.log')
    print(f'[日志] {SEARCH_DIR / "run.log"}')
    try:
        _run(args)
    finally:
        stop_tee(log_fh)


if __name__ == '__main__':
    main()
