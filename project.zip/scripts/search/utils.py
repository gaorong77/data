"""
search/utils.py
通用小工具：tag、配置加载、设备检测、打印辅助、指标判通过。
"""
import torch
import yaml


def tag(t_ms: float) -> str:
    """将曝光时间转为目录标签，如 't5.09ms'。"""
    return f't{t_ms:.2f}ms'


def load_cfg(path: str) -> dict:
    """读取 YAML 配置文件，返回字典。"""
    with open(path, encoding='utf-8') as f:
        return yaml.safe_load(f)


def get_device() -> torch.device:
    """返回可用设备（CUDA 优先），并打印显存信息。"""
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        free, total = torch.cuda.mem_get_info(0)
        print(f'  [GPU] {torch.cuda.get_device_name(0)} '
              f'({free//1024**2}/{total//1024**2} MB)')
        return torch.device('cuda')
    print('  [CPU] 无 GPU，使用 CPU（训练会慢）')
    return torch.device('cpu')


def hline(ch: str = '─', n: int = 64):
    """打印分隔线。"""
    print(ch * n)


def passes(metrics: dict, targets: dict) -> bool:
    """判断系统指标是否全部达标。"""
    return (metrics['fidelity'] >= targets['fidelity'] and
            metrics['far']      <= targets['far']      and
            metrics['mdr']      <= targets['mdr'])
