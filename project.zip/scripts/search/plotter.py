"""
search/plotter.py
搜索结果可视化：将所有测试点的 Fidelity / FAR / MDR / L2路由率绘制成 2×2 图。
"""
from pathlib import Path


def plot_summary(all_results: list, targets: dict, save_path: Path):
    """
    绘制搜索曲线并保存为 PNG。

    参数
    ----
    all_results : 已按 t_l1_ms 排序的结果列表（每项为 run_point 返回的字典）
    targets     : {'fidelity': ..., 'far': ..., 'mdr': ...}
    save_path   : 图片保存路径
    """
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        matplotlib.rcParams['font.family']        = 'DejaVu Sans'
        matplotlib.rcParams['axes.unicode_minus'] = False

        ts   = [r['t_l1_ms']            for r in all_results]
        fids = [r['system']['fidelity'] for r in all_results]
        fars = [r['system']['far']      for r in all_results]
        mdrs = [r['system']['mdr']      for r in all_results]
        l2rs = [r['system']['l2_rate']  for r in all_results]

        fig, axes = plt.subplots(2, 2, figsize=(12, 8))
        fig.suptitle('PA-3HDA Auto Exposure Search Results', fontsize=13)

        for ax, vals, thr, name, op, color in [
            (axes[0, 0], fids, targets['fidelity'], 'Fidelity', '>=', 'tab:blue'),
            (axes[0, 1], fars, targets['far'],       'FAR',      '<=', 'tab:orange'),
            (axes[1, 0], mdrs, targets['mdr'],       'MDR',      '<=', 'tab:red'),
            (axes[1, 1], l2rs, None,                 'L2 Rate',  None, 'tab:purple'),
        ]:
            ax.plot(ts, vals, 'o-', color=color, linewidth=2)
            if thr is not None:
                ax.axhline(thr, color='gray', linestyle='--',
                           label=f'Target {op}{thr}')
                ax.legend(fontsize=8)
            ax.set_xlabel('L1 Exposure (ms)')
            ax.set_ylabel(name)
            ax.set_title(name)
            ax.grid(True, alpha=0.3)

        # 通过/未通过的竖向色带
        for r in all_results:
            c = 'green' if r['pass'] else 'red'
            for ax in axes.flat[:3]:
                ax.axvline(r['t_l1_ms'], color=c, alpha=0.15, linewidth=8)

        plt.tight_layout()
        save_path.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f'\n[plot] saved: {save_path}')
        plt.close()

    except Exception as e:
        print(f'[warning] plot failed: {e}')
