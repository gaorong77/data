"""
search/data_gen.py
仿真数据生成：根据指定曝光时间生成 train/val/test 数据集并保存归一化基准。
已存在 .done 标志时自动跳过，无需重复生成。
"""
import json
from pathlib import Path

import numpy as np

# 项目路径在调用方（auto_search.py）已加入 sys.path
from data.simulate import AtomArraySimulator


def generate_dataset(cfg: dict, t_l1: float, out_dir: Path,
                     n_train: int = 400, n_val: int = 100, n_test: int = 100):
    """
    用指定 L1 曝光时间生成三拆数据集（train / val / test）。

    参数
    ----
    cfg     : 完整配置字典（来自 default.yaml）
    t_l1    : L1 曝光时间（秒）
    out_dir : 数据保存目录
    n_train / n_val / n_test : 各拆帧数
    """
    flag = out_dir / '.done'
    if flag.exists():
        print(f'  [跳过] 数据集已存在: {out_dir}')
        return

    out_dir.mkdir(parents=True, exist_ok=True)
    arr = cfg['array']
    sim = cfg['simulation']

    simulator = AtomArraySimulator(
        n_rows               = arr['n_rows'],
        n_cols               = arr['n_cols'],
        grid_spacing         = arr['grid_spacing'],
        psf_sigma            = sim['psf_sigma'],
        light_source_stdev   = sim.get('light_source_stdev',   1.0),
        atom_position_jitter = sim.get('atom_position_jitter', 0.35),
        psf_ellipticity      = sim.get('psf_ellipticity',      0.10),
        psf_drift_stdev      = sim.get('psf_drift_stdev',      0.15),
        hot_pixel_rate       = sim.get('hot_pixel_rate',       1e-5),
        hot_pixel_amp        = sim.get('hot_pixel_amp',        500.0),
        scattering_rate      = sim.get('scattering_rate',      35000.0),
        exposure_time_l1     = t_l1,
        exposure_time_l2     = t_l1 * cfg['simulation'].get('l2_multiplier', 3.0),
        survival_probability = sim.get('survival_probability', 1.0),
        stray_light_rate     = sim.get('stray_light_rate',     200.0),
        quantum_efficiency   = sim.get('quantum_efficiency',   0.72),
        dark_current_alpha   = sim.get('dark_current_alpha',   0.003),
        dark_current_beta    = sim.get('dark_current_beta',    1.0),
        bias_clamp           = sim.get('bias_clamp',           100.0),
        bias_stdev           = sim.get('bias_stdev',           0.5),
        row_noise_stdev      = sim.get('row_noise_stdev',      0.01),
        column_noise_scale   = sim.get('column_noise_scale',   0.005),
        flicker_noise_scale  = sim.get('flicker_noise_scale',  0.005),
        readout_stdev        = sim.get('readout_stdev',        0.35),
        crosstalk            = sim.get('crosstalk',            0.01),
    )

    print(f'  [仿真] t_l1={t_l1*1000:.1f}ms → '
          f'信号L1={simulator.atom_signal:.0f}ph  '
          f'L2={simulator.atom_signal_l2:.0f}ph')

    # 生成三拆数据（test 使用真实分布 fill_prob=0.85）
    for split, n, fill_prob, seed in [
        ('train', n_train, 0.5,  42),
        ('val',   n_val,   0.5,  43),
        ('test',  n_test,  0.85, 44),
    ]:
        imgs_s, imgs_l, labels = simulator.generate_dataset(
            n_frames=n, fill_prob=fill_prob, rng_seed=seed)
        np.savez_compressed(
            out_dir / f'{split}.npz',
            images_short=imgs_s, images_long=imgs_l,
            labels=labels, centers=simulator.centers)
        print(f'  [数据] {split}: {n}帧')

    # 保存归一化基准（与 dataset.py 训练时完全一致）
    tr   = np.load(str(out_dir / 'train.npz'), allow_pickle=True)
    norm = {
        'gmax_s': float(np.percentile(tr['images_short'][:20], 99.9)) + 1e-6,
        'gmax_l': float(np.percentile(tr['images_long'][:20],  99.9)) + 1e-6,
    }
    (out_dir / 'normalization.json').write_text(json.dumps(norm, indent=2))
    del tr

    flag.touch()
