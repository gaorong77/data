# search/ — auto_search 功能拆分包
from .logger      import start_tee, stop_tee
from .utils       import tag, load_cfg, get_device, hline, passes
from .data_gen    import generate_dataset
from .model_train import build_l1_cnn, train_one
from .router_l15  import neighbor_pressure, route_l15
from .failure_viz import save_failure_cases
from .evaluator   import evaluate_system
from .plotter     import plot_summary

__all__ = [
    'start_tee', 'stop_tee',
    'tag', 'load_cfg', 'get_device', 'hline', 'passes',
    'generate_dataset',
    'build_l1_cnn', 'train_one',
    'neighbor_pressure', 'route_l15',
    'save_failure_cases',
    'evaluate_system',
    'plot_summary',
]
