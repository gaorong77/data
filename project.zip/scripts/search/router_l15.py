"""
search/router_l15.py
Layer 1.5 物理诊断路由器（v9.3 双高置信一致性）

路由逻辑：
  进入条件：邻居压力 > nbr_thr（串扰嫌疑区）

  调用 L1-Wide，与 L1 联合判决：
    p_l1 > 0.95  AND  p_wide > 0.95  → 直接接受（B_xtalk_joint_accept）
    p_l1 < 0.005 AND  p_wide < 0.005 → 直接拒绝（B_xtalk_joint_reject）
    其余所有情况（分歧/中间模糊区） → L2 精判（B_xtalk_disagree_l2）

  无串扰嫌疑（邻居压力 <= nbr_thr）：
    → L2 精判（B_weak_to_l2）

设计原则：
  - 串扰区内只有两个模型均极度确信（>0.95 或 <0.005）时才直接判决
  - 任何不确定或分歧情况统一交给 L2 长曝光终裁
  - L2 是系统唯一的模糊出口
"""

from __future__ import annotations

from typing import Callable, Optional, Tuple

import numpy as np

# 双高置信门限（与 configs/default.yaml 中 theta_h / theta_l 独立，
# 用于 L1+L1-Wide 联合判决，要求更严格）
JOINT_H = 0.95    # 两者均超过此值 → 接受
JOINT_L = 0.005   # 两者均低于此值 → 拒绝


# ─────────────────────────────────────────────────────────────
# 邻居压力计算
# ─────────────────────────────────────────────────────────────

def neighbor_pressure(all_p: np.ndarray, k: int) -> float:
    """
    返回格点 k 的 8-邻域 L1 概率最大值（邻居压力）。

    参数
    ----
    all_p : 形状 (K,) 的本帧全部格点 L1 概率
    k     : 目标格点索引

    返回
    ----
    float：0.0（无有效邻居）~ 1.0
    """
    n_atoms = all_p.shape[0]
    side    = int(round(n_atoms ** 0.5))
    if side * side != n_atoms:
        return 0.0

    row, col = divmod(k, side)
    nbrs = [
        float(all_p[(row + dr) * side + (col + dc)])
        for dr in (-1, 0, 1)
        for dc in (-1, 0, 1)
        if not (dr == 0 and dc == 0)
        and 0 <= row + dr < side
        and 0 <= col + dc < side
    ]
    return max(nbrs) if nbrs else 0.0


# ─────────────────────────────────────────────────────────────
# L1.5 路由决策
# ─────────────────────────────────────────────────────────────

RouteResult = Tuple[int, str, Optional[float], Optional[float]]


def route_l15(
    k:          int,
    p_l1:       float,
    p_l1_all:   np.ndarray,
    infer_wide: Callable[[int], float],
    infer_l2:   Callable[[int], float],
    nbr_thr:    float = 0.95,
) -> RouteResult:
    """
    Layer 1.5 物理诊断路由（v9.3 双高置信一致性）。

    参数
    ----
    k           : 格点索引
    p_l1        : 本格点 L1 输出概率
    p_l1_all    : 本帧全部格点 L1 概率，用于邻居压力计算
    infer_wide  : 调用 L1-Wide 推理的回调，签名 (k) -> float
    infer_l2    : 调用 L2 推理的回调，签名 (k) -> float
    nbr_thr     : 邻居压力阈值（超过则视为串扰嫌疑）

    返回
    ----
    (pred, route, p_wide, p_l2)
    """
    p_nbr = neighbor_pressure(p_l1_all, k)

    if p_nbr > nbr_thr:
        # ── 串扰嫌疑：调用 L1-Wide 进行联合判决 ─────────────
        p_wide = infer_wide(k)

        if p_l1 > JOINT_H and p_wide > JOINT_H:
            # 双高一致 → 有原子
            return 1, 'B_xtalk_joint_accept', p_wide, None

        elif p_l1 < JOINT_L and p_wide < JOINT_L:
            # 双低一致 → 无原子
            return 0, 'B_xtalk_joint_reject', p_wide, None

        else:
            # 分歧或中间模糊区 → L2 精判
            p_l2 = infer_l2(k)
            pred = 1 if p_l2 > 0.5 else 0
            return pred, 'B_xtalk_disagree_l2', p_wide, p_l2

    else:
        # ── 无串扰嫌疑：弱信号 / 背景 → L2 终裁 ─────────────
        p_l2 = infer_l2(k)
        pred = 1 if p_l2 > 0.5 else 0
        return pred, 'B_weak_to_l2', None, p_l2
