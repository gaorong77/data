"""
search/model_train.py
单模型训练：根据模型类型构建网络、选择数据集、调用 Trainer。
已有 .done + .pth 时自动跳过。
"""
import json
from pathlib import Path

import torch

from data.dataset      import L1Dataset, L2Dataset, L3Dataset
from models.l1_roi_cnn import L1_ROI_CNN
from models.l3_unet    import L3_UNet
from train.trainer     import Trainer


def build_l1_cnn(m_cfg: dict, key: str) -> L1_ROI_CNN:
    """从配置字典构建 L1_ROI_CNN（L1 / L1-Wide / L2 共用同一架构）。"""
    return L1_ROI_CNN(**{k: m_cfg[key][k]
                         for k in ['in_channels', 'hidden_channels', 'out_channels']})


def train_one(model_type: str, cfg: dict, data_dir: Path,
              ckpt_dir: Path, device: torch.device,
              epochs_override: int = None) -> float:
    """
    训练单个子模型，返回最优验证分数。

    自动跳过条件：ckpt_dir/{model_type}.done 和 {model_type}_best.pth 均存在。

    参数
    ----
    model_type      : 'l1' | 'l1_wide' | 'l2' | 'l3'
    cfg             : 完整配置字典
    data_dir        : 数据目录（含 train.npz / val.npz）
    ckpt_dir        : checkpoint 保存目录
    device          : 训练设备
    epochs_override : 覆盖配置中的 epoch 数（None 则使用配置值）
    """
    ckpt_path  = ckpt_dir / f'{model_type}_best.pth'
    done_flag  = ckpt_dir / f'{model_type}.done'
    score_file = ckpt_dir / f'{model_type}_score.json'

    # ── 已训练：直接读取历史分数 ──────────────────────────────
    if done_flag.exists() and ckpt_path.exists():
        try:
            score = json.loads(score_file.read_text())['best']
        except (json.JSONDecodeError, KeyError, FileNotFoundError):
            score = 0.0   # score 文件损坏，返回占位值
        print(f'  [跳过] {model_type} 已训练，score={score:.4f}')
        return score

    ckpt_dir.mkdir(parents=True, exist_ok=True)
    roi_n      = cfg['roi']['n']
    roi_n_wide = roi_n * cfg['roi']['k_wide']
    m_cfg      = cfg['model']
    tr_base    = cfg['training']
    train_npz  = str(data_dir / 'train.npz')
    val_npz    = str(data_dir / 'val.npz')

    # ── 根据模型类型选数据集和网络 ───────────────────────────
    if model_type == 'l1':
        tr_cfg   = dict(tr_base['l1'])
        train_ds = L1Dataset(train_npz, roi_n=roi_n,      augment=True)
        val_ds   = L1Dataset(val_npz,   roi_n=roi_n,      augment=False)
        model    = build_l1_cnn(m_cfg, 'l1')

    elif model_type == 'l1_wide':
        tr_cfg   = dict(tr_base['l1_wide'])
        train_ds = L1Dataset(train_npz, roi_n=roi_n_wide, augment=True)
        val_ds   = L1Dataset(val_npz,   roi_n=roi_n_wide, augment=False)
        model    = build_l1_cnn(m_cfg, 'l1_wide')

    elif model_type == 'l2':
        tr_cfg   = dict(tr_base['l2'])
        train_ds = L2Dataset(train_npz, roi_n=roi_n,      augment=True)
        val_ds   = L2Dataset(val_npz,   roi_n=roi_n,      augment=False)
        model    = build_l1_cnn(m_cfg, 'l2')

    elif model_type == 'l3':
        tr_cfg   = dict(tr_base['l3'])
        sigma    = tr_cfg.get('gaussian_sigma', cfg['simulation']['psf_sigma'])
        # 强制裁剪模式防止 8GB 显存 OOM
        train_ds = L3Dataset(train_npz, sigma=sigma, is_train=True)
        val_ds   = L3Dataset(val_npz,   sigma=sigma, is_train=True)
        model    = L3_UNet(in_channels   = m_cfg['l3']['in_channels'],
                           base_channels = m_cfg['l3']['base_channels'])
    else:
        raise ValueError(f'未知模型类型: {model_type}')

    if epochs_override:
        tr_cfg['epochs'] = epochs_override

    # ── 训练 ─────────────────────────────────────────────────
    trainer = Trainer(
        model, train_ds, val_ds, tr_cfg,
        str(ckpt_path), device,
        model_type=model_type,
        use_balanced_sampler=(model_type == 'l2'),
    )
    best, _ = trainer.train()

    score_file.write_text(json.dumps({'best': best}))
    done_flag.touch()
    return best
