"""
search/logger.py
同时向屏幕和日志文件输出（带毫秒级时间戳）。
"""
import datetime
import io
import sys
from pathlib import Path


class _Tee(io.TextIOBase):
    """写操作同时转发到屏幕和日志文件，日志每行加时间戳。"""

    def __init__(self, primary, secondary):
        self._primary   = primary
        self._secondary = secondary
        self._buf       = ''

    @staticmethod
    def _ts():
        return datetime.datetime.now().strftime('[%H:%M:%S.%f')[:-3] + '] '

    def _write_to_file(self, s):
        data  = self._buf + s
        lines = data.split('\n')
        self._buf = lines[-1]
        for line in lines[:-1]:
            self._secondary.write(('\n' if line == '' else self._ts() + line + '\n'))
        self._secondary.flush()

    def write(self, s):
        self._primary.write(s)
        self._primary.flush()
        self._write_to_file(s)
        return len(s)

    def flush(self):
        self._primary.flush()
        if self._buf:
            self._secondary.write(self._ts() + self._buf)
            self._buf = ''
        self._secondary.flush()

    def fileno(self):   return self._primary.fileno()
    def isatty(self):   return self._primary.isatty()


def start_tee(log_path: Path):
    """重定向 stdout/stderr → 屏幕 + 日志文件，返回文件句柄。"""
    log_path.parent.mkdir(parents=True, exist_ok=True)
    fh = open(log_path, 'a', encoding='utf-8', buffering=1)
    fh.write(f'\n{"="*64}\n'
             f'  Run: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n'
             f'{"="*64}\n')
    sys.stdout = _Tee(sys.__stdout__, fh)
    sys.stderr = _Tee(sys.__stderr__, fh)
    return fh


def stop_tee(fh):
    """恢复 stdout/stderr，关闭日志文件。"""
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    fh.close()
