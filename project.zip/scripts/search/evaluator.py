"""
search/evaluator.py
整合系统评估（v9.3 路由）。

路由优先级：
  1. 先检测邻居压力（串扰嫌疑），有压力 → L1.5 双高置信联合判决
  2. 无串扰嫌疑 → L1 双端快速判决（孤立格点）
  3. L1 模糊区（无串扰）→ L2 直接终裁

依赖拆分：
  - router_l15.py   L1.5 物理诊断路由逻辑
  - failure_viz.py  失败案例保存与可视化
"""

import json
from pathlib import Path

import numpy as np
import torch

from data.dataset  import _extract_roi
from .model_train  import build_l1_cnn
from .router_l15   import neighbor_pressure, route_l15
from .failure_viz  import save_failure_cases


# ─────────────────────────────────────────────────────────────
# checkpoint 加载（含完整性检查）
# ─────────────────────────────────────────────────────────────

def _load_model(mtype, arch, ckpt_dir, device):
    ckpt = ckpt_dir / f'{mtype}_best.pth'
    if not ckpt.exists():
        raise FileNotFoundError(
            f'[load_model] not found: {ckpt}\n'
            f'  -> Re-run training for: {mtype}')
    if ckpt.stat().st_size < 256:
        raise RuntimeError(
            f'[load_model] too small ({ckpt.stat().st_size}B), corrupted: {ckpt}\n'
            f'  -> Delete and re-run training for: {mtype}')
    try:
        arch.load_state_dict(
            torch.load(ckpt, map_location=device, weights_only=True))
    except EOFError:
        raise RuntimeError(
            f'[load_model] EOFError: {ckpt}\n'
            f'  -> Training was interrupted. Delete and re-run.')
    return arch.eval().to(device)


# ─────────────────────────────────────────────────────────────
# 公开接口
# ─────────────────────────────────────────────────────────────

@torch.no_grad()
def evaluate_system(cfg: dict, data_dir: Path,
                    ckpt_dir: Path, device: torch.device) -> dict:
    """
    v9.3 路由评估。

    串扰嫌疑区（邻居压力 > nbr_thr）：
      L1 和 L1-Wide 均 > 0.95  → 接受
      L1 和 L1-Wide 均 < 0.005 → 拒绝
      其余（分歧/模糊）        → L2 精判

    无串扰区（孤立格点）：
      p_l1 > theta_h → 直接接受
      p_l1 < theta_l → 直接拒绝
      theta_l <= p_l1 <= theta_h → L2 精判
    """
    roi_n      = cfg['roi']['n']
    roi_n_wide = roi_n * cfg['roi']['k_wide']
    m_cfg      = cfg['model']
    r_cfg      = cfg['routing']
    theta_h    = r_cfg['theta_h']
    theta_l    = r_cfg.get('theta_l',              0.05)
    nbr_thr    = r_cfg.get('neighbor_pressure_thr', theta_h)

    # ── 加载模型 ─────────────────────────────────────────────
    model_l1      = _load_model('l1',      build_l1_cnn(m_cfg, 'l1'),      ckpt_dir, device)
    model_l1_wide = _load_model('l1_wide', build_l1_cnn(m_cfg, 'l1_wide'), ckpt_dir, device)
    model_l2      = _load_model('l2',      build_l1_cnn(m_cfg, 'l2'),      ckpt_dir, device)

    # ── 加载测试集 & 归一化 ──────────────────────────────────
    data    = np.load(str(data_dir / 'test.npz'), allow_pickle=True)
    imgs_s  = data['images_short'].astype(np.float32)
    imgs_l  = data['images_long'].astype(np.float32)
    labels  = data['labels'].astype(np.int32)
    centers = data['centers']
    N, K    = labels.shape

    norm_path = data_dir / 'normalization.json'
    if norm_path.exists():
        ns     = json.loads(norm_path.read_text())
        gmax_s, gmax_l = ns['gmax_s'], ns['gmax_l']
    else:
        tr     = np.load(str(data_dir / 'train.npz'), allow_pickle=True)
        gmax_s = float(np.percentile(tr['images_short'][:20], 99.9)) + 1e-6
        gmax_l = float(np.percentile(tr['images_long'][:20],  99.9)) + 1e-6
        del tr
        norm_path.write_text(json.dumps({'gmax_s': gmax_s, 'gmax_l': gmax_l}, indent=2))
    print(f'  [归一化] gmax_s={gmax_s:.1f}  gmax_l={gmax_l:.1f}')

    # ── 推理辅助 ─────────────────────────────────────────────
    def infer(model, roi):
        x   = torch.from_numpy(roi).unsqueeze(0).unsqueeze(0).to(device)
        out = model(x)
        if out.dim() == 2 and out.shape[1] == 1:
            out = out.squeeze(1)
        return float(torch.sigmoid(out).item())

    # ── 路由计数器（v9.3）────────────────────────────────────
    cnt = {
        'A_l1_accept':          0,   # 孤立点 p_l1 > theta_h
        'A_l1_reject':          0,   # 孤立点 p_l1 < theta_l
        'A_l1_weak_to_l2':      0,   # 孤立点 模糊区 → L2
        'B_xtalk_joint_accept': 0,   # 串扰区 双高(>0.95) → 接受
        'B_xtalk_joint_reject': 0,   # 串扰区 双低(<0.005) → 拒绝
        'B_xtalk_disagree_l2':  0,   # 串扰区 分歧/模糊 → L2
        'B_weak_to_l2':         0,   # 无串扰 弱信号 → L2
    }
    all_preds, all_gts = [], []
    records = []   # (p_l1, p_wide|None, p_l2|None, pred, gt, route)

    # ── 主推理循环 ───────────────────────────────────────────
    for i in range(N):
        img_s = imgs_s[i] / gmax_s
        img_l = imgs_l[i] / gmax_l

        # 批量推理本帧全部格点 L1 概率（供邻居压力使用）
        p_l1_all = np.array([
            infer(model_l1,
                  _extract_roi(img_s, centers[k][0], centers[k][1], roi_n))
            for k in range(K)
        ], dtype=np.float32)

        for k in range(K):
            cy, cx = centers[k]
            gt   = int(labels[i, k])
            p_l1 = float(p_l1_all[k])

            # ── 优先检测邻居压力 ──────────────────────────────
            p_nbr = neighbor_pressure(p_l1_all, k)

            if p_nbr > nbr_thr:
                # 【路径 B】串扰嫌疑区：L1.5 双高置信联合判决
                pred, route, p_wide, p_l2 = route_l15(
                    k          = k,
                    p_l1       = p_l1,
                    p_l1_all   = p_l1_all,
                    infer_wide = lambda _k: infer(
                        model_l1_wide,
                        _extract_roi(img_s, centers[_k][0], centers[_k][1], roi_n_wide)),
                    infer_l2   = lambda _k: infer(
                        model_l2,
                        _extract_roi(img_l, centers[_k][0], centers[_k][1], roi_n)),
                    nbr_thr    = nbr_thr,
                )

            else:
                # 【路径 A】无串扰孤立点：信任 L1 双端判决
                p_wide, p_l2 = None, None
                if p_l1 > theta_h:
                    pred, route = 1, 'A_l1_accept'
                elif p_l1 < theta_l:
                    pred, route = 0, 'A_l1_reject'
                else:
                    # 模糊区 → L2
                    p_l2 = infer(model_l2,
                                 _extract_roi(img_l, cy, cx, roi_n))
                    pred  = 1 if p_l2 > 0.5 else 0
                    route = 'A_l1_weak_to_l2'

            # 统一计数
            if route in cnt:
                cnt[route] += 1

            all_preds.append(pred)
            all_gts.append(gt)
            records.append((p_l1, p_wide, p_l2, pred, gt, route))

    preds = np.array(all_preds)
    gts   = np.array(all_gts)

    # ── 指标计算 ─────────────────────────────────────────────
    neg          = gts == 0
    pos          = gts == 1
    far          = float((preds[neg] == 1).mean()) if neg.any() else 0.0
    mdr          = float((preds[pos] == 0).mean()) if pos.any() else 0.0
    atom_acc     = float((preds == gts).mean())
    frame_preds  = preds.reshape(N, K)
    frame_gts    = gts.reshape(N, K)
    atom_errors  = frame_preds != frame_gts
    frame_ok     = (~atom_errors).all(axis=1)
    fidelity     = float(frame_ok.mean())
    n_bad_frames = int((~frame_ok).sum())
    n_bad_atoms  = int(atom_errors.sum())

    # ── 失败案例保存 ─────────────────────────────────────────
    failure_dir  = ckpt_dir.parent / 'failure_cases'
    per_site_err = atom_errors.mean(axis=0)
    worst_sites  = np.argsort(per_site_err)[-5:][::-1]
    meta_list    = []

    if n_bad_atoms > 0:
        meta_list = save_failure_cases(
            failure_dir, records, frame_ok, atom_errors,
            imgs_s, imgs_l, centers, roi_n, roi_n_wide)

    # ── 诊断打印 ─────────────────────────────────────────────
    print(f'\n  [原子级] 准确率={atom_acc:.6f}  '
          f'错误格点={n_bad_atoms}/{N*K}  失败帧={n_bad_frames}/{N}')

    if n_bad_atoms > 0:
        for si in worst_sites:
            if per_site_err[si] > 0:
                print(f'    格点#{si:03d}: {per_site_err[si]:.4%}  '
                      f'(y={centers[si][0]:.0f} x={centers[si][1]:.0f})')
        print(f'  [失败案例] -> {failure_dir}  ({len(meta_list)} 条)')
        for fi in np.where(~frame_ok)[0][:5]:
            for ak in np.where(atom_errors[fi])[0][:5]:
                rp1, rpw, rp2, rpred, rgt, rroute = records[fi * K + ak]
                etype  = 'FA' if (rpred == 1 and rgt == 0) else 'MD'
                pw_str = f'{rpw:.4f}' if rpw is not None else 'N/A'
                p2_str = f'{rp2:.4f}' if rp2 is not None else 'N/A'
                print(f'    帧#{fi:03d} 格点#{ak:03d} [{etype}]'
                      f'  p_l1={rp1:.4f}  p_wide={pw_str}  p_l2={p2_str}'
                      f'  route={rroute}')
    else:
        print('  [诊断] 所有帧完全正确，无失败案例 ✓')

    # ── 路由统计打印 ─────────────────────────────────────────
    total      = N * K
    n_l2_total = (cnt['A_l1_weak_to_l2'] +
                  cnt['B_xtalk_disagree_l2'] +
                  cnt['B_weak_to_l2'])

    print('\n  ┌──────────────────────────────────────────────────┬───────┬───────┐')
    print(  '  │ 路由路径 (v9.3 双高置信一致性)                    │  数量 │  占比 │')
    print(  '  ├──────────────────────────────────────────────────┼───────┼───────┤')
    rows = [
        ('A-accept       孤立点 L1 直接接受 (p > θH)',        cnt['A_l1_accept']),
        ('A-reject       孤立点 L1 直接拒绝 (p < θL)',        cnt['A_l1_reject']),
        ('A-weak-L2      孤立点 模糊区 → L2',                 cnt['A_l1_weak_to_l2']),
        ('B-joint-✓      串扰区 双高(>0.95) → 接受',          cnt['B_xtalk_joint_accept']),
        ('B-joint-✗      串扰区 双低(<0.005) → 拒绝',         cnt['B_xtalk_joint_reject']),
        ('B-disagree-L2  串扰区 分歧/模糊 → L2',              cnt['B_xtalk_disagree_l2']),
        ('B-weak-L2      无串扰 弱信号 → L2',                 cnt['B_weak_to_l2']),
    ]
    for name, n in rows:
        print(f'  │ {name:<48} │ {n:>5} │ {n/total:>5.1%} │')
    print(  '  ├──────────────────────────────────────────────────┼───────┼───────┤')
    print(f'  │ {"L2 终裁总量":<48} │ {n_l2_total:>5} │ {n_l2_total/total:>5.1%} │')
    print(f'  │ {"总计":<48} │ {total:>5} │ {"100%":>5} │')
    print(  '  └──────────────────────────────────────────────────┴───────┴───────┘')

    return {
        'fidelity':      fidelity,
        'far':           far,
        'mdr':           mdr,
        'atom_accuracy': atom_acc,
        'n_bad_frames':  n_bad_frames,
        'n_bad_atoms':   n_bad_atoms,
        'l2_rate':       n_l2_total / total,
        'routing':       {**cnt,
                          'l2_total':     n_l2_total,
                          'l2_total_pct': n_l2_total / total},
    }
