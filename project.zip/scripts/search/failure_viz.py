"""
search/failure_viz.py
Failure case visualization and storage.

Each failed atom site generates:
  - .npz : roi_short (n×n) / roi_long (n×n) / roi_wide_s (3n×3n short)
           / roi_wide_l (3n×3n long) / meta
  - .png : 2×2 image grid (L1 ROI / L1-Wide ROI / L2 ROI / L2-Wide ROI)
           + route path and probability annotations (English only)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import List

import numpy as np

from data.dataset import _extract_roi


def save_failure_cases(
    failure_dir: Path,
    records:     list,
    frame_ok:    np.ndarray,
    atom_errors: np.ndarray,
    imgs_s:      np.ndarray,
    imgs_l:      np.ndarray,
    centers:     np.ndarray,
    roi_n:       int,
    roi_n_wide:  int,
) -> List[dict]:
    """
    Save all failed atom sites as .npz data and .png visualizations.
    Returns meta_list (list of dicts, one per error).
    """
    failure_dir.mkdir(parents=True, exist_ok=True)

    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import matplotlib.patches as patches
        matplotlib.rcParams['font.family']        = 'DejaVu Sans'
        matplotlib.rcParams['axes.unicode_minus'] = False
        _has_mpl = True
    except ImportError:
        _has_mpl = False

    N, K      = atom_errors.shape
    meta_list = []
    case_id   = 0

    for fi in np.where(~frame_ok)[0]:
        for ak in np.where(atom_errors[fi])[0]:
            rp1, rpw, rp2, rpred, rgt, rroute = records[fi * K + ak]
            cy, cx = centers[ak]
            etype  = 'FA' if (rpred == 1 and rgt == 0) else 'MD'

            # ── Extract ROIs ─────────────────────────────────
            roi_s      = _extract_roi(imgs_s[fi], cy, cx, roi_n)
            roi_l      = _extract_roi(imgs_l[fi], cy, cx, roi_n)
            roi_wide_s = _extract_roi(imgs_s[fi], cy, cx, roi_n_wide)
            roi_wide_l = _extract_roi(imgs_l[fi], cy, cx, roi_n_wide)

            meta = {
                'case_id':    case_id,
                'error_type': etype,
                'frame':      int(fi),
                'atom_k':     int(ak),
                'cy': float(cy), 'cx': float(cx),
                'gt': int(rgt),  'pred': int(rpred),
                'p_l1':   round(float(rp1), 6),
                'p_wide': round(float(rpw), 6) if rpw is not None else None,
                'p_l2':   round(float(rp2), 6) if rp2 is not None else None,
                'route':  rroute,
            }
            meta_list.append(meta)

            stem = f'case_{case_id:04d}_{etype}_f{fi:03d}_k{ak:03d}'

            # ── Save .npz ─────────────────────────────────────
            np.savez_compressed(
                failure_dir / f'{stem}.npz',
                roi_short    = roi_s,
                roi_long     = roi_l,
                roi_wide_s   = roi_wide_s,
                roi_wide_l   = roi_wide_l,
                meta         = np.array([meta], dtype=object))

            # ── Save .png ─────────────────────────────────────
            if _has_mpl:
                _plot_case(
                    save_path  = failure_dir / f'{stem}.png',
                    roi_s      = roi_s,
                    roi_wide_s = roi_wide_s,
                    roi_l      = roi_l,
                    roi_wide_l = roi_wide_l,
                    roi_n      = roi_n,
                    etype      = etype,
                    meta       = meta,
                )

            case_id += 1

    # ── Summary JSON ──────────────────────────────────────────
    per_site_err = atom_errors.mean(axis=0)
    worst_sites  = np.argsort(per_site_err)[-5:][::-1]
    (failure_dir / 'failure_summary.json').write_text(
        json.dumps({
            'n_bad_frames': int((~frame_ok).sum()),
            'n_bad_atoms':  int(atom_errors.sum()),
            'worst_sites':  worst_sites.tolist(),
            'cases':        meta_list,
        }, indent=2, ensure_ascii=False))

    return meta_list


def _draw_roi_box(ax, roi_n: int, color: str = '#00FFD4'):
    """Draw a dashed box marking the n×n ROI centre inside a 3n×3n image."""
    import matplotlib.patches as patches
    offset = roi_n
    rect = patches.Rectangle(
        (offset - 0.5, offset - 0.5), roi_n, roi_n,
        linewidth=2, edgecolor=color, facecolor='none', linestyle='--')
    ax.add_patch(rect)
    for cx_, cy_ in [
        (offset - 0.5,         offset - 0.5),
        (offset + roi_n - 0.5, offset - 0.5),
        (offset - 0.5,         offset + roi_n - 0.5),
        (offset + roi_n - 0.5, offset + roi_n - 0.5),
    ]:
        ax.plot(cx_, cy_, 's', ms=4, color=color, zorder=5)


def _plot_case(save_path, roi_s, roi_wide_s, roi_l, roi_wide_l,
               roi_n, etype, meta):
    """
    2×2 image grid:
      [0,0] L1  short-exposure ROI  (n×n)
      [0,1] L1-Wide  (3n×3n) + dashed ROI box  (short exposure)
      [1,0] L2  long-exposure  ROI  (n×n)
      [1,1] L2-Wide  (3n×3n) + dashed ROI box  (long  exposure)

    Bottom panel: route path + probability decisions (English only).
    """
    import matplotlib.pyplot as plt
    import matplotlib.gridspec as gridspec

    p_l1   = meta['p_l1']
    p_wide = meta.get('p_wide')
    p_l2   = meta.get('p_l2')
    rgt    = meta['gt']
    rpred  = meta['pred']
    fi     = meta['frame']
    ak     = meta['atom_k']
    route  = meta['route']

    accent = '#FF5555' if etype == 'FA' else '#FFB300'
    BG     = '#0D0D0D'

    # ── Layout: 2×2 images + 1 text row ──────────────────────
    fig = plt.figure(figsize=(11, 9), facecolor=BG)
    gs  = gridspec.GridSpec(
        3, 2,
        figure=fig,
        height_ratios=[4, 4, 1.6],
        hspace=0.35, wspace=0.18,
        left=0.05, right=0.95, top=0.88, bottom=0.04)

    axes_img = [
        fig.add_subplot(gs[0, 0]),
        fig.add_subplot(gs[0, 1]),
        fig.add_subplot(gs[1, 0]),
        fig.add_subplot(gs[1, 1]),
    ]
    ax_text = fig.add_subplot(gs[2, :])

    # ── Image panels ─────────────────────────────────────────
    panels = [
        (roi_s,      f'L1  Short  {roi_n}×{roi_n} px',         False, '#00FFD4'),
        (roi_wide_s, f'L1-Wide  Short  {roi_n*3}×{roi_n*3} px', True,  '#00FFD4'),
        (roi_l,      f'L2  Long   {roi_n}×{roi_n} px',          False, '#FF9F00'),
        (roi_wide_l, f'L2-Wide  Long   {roi_n*3}×{roi_n*3} px', True,  '#FF9F00'),
    ]

    for ax, (img, title, draw_box, box_color) in zip(axes_img, panels):
        ax.set_facecolor(BG)
        ax.imshow(img, cmap='inferno', interpolation='nearest',
                  vmin=0, vmax=max(img.max(), 1e-6))
        ax.set_title(title, fontsize=8.5, color='#CCCCCC', pad=4)
        ax.axis('off')
        if draw_box:
            _draw_roi_box(ax, roi_n, color=box_color)
        for sp in ax.spines.values():
            sp.set_edgecolor('#333333')
            sp.set_linewidth(0.8)

    # ── Text panel: route + probabilities ────────────────────
    ax_text.set_facecolor('#181818')
    ax_text.axis('off')
    for sp in ax_text.spines.values():
        sp.set_edgecolor('#444444')
        sp.set_linewidth(0.8)

    # Build probability string
    p_l1_str   = f'{p_l1:.4f}'
    p_wide_str = f'{p_wide:.4f}' if p_wide is not None else 'N/A'
    p_l2_str   = f'{p_l2:.4f}'  if p_l2  is not None else 'N/A'

    # Decision verdict per model
    def verdict(p, thr_h=0.95, thr_l=0.005):
        if p is None:     return '---'
        if p > thr_h:     return 'ATOM  ✓'
        if p < thr_l:     return 'EMPTY ✓'
        return 'UNSURE'

    v_l1   = verdict(p_l1)
    v_wide = verdict(p_wide)
    v_l2   = 'ATOM' if (p_l2 is not None and p_l2 > 0.5) else ('EMPTY' if p_l2 is not None else 'N/A')

    line1 = (f'Route: {route}    |    '
             f'L1: {p_l1_str} ({v_l1})    '
             f'L1-Wide: {p_wide_str} ({v_wide})    '
             f'L2: {p_l2_str} ({v_l2})')
    line2 = (f'GT = {rgt}    Pred = {rpred}    '
             f'Error type: {etype}  '
             f'("{"False Alarm" if etype == "FA" else "Missed Detection"}")')

    ax_text.text(0.5, 0.72, line1,
                 ha='center', va='center', fontsize=8.5,
                 color='#DDDDDD', transform=ax_text.transAxes,
                 fontfamily='monospace')
    ax_text.text(0.5, 0.28, line2,
                 ha='center', va='center', fontsize=9,
                 color=accent, transform=ax_text.transAxes,
                 fontweight='bold')

    # ── Super title ───────────────────────────────────────────
    fig.suptitle(
        f'[{etype}]  Frame #{fi:03d}  Atom #{ak:03d}  '
        f'|  GT={rgt}  Pred={rpred}',
        fontsize=11, color=accent, y=0.96)

    plt.savefig(save_path, dpi=130, bbox_inches='tight', facecolor=BG)
    plt.close(fig)
