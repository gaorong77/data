"""
PA3HDA_v4/scripts/analyze_atom_loss.py
========================================
原子损失分析工具

功能
----
对比「前5帧叠加」(8+10+20+40+80 ms) 与「第6帧」(160 ms)，
定量分析成像过程中原子损失的数量与比例。

原理
----
在量子原子阵列实验中，成像光会将原子加热并最终从阱中逸出。
通过对比前5次（较短曝光）叠加图和最后一次（最长曝光）图像，
可以估计整个采集序列中的原子损失率。

    损失原子 = 在前5帧叠加中检测到，但在第6帧中未检测到的格点
    增加原子 = 在第6帧中检测到，但在前5帧叠加中未检测到的格点（理论上应为0）

输出
----
- 单组可视化图：并排显示两幅图，叠加格点状态（绿=存在/红=损失/蓝=新增）
- 多组批量统计：损失率分布直方图 + 汇总CSV

用法示例
--------
# 分析单组：
python scripts/analyze_atom_loss.py \\
    --data-root /path/to/data \\
    --group-id 1 \\
    --output-dir results/atom_loss

# 分析所有组（批量）：
python scripts/analyze_atom_loss.py \\
    --data-root /path/to/data \\
    --all \\
    --output-dir results/atom_loss

# 分析前50组并保存CSV：
python scripts/analyze_atom_loss.py \\
    --data-root /path/to/data \\
    --all --max-groups 50 \\
    --output-dir results/atom_loss
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")          # 无显示器环境
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib import font_manager
from PIL import Image


# ══════════════════════════════════════════════════════════════════════════════
# 中文字体自动配置
# 按优先级依次尝试 Windows / macOS / Linux 常见中文字体，找到即用。
# 若全部找不到则回退英文标签，不影响图像内容。
# ══════════════════════════════════════════════════════════════════════════════

def _setup_chinese_font() -> bool:
    """
    尝试为 matplotlib 配置中文字体，返回是否成功。
    成功后所有 plt.title / ax.set_xlabel 等中文文本均可正常显示。
    """
    candidates = [
        # Windows
        "Microsoft YaHei", "微软雅黑",
        "SimHei", "SimSun", "NSimSun", "FangSong", "KaiTi",
        # macOS
        "PingFang SC", "Heiti SC", "STHeiti", "STSong",
        # Linux / 跨平台
        "WenQuanYi Micro Hei", "WenQuanYi Zen Hei",
        "Noto Sans CJK SC", "Source Han Sans SC",
        "Droid Sans Fallback",
    ]
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in candidates:
        if name in available:
            matplotlib.rcParams["font.family"]       = "sans-serif"
            matplotlib.rcParams["font.sans-serif"]   = [name, "DejaVu Sans"]
            matplotlib.rcParams["axes.unicode_minus"] = False   # 负号正常显示
            return True
    # 全部失败：保持默认，但把中文标签替换为英文（见 _LABELS）
    return False

_CN_FONT_OK = _setup_chinese_font()

# ── 标签字典：中文字体可用时用中文，否则用英文 ─────────────────────────────
_L = {
    "title_single"  : ("原子损失分析",            "Atom Loss Analysis"),
    "early_title"   : ("前5帧叠加",               "Early stack"),
    "early_exp"     : ("8+10+20+40+80 ms",         "8+10+20+40+80 ms"),
    "late_title"    : ("第6帧",                   "Frame-6"),
    "atoms"         : ("原子数",                  "Atoms"),
    "diff_title"    : ("差异图",                  "Diff"),
    "lost_label"    : ("损失",                    "Lost"),
    "gain_label"    : ("新增",                    "Gain"),
    "retain_label"  : ("保留",                    "Retain"),
    "hist_title"    : ("损失率分布",              "Loss-rate dist."),
    "scatter_title" : ("初始原子数 vs 损失率",    "Init atoms vs loss rate"),
    "bar_title"     : ("各组损失原子数",          "Loss atoms per group"),
    "loss_pct"      : ("损失率 (%)",              "Loss rate (%)"),
    "group_count"   : ("组数",                    "# Groups"),
    "init_atoms"    : ("前5帧原子数",             "Early atoms"),
    "sorted_groups" : ("组（按损失数排序）",      "Groups (sorted)"),
    "loss_atoms"    : ("损失原子数",              "Lost atoms"),
    "mean_label"    : ("均值",                    "Mean"),
    "median_label"  : ("中位数",                  "Median"),
}

def t(key: str) -> str:
    """根据字体状态返回中文或英文标签。"""
    zh, en = _L[key]
    return zh if _CN_FONT_OK else en

# ── 曝光档位定义 ───────────────────────────────────────────────────────────────
EXPOSURES      = [8, 10, 20, 40, 80, 160]   # ms
EARLY_EXP      = EXPOSURES[:5]              # 前5帧
LATE_EXP       = EXPOSURES[5]              # 第6帧（160ms）

# ── 默认格点参数（可通过 --spacing / --n-rows / --n-cols 覆盖）─────────────────
DEFAULT_SPACING = 20
DEFAULT_N_ROWS  = 20
DEFAULT_N_COLS  = 20
DEFAULT_SIGMA_THR = 4.0   # 检测阈值（sigma倍数），可适当调低以适应低SNR帧


# ══════════════════════════════════════════════════════════════════════════════
# 底层 I/O
# ══════════════════════════════════════════════════════════════════════════════

def load_tif(folder: Path, exp: int) -> Optional[np.ndarray]:
    """加载 {folder}/{exp}ms/0001.tif，返回 float32 数组，失败返回 None。"""
    tif_path = folder / f"{exp}ms" / "0001.tif"
    if not tif_path.exists():
        return None
    try:
        return np.array(Image.open(tif_path)).astype(np.float32)
    except Exception as e:
        print(f"  [警告] 读取 {tif_path} 失败: {e}")
        return None


def find_groups(data_root: Path) -> List[int]:
    """返回数据根目录下所有组编号（排序）。"""
    return sorted(
        int(d.name) for d in data_root.iterdir()
        if d.is_dir() and d.name.isdigit()
    )


# ══════════════════════════════════════════════════════════════════════════════
# 格点检测
# ══════════════════════════════════════════════════════════════════════════════

def auto_offset(img: np.ndarray, spacing: int) -> Tuple[int, int]:
    """通过全图最亮点推算格点起始偏移量。"""
    y_max, x_max = np.unravel_index(np.argmax(img), img.shape)
    return int(y_max % spacing), int(x_max % spacing)


def detect_atoms_on_grid(
    img: np.ndarray,
    n_rows: int,
    n_cols: int,
    spacing: int,
    off_y: int,
    off_x: int,
    sigma_thr: float,
    roi_r: int = 2,
) -> np.ndarray:
    """
    在给定格点上检测原子占据情况。

    Parameters
    ----------
    img       : [H, W] float32 图像（可以是叠加图或单帧图）
    off_y/x   : 格点起始偏移（由参考图像确定，保持一致）
    sigma_thr : 检测阈值 = bg + sigma_thr * std
    roi_r     : ROI 半径（像素），默认取格点中心 ±2

    Returns
    -------
    labels : [n_rows, n_cols] int32，1=有原子，0=空
    """
    bg  = float(np.median(img))
    std = float(np.std(img - bg)) + 1e-6
    thr = bg + sigma_thr * std

    H, W = img.shape
    labels = np.zeros((n_rows, n_cols), dtype=np.int32)

    for r in range(n_rows):
        for c in range(n_cols):
            yc = off_y + r * spacing
            xc = off_x + c * spacing
            if 0 <= yc < H and 0 <= xc < W:
                roi = img[max(0, yc - roi_r): yc + roi_r + 1,
                          max(0, xc - roi_r): xc + roi_r + 1]
                if float(np.mean(roi)) > thr:
                    labels[r, c] = 1
    return labels


def build_centers(n_rows, n_cols, spacing, off_y, off_x):
    """返回所有格点中心坐标 [K, 2]，顺序 (y, x)。"""
    centers = []
    for r in range(n_rows):
        for c in range(n_cols):
            centers.append([off_y + r * spacing, off_x + c * spacing])
    return np.array(centers, dtype=np.float32)


# ══════════════════════════════════════════════════════════════════════════════
# 单组分析
# ══════════════════════════════════════════════════════════════════════════════

def analyze_group(
    group_dir: Path,
    n_rows: int,
    n_cols: int,
    spacing: int,
    sigma_thr: float,
) -> Optional[Dict]:
    """
    分析单组的原子损失情况。

    Returns
    -------
    dict with keys:
        early_stack : [H,W] float32  — 前5帧叠加图
        late_img    : [H,W] float32  — 第6帧（160ms）图
        labels_early: [n_rows, n_cols] int32  — 前5帧检测结果
        labels_late : [n_rows, n_cols] int32  — 第6帧检测结果
        labels_lost : [n_rows, n_cols] int32  — 损失原子（early=1, late=0）
        labels_gain : [n_rows, n_cols] int32  — 新增原子（early=0, late=1）
        centers     : [K, 2] float32          — 格点中心
        n_early     : int  — 前5帧原子数
        n_late      : int  — 第6帧原子数
        n_lost      : int  — 损失原子数
        n_gain      : int  — 新增原子数
        loss_rate   : float — 损失率 = n_lost / n_early
        off_y, off_x: int   — 格点偏移
    or None if images are missing.
    """
    # —— 加载前5帧 ————————————————————————————————————————————————————————
    early_stack: Optional[np.ndarray] = None
    for exp in EARLY_EXP:
        img = load_tif(group_dir, exp)
        if img is not None:
            early_stack = img if early_stack is None else early_stack + img

    if early_stack is None:
        return None

    # —— 加载第6帧 ————————————————————————————————————————————————————————
    late_img = load_tif(group_dir, LATE_EXP)
    if late_img is None:
        return None

    # —— 用叠加图确定格点偏移（信噪比最高） ————————————————————————————————
    ref = early_stack   # 以叠加图为参考，保证格点一致
    off_y, off_x = auto_offset(ref, spacing)
    centers = build_centers(n_rows, n_cols, spacing, off_y, off_x)

    # —— 在叠加图和第6帧上分别检测原子 ————————————————————————————————————
    labels_early = detect_atoms_on_grid(
        early_stack, n_rows, n_cols, spacing, off_y, off_x, sigma_thr)
    labels_late  = detect_atoms_on_grid(
        late_img,    n_rows, n_cols, spacing, off_y, off_x, sigma_thr)

    # —— 对比 ——————————————————————————————————————————————————————————————
    labels_lost = ((labels_early == 1) & (labels_late == 0)).astype(np.int32)
    labels_gain = ((labels_early == 0) & (labels_late == 1)).astype(np.int32)

    n_early = int(np.sum(labels_early))
    n_late  = int(np.sum(labels_late))
    n_lost  = int(np.sum(labels_lost))
    n_gain  = int(np.sum(labels_gain))
    loss_rate = n_lost / max(n_early, 1)

    return dict(
        early_stack  = early_stack,
        late_img     = late_img,
        labels_early = labels_early,
        labels_late  = labels_late,
        labels_lost  = labels_lost,
        labels_gain  = labels_gain,
        centers      = centers,
        n_early      = n_early,
        n_late       = n_late,
        n_lost       = n_lost,
        n_gain       = n_gain,
        loss_rate    = loss_rate,
        off_y        = off_y,
        off_x        = off_x,
    )


# ══════════════════════════════════════════════════════════════════════════════
# 可视化
# ══════════════════════════════════════════════════════════════════════════════

def _percentile_clip(img: np.ndarray, lo=1, hi=99) -> np.ndarray:
    """对比度拉伸，便于可视化。"""
    vmin = np.percentile(img, lo)
    vmax = np.percentile(img, hi)
    return np.clip((img - vmin) / (vmax - vmin + 1e-9), 0, 1)


def plot_single_group(
    result: Dict,
    group_id: int,
    n_rows: int,
    n_cols: int,
    spacing: int,
    save_path: Optional[Path] = None,
) -> plt.Figure:
    """
    生成单组可视化图：
    左  — 前5帧叠加（含原子状态叠加）
    右  — 第6帧 160ms（含原子状态叠加）
    下  — 差异放大图（仅显示损失/新增格点）

    图例：
      绿圆 = 两帧都有（保留）
      红×  = 前5帧有、第6帧无（损失）
      蓝+  = 前5帧无、第6帧有（新增）
      灰点 = 两帧都无（空格点）
    """
    early  = _percentile_clip(result["early_stack"])
    late   = _percentile_clip(result["late_img"])
    centers = result["centers"]   # [K, 2] (y, x)
    le = result["labels_early"].flatten()
    ll = result["labels_late"].flatten()
    lo = result["labels_lost"].flatten()
    lg = result["labels_gain"].flatten()

    fig, axes = plt.subplots(1, 3, figsize=(20, 7))
    fig.suptitle(
        f"Group {group_id}  |  {t('title_single')}\n"
        f"{t('early_title')} {t('atoms')}: {result['n_early']}  →  "
        f"{t('late_title')} {t('atoms')}: {result['n_late']}  |  "
        f"{t('lost_label')}: {result['n_lost']} ({result['loss_rate']*100:.1f}%)  |  "
        f"{t('gain_label')}: {result['n_gain']}",
        fontsize=13, fontweight="bold", y=1.01,
    )

    # ── 公共绘制函数 ────────────────────────────────────────────────────────
    def _draw(ax, img_display, labels_show, title, mark_lost=True):
        ax.imshow(img_display, cmap="gray", interpolation="nearest")
        ax.set_title(title, fontsize=11)
        ax.axis("off")

        for k, (yc, xc) in enumerate(centers):
            e, l, lost, gain = le[k], ll[k], lo[k], lg[k]
            if lost:
                # 损失：红色 ×
                ax.plot(xc, yc, "rx", markersize=7, markeredgewidth=2)
            elif gain:
                # 新增：蓝色 +
                ax.plot(xc, yc, "b+", markersize=8, markeredgewidth=2)
            elif e == 1 and l == 1:
                # 保留：绿色圆
                ax.plot(xc, yc, "go", markersize=5, alpha=0.7,
                        markerfacecolor="none", markeredgewidth=1.5)
            # 空格点不标记，保持图面整洁

    # ── 左图：前5帧叠加 ─────────────────────────────────────────────────────
    _draw(axes[0], early, le,
          f"{t('early_title')} ({t('early_exp')})\n{t('atoms')}={result['n_early']}")

    # ── 中图：第6帧 ──────────────────────────────────────────────────────────
    _draw(axes[1], late, ll,
          f"{t('late_title')} (160 ms)\n{t('atoms')}={result['n_late']}")

    # ── 右图：差异图（仅突出损失/新增） ─────────────────────────────────────
    # 用叠加图做背景，降亮并用颜色标记变化
    diff_bg = early * 0.4   # 降亮背景
    rgb = np.stack([diff_bg, diff_bg, diff_bg], axis=-1)

    ax = axes[2]
    ax.imshow(rgb, interpolation="nearest")
    ax.set_title(
        f"{t('diff_title')}\n{t('lost_label')}(\u00d7)={result['n_lost']}  {t('gain_label')}(+)={result['n_gain']}",
        fontsize=11)
    ax.axis("off")

    for k, (yc, xc) in enumerate(centers):
        if lo[k]:
            ax.plot(xc, yc, "rx", markersize=10, markeredgewidth=2.5)
        elif lg[k]:
            ax.plot(xc, yc, "b+", markersize=10, markeredgewidth=2.5)
        elif le[k] == 1 and ll[k] == 1:
            ax.plot(xc, yc, "go", markersize=4, alpha=0.5,
                    markerfacecolor="none", markeredgewidth=1.2)

    # ── 图例 ─────────────────────────────────────────────────────────────────
    legend_elements = [
        mpatches.Patch(color="green",  label=f"{t('retain_label')}  {int(np.sum((le==1)*(ll==1)))}"),
        mpatches.Patch(color="red",    label=f"{t('lost_label')}    {result['n_lost']}"),
        mpatches.Patch(color="blue",   label=f"{t('gain_label')}    {result['n_gain']}"),
    ]
    fig.legend(handles=legend_elements, loc="lower center",
               ncol=3, fontsize=11, bbox_to_anchor=(0.5, -0.02))

    plt.tight_layout()

    if save_path is not None:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  [保存] {save_path}")

    return fig


def plot_batch_statistics(
    records: List[Dict],
    output_dir: Path,
):
    """
    批量统计图：
    1. 损失率分布直方图
    2. 前5帧原子数 vs 损失率散点图
    3. 每组损失原子数排序图
    """
    gids      = [r["group_id"]  for r in records]
    loss_rates = [r["loss_rate"] * 100 for r in records]
    n_early    = [r["n_early"]   for r in records]
    n_lost     = [r["n_lost"]    for r in records]
    n_late     = [r["n_late"]    for r in records]

    fig, axes = plt.subplots(1, 3, figsize=(20, 6))
    fig.suptitle(
        f"Atom Loss Batch Statistics  ({len(records)} groups)\n"
        f"Mean: {np.mean(loss_rates):.2f}%  |  "
        f"Median: {np.median(loss_rates):.2f}%  |  "
        f"Max: {np.max(loss_rates):.2f}%  |  Min: {np.min(loss_rates):.2f}%",
        fontsize=13, fontweight="bold",
    )

    # ── 1. 损失率直方图 ──────────────────────────────────────────────────────
    ax = axes[0]
    ax.hist(loss_rates, bins=30, color="#e05c5c", edgecolor="white", linewidth=0.5)
    ax.axvline(np.mean(loss_rates),  color="red",    linestyle="--", label=f"{t('mean_label')} {np.mean(loss_rates):.2f}%")
    ax.axvline(np.median(loss_rates), color="orange", linestyle="--", label=f"{t('median_label')} {np.median(loss_rates):.2f}%")
    ax.set_xlabel(t('loss_pct'), fontsize=11)
    ax.set_ylabel(t('group_count'), fontsize=11)
    ax.set_title(t('hist_title'), fontsize=12)
    ax.legend(fontsize=9)

    # ── 2. 初始原子数 vs 损失率 ─────────────────────────────────────────────
    ax = axes[1]
    sc = ax.scatter(n_early, loss_rates, c=loss_rates,
                    cmap="RdYlGn_r", alpha=0.7, s=20, edgecolors="none")
    plt.colorbar(sc, ax=ax, label=t('loss_pct'))
    ax.set_xlabel(t('init_atoms'), fontsize=11)
    ax.set_ylabel(t('loss_pct'), fontsize=11)
    ax.set_title(t('scatter_title'), fontsize=12)

    # ── 3. 各组损失原子数（排序） ────────────────────────────────────────────
    ax = axes[2]
    sorted_idx = np.argsort(n_lost)[::-1]
    colors = ["#e05c5c" if n_lost[i] > 0 else "#aaaaaa" for i in sorted_idx]
    ax.bar(range(len(records)), [n_lost[i] for i in sorted_idx],
           color=colors, width=1.0, edgecolor="none")
    ax.set_xlabel(t('sorted_groups'), fontsize=11)
    ax.set_ylabel(t('loss_atoms'), fontsize=11)
    ax.set_title(t('bar_title'), fontsize=12)

    plt.tight_layout()
    save_path = output_dir / "batch_statistics.png"
    output_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    print(f"[保存] 批量统计图 → {save_path}")
    return fig


# ══════════════════════════════════════════════════════════════════════════════
# CSV 导出
# ══════════════════════════════════════════════════════════════════════════════

def save_csv(records: List[Dict], output_dir: Path):
    """将所有组的统计结果保存为 CSV。"""
    csv_path = output_dir / "atom_loss_stats.csv"
    output_dir.mkdir(parents=True, exist_ok=True)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "group_id", "n_early", "n_late",
            "n_lost", "n_gain", "loss_rate_pct",
        ])
        writer.writeheader()
        for r in records:
            writer.writerow({
                "group_id":      r["group_id"],
                "n_early":       r["n_early"],
                "n_late":        r["n_late"],
                "n_lost":        r["n_lost"],
                "n_gain":        r["n_gain"],
                "loss_rate_pct": f"{r['loss_rate']*100:.4f}",
            })
    print(f"[保存] CSV → {csv_path}")


# ══════════════════════════════════════════════════════════════════════════════
# 主流程
# ══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="原子损失分析：对比前5帧叠加 vs 第6帧（160ms）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--data-root",  required=True,  type=Path,
                        help="原始数据根目录（含 1~1001 子目录）")
    parser.add_argument("--output-dir", required=True,  type=Path,
                        help="输出目录")
    parser.add_argument("--group-id",   type=int, default=None,
                        help="单组分析时指定组编号")
    parser.add_argument("--all",        action="store_true",
                        help="分析所有组（批量模式）")
    parser.add_argument("--max-groups", type=int, default=None,
                        help="批量模式最多分析前 N 组（用于快速测试）")
    parser.add_argument("--save-single",action="store_true", default=True,
                        help="批量模式下是否保存每组的单图（默认：是）")
    parser.add_argument("--no-single",  action="store_true",
                        help="批量模式下不保存每组单图（仅保存汇总图）")
    # 格点参数
    parser.add_argument("--n-rows",   type=int,   default=DEFAULT_N_ROWS)
    parser.add_argument("--n-cols",   type=int,   default=DEFAULT_N_COLS)
    parser.add_argument("--spacing",  type=int,   default=DEFAULT_SPACING,
                        help="格点间距（像素）")
    parser.add_argument("--sigma-thr",type=float, default=DEFAULT_SIGMA_THR,
                        help="检测阈值（sigma 倍数），默认 4.0")
    args = parser.parse_args()

    data_root  = args.data_root
    output_dir = args.output_dir
    n_rows, n_cols = args.n_rows, args.n_cols
    spacing = args.spacing
    sigma_thr = args.sigma_thr
    save_single = args.save_single and not args.no_single

    # ── 确定要分析的组列表 ─────────────────────────────────────────────────
    if args.all:
        group_ids = find_groups(data_root)
        if args.max_groups:
            group_ids = group_ids[:args.max_groups]
        print(f"批量模式：共 {len(group_ids)} 组")
    elif args.group_id is not None:
        group_ids = [args.group_id]
        print(f"单组模式：group_id={args.group_id}")
    else:
        parser.error("请指定 --group-id <id> 或 --all")

    # ── 逐组分析 ───────────────────────────────────────────────────────────
    records = []
    failed  = []
    for gid in group_ids:
        group_dir = data_root / str(gid)
        result = analyze_group(group_dir, n_rows, n_cols, spacing, sigma_thr)

        if result is None:
            print(f"  [跳过] group {gid}：图像缺失")
            failed.append(gid)
            continue

        result["group_id"] = gid
        records.append(result)

        # 打印单组结果
        print(
            f"  group {gid:4d} | "
            f"前5帧: {result['n_early']:3d}  →  160ms: {result['n_late']:3d}  | "
            f"损失: {result['n_lost']:3d} ({result['loss_rate']*100:5.1f}%)  "
            f"新增: {result['n_gain']:2d}"
        )

        # 保存单组图
        if save_single:
            save_path = output_dir / "single_groups" / f"group_{gid:04d}.png"
            plot_single_group(result, gid, n_rows, n_cols, spacing, save_path)
            plt.close("all")

    if not records:
        print("无有效数据，退出。")
        return

    # ── 汇总统计 ───────────────────────────────────────────────────────────
    loss_rates = [r["loss_rate"] * 100 for r in records]
    n_early_all = [r["n_early"] for r in records]
    print("\n" + "═" * 60)
    print(f"  分析完成：{len(records)} 组成功 / {len(failed)} 组失败")
    print(f"  前5帧平均原子数 : {np.mean(n_early_all):.1f}")
    print(f"  平均损失率      : {np.mean(loss_rates):.2f}%")
    print(f"  中位数损失率    : {np.median(loss_rates):.2f}%")
    print(f"  最大损失率      : {np.max(loss_rates):.2f}%  (group {records[np.argmax(loss_rates)]['group_id']})")
    print(f"  最小损失率      : {np.min(loss_rates):.2f}%  (group {records[np.argmin(loss_rates)]['group_id']})")
    print("═" * 60)

    # ── 批量图 + CSV ──────────────────────────────────────────────────────
    if len(records) > 1:
        plot_batch_statistics(records, output_dir)
        plt.close("all")
    save_csv(records, output_dir)


if __name__ == "__main__":
    main()
