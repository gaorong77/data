"""
scripts/infer_demo.py
PA-3HDA 端到端推理演示

用法:
  python scripts/infer_demo.py --config configs/default.yaml \\
      --data-dir data/datasets/dataset_v4 --frame 0

输出:
  - 显示短曝光 + 长曝光图像
  - 打印每个原子的预测结果和 GT 对比
  - 输出帧级保真度
"""

import argparse
import sys
import numpy as np
from pathlib import Path
import time

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import torch
import yaml
from models.pa3hda import PA3HDA


def main():
    parser = argparse.ArgumentParser(description='PA-3HDA 推理演示')
    parser.add_argument('--config',   default='configs/default.yaml')
    parser.add_argument('--data-dir', required=True)
    parser.add_argument('--split',    default='test')
    parser.add_argument('--frame',    type=int, default=0)
    parser.add_argument('--l1',       default=None)
    parser.add_argument('--l1-wide',  default=None)
    parser.add_argument('--l2',       default=None)
    parser.add_argument('--l3',       default=None)
    parser.add_argument('--no-plot',  action='store_true')
    args = parser.parse_args()

    with open(args.config, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    # 加载模型
    model = PA3HDA(args.config)
    ck    = cfg['checkpoint']
    model.load_weights(
        l1      = args.l1      or ck.get('l1_path'),
        l1_wide = args.l1_wide or ck.get('l1_wide_path'),
        l2      = args.l2      or ck.get('l2_path'),
        l3      = args.l3      or ck.get('l3_path'),
    )
    model.to_device()
    print(f'推理设备: {model.device}')

    # 加载数据
    data_path = Path(args.data_dir) / f'{args.split}.npz'
    data = np.load(data_path, allow_pickle=True)
    images_short = data['images_short'].astype(np.float32)
    images_long  = data['images_long'].astype(np.float32)
    gt_labels    = data['labels'].astype(np.int32)
    centers      = data['centers']

    max_s = float(np.percentile(images_short, 99.9)) + 1e-6
    max_l = float(np.percentile(images_long,  99.9)) + 1e-6

    frame_idx = args.frame % images_short.shape[0]
    img_s = images_short[frame_idx] / max_s
    img_l = images_long[frame_idx]  / max_l
    gt    = gt_labels[frame_idx]
    K     = len(centers)

    # 推理计时
    t0   = time.perf_counter()
    pred = model.forward(img_s, img_l, centers.copy().astype(float))
    t1   = time.perf_counter()
    elapsed_ms = (t1 - t0) * 1000

    # 结果
    correct = np.sum(pred == gt)
    fidelity = 1.0 if np.all(pred == gt) else 0.0
    far = np.sum((pred == 1) & (gt == 0)) / max(np.sum(gt == 0), 1)
    mdr = np.sum((pred == 0) & (gt == 1)) / max(np.sum(gt == 1), 1)

    print(f'\n═══ 帧 {frame_idx} 推理结果 ═══')
    print(f'  推理耗时: {elapsed_ms:.2f} ms  |  设备: {model.device}')
    print(f'  原子总数: {K}  正确: {correct}/{K}')
    print(f'  帧保真度: {fidelity:.0f}  FAR: {far:.4f}  MDR: {mdr:.4f}')
    print(f'  GT 有原子: {int(gt.sum())}  预测有原子: {int(pred.sum())}')

    # 可视化
    if not args.no_plot:
        import matplotlib
        matplotlib.use('TkAgg')
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
        fig.suptitle(f'PA-3HDA 推理演示 - 帧 {frame_idx}  '
                     f'(保真度={fidelity:.0f}, {elapsed_ms:.1f}ms)')

        vmin_s = np.percentile(img_s, 1); vmax_s = np.percentile(img_s, 99)
        vmin_l = np.percentile(img_l, 1); vmax_l = np.percentile(img_l, 99)

        axes[0].imshow(img_s, cmap='gray', vmin=vmin_s, vmax=vmax_s)
        axes[0].set_title('短曝光图像 (L1 输入)')
        axes[1].imshow(img_l, cmap='gray', vmin=vmin_l, vmax=vmax_l)
        axes[1].set_title('长曝光图像 (L2 输入)')

        for i, ((cy, cx), p, g) in enumerate(zip(centers, pred, gt)):
            for ax in axes:
                if p == g:
                    color = 'lime'
                elif p == 1 and g == 0:
                    color = 'yellow'   # 误报
                else:
                    color = 'red'      # 漏检
                ax.plot(cx, cy, 'o', color=color, ms=8, mew=1.5, alpha=0.7,
                        markerfacecolor='none')

        # 图例
        from matplotlib.lines import Line2D
        legend = [
            Line2D([0],[0],marker='o',color='w',markerfacecolor='none',
                   markeredgecolor='lime', ms=8, label='正确'),
            Line2D([0],[0],marker='o',color='w',markerfacecolor='none',
                   markeredgecolor='yellow', ms=8, label='误报(FA)'),
            Line2D([0],[0],marker='o',color='w',markerfacecolor='none',
                   markeredgecolor='red', ms=8, label='漏检(MD)'),
        ]
        axes[0].legend(handles=legend, loc='lower right', fontsize=9)
        plt.tight_layout()
        plt.show()


if __name__ == '__main__':
    main()
