# import torch, numpy, scipy, matplotlib, yaml, PIL
# print('=== PA-3HDA 环境验证 ===')
# print(f'PyTorch:    {torch.__version__}')
# print(torch.cuda.is_available() )
# print(numpy.__version__)
# print(f'SciPy:      {scipy.__version__}')
# print(f'Matplotlib: {matplotlib.__version__}')
# print('=== 验证通过 ✓ ===')


import sys
sys.path.insert(0, '.')
print('1. 基础导入...')
import torch, yaml, numpy as np
print('2. dataset...')
from data.dataset import L1Dataset, L2Dataset, L3Dataset
print('3. models...')
from models.l1_roi_cnn import L1_ROI_CNN
from models.l3_unet import L3_UNet
print('4. trainer...')
from train.trainer import Trainer
print('5. visualizer...')
from train.visualizer import Visualizer
print('全部 OK')
