"""
scripts/run_train.py
PA-3HDA 主训练脚本

用法:
  # 训练 L1 模型（推荐先训练 L1）
  python scripts/run_train.py --model l1 --data-dir data/datasets/dataset_v4

  # 训练 L1-Wide 模型（串扰精判）
  python scripts/run_train.py --model l1_wide --data-dir data/datasets/dataset_v4

  # 训练 L2 模型（弱信号精判，长曝光）
  python scripts/run_train.py --model l2 --data-dir data/datasets/dataset_v4

  # 训练 L3 模型（后台全图校准）
  python scripts/run_train.py --model l3 --data-dir data/datasets/dataset_v4

  # 指定配置文件
  python scripts/run_train.py --model l1 --data-dir ... --config configs/default.yaml
"""

import argparse
import sys
from pathlib import Path

# 确保从工程根目录导入
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import torch
import yaml

from data.dataset import L1Dataset, L2Dataset, L3Dataset
from models.l1_roi_cnn import L1_ROI_CNN
from models.l3_unet import L3_UNet
from train.trainer import Trainer
from train.visualizer import Visualizer


def get_device(cfg):
    dev_cfg = cfg['device']
    if dev_cfg['auto']:
        # 强制清除某些异常状态的显存
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            device = torch.device('cuda')
            # 增加显存检测逻辑
            mem_free, mem_total = torch.cuda.mem_get_info(0)
            print(f'[Device] CUDA 可用: {torch.cuda.get_device_name(0)}'
                  f' (显存: {mem_free // 1024**2} / {mem_total // 1024**2} MB 可用)')
            if dev_cfg.get('cuda_benchmark', True):
                torch.backends.cudnn.benchmark = True
        elif torch.backends.mps.is_available():
            device = torch.device('mps')
            print('[Device] Apple MPS 可用')
        else:
            device = torch.device('cpu')
            print('[Device] 使用 CPU (警告: 未检测到显卡驱动或 PyTorch CUDA 版本不对)')
    else:
        device = torch.device(dev_cfg['force'])
    return device


def main():
    parser = argparse.ArgumentParser(description='PA-3HDA 训练')
    parser.add_argument('--model',    required=True,
                        choices=['l1', 'l1_wide', 'l2', 'l3'])
    parser.add_argument('--data-dir', required=True,
                        help='数据集目录（含 train.npz/val.npz）')
    parser.add_argument('--config',   default='configs/default.yaml')
    parser.add_argument('--epochs',   type=int, default=None)
    parser.add_argument('--lr',       type=float, default=None)
    parser.add_argument('--batch-size', type=int, default=None)
    parser.add_argument('--no-viz',   action='store_true',
                        help='关闭可视化')
    args = parser.parse_args()

    # 读取配置
    with open(args.config, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    device = get_device(cfg)

    train_path = Path(args.data_dir) / 'train.npz'
    val_path   = Path(args.data_dir) / 'val.npz'
    assert train_path.exists(), f'训练集不存在: {train_path}'
    assert val_path.exists(),   f'验证集不存在: {val_path}'

    roi_n      = cfg['roi']['n']
    roi_n_wide = roi_n * cfg['roi']['k_wide']
    m_cfg      = cfg['model']
    ck_cfg     = cfg['checkpoint']
    viz_cfg    = cfg['visualization']

    # ── 可视化器 ──
    if not args.no_viz and viz_cfg.get('enabled', True):
        viz = Visualizer(
            backend  = viz_cfg.get('backend', 'matplotlib'),
            log_dir  = viz_cfg.get('log_dir', './logs'),
            run_name = f'pa3hda_{args.model}',
            save_plots = viz_cfg.get('save_plots', True),
        )
    else:
        viz = None

    # ── 根据 model 类型分支 ──
    if args.model == 'l1':
        print(f'\n═══ 训练 L1 ROI-CNN (短曝光 {roi_n}×{roi_n}) ═══')
        tr_cfg = cfg['training']['l1']
        if args.epochs:   tr_cfg['epochs']     = args.epochs
        if args.lr:       tr_cfg['lr']          = args.lr
        if args.batch_size: tr_cfg['batch_size'] = args.batch_size

        train_ds = L1Dataset(str(train_path), roi_n=roi_n, augment=True)
        val_ds   = L1Dataset(str(val_path),   roi_n=roi_n, augment=False)
        model    = L1_ROI_CNN(**{k: m_cfg['l1'][k] for k in
                                 ['in_channels','hidden_channels','out_channels']})
        save_path = ck_cfg['l1_path']

        trainer = Trainer(model, train_ds, val_ds, tr_cfg, save_path,
                          device, model_type='l1', visualizer=viz)

    elif args.model == 'l1_wide':
        print(f'\n═══ 训练 L1-Wide (短曝光 {roi_n_wide}×{roi_n_wide}) ═══')
        tr_cfg = cfg['training']['l1_wide']
        if args.epochs:   tr_cfg['epochs']     = args.epochs
        if args.lr:       tr_cfg['lr']          = args.lr
        if args.batch_size: tr_cfg['batch_size'] = args.batch_size

        train_ds  = L1Dataset(str(train_path), roi_n=roi_n_wide, augment=True)
        val_ds    = L1Dataset(str(val_path),   roi_n=roi_n_wide, augment=False)
        model     = L1_ROI_CNN(**{k: m_cfg['l1_wide'][k] for k in
                                  ['in_channels','hidden_channels','out_channels']})
        save_path = ck_cfg['l1_wide_path']

        trainer = Trainer(model, train_ds, val_ds, tr_cfg, save_path,
                          device, model_type='l1_wide', visualizer=viz)

    elif args.model == 'l2':
        print(f'\n═══ 训练 L2-Weak (长曝光 {roi_n}×{roi_n}) ═══')
        tr_cfg = cfg['training']['l2']
        if args.epochs:   tr_cfg['epochs']     = args.epochs
        if args.lr:       tr_cfg['lr']          = args.lr
        if args.batch_size: tr_cfg['batch_size'] = args.batch_size

        # L2 使用长曝光数据 + 均衡采样
        train_ds  = L2Dataset(str(train_path), roi_n=roi_n, augment=True)
        val_ds    = L2Dataset(str(val_path),   roi_n=roi_n, augment=False)
        model     = L1_ROI_CNN(**{k: m_cfg['l2'][k] for k in
                                  ['in_channels','hidden_channels','out_channels']})
        save_path = ck_cfg['l2_path']
        use_bal   = tr_cfg.get('use_balanced_sampler', True)

        trainer = Trainer(model, train_ds, val_ds, tr_cfg, save_path,
                          device, model_type='l2',
                          use_balanced_sampler=use_bal, visualizer=viz)

    elif args.model == 'l3':
        print(f'\n═══ 训练 L3 U-Net (全图热力图) ═══')
        tr_cfg = cfg['training']['l3']
        if args.epochs:   tr_cfg['epochs']     = args.epochs
        if args.lr:       tr_cfg['lr']          = args.lr
        if args.batch_size: tr_cfg['batch_size'] = args.batch_size

        sigma = tr_cfg.get('gaussian_sigma', cfg['simulation']['psf_sigma'])
        # 训练集开启随机裁剪 (256x256)
        train_ds = L3Dataset(str(train_path), sigma=sigma, is_train=True)
        # 验证集使用中心固定裁剪 (512x512)
        val_ds   = L3Dataset(str(val_path),   sigma=sigma, is_train=False)
        model    = L3_UNet(
            in_channels   = m_cfg['l3']['in_channels'],
            base_channels = m_cfg['l3']['base_channels'])
        save_path = ck_cfg['l3_path']

        trainer = Trainer(model, train_ds, val_ds, tr_cfg, save_path,
                          device, model_type='l3', visualizer=viz)

    # ── 执行训练 ──
    best_fidelity, history = trainer.train()
    print(f'\n[完成] {args.model.upper()} 最优 Fidelity = {best_fidelity:.4f}')
    print(f'权重已保存: {save_path}')


if __name__ == '__main__':
    main()
