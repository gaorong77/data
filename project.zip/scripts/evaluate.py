"""
scripts/evaluate.py
PA-3HDA 系统级评估脚本

评估指标:
  - Fidelity      : 保真度（目标 >0.999）
  - FAR           : 误报率 False Alarm Rate（目标 <0.0005）
  - MDR           : 漏检率 Miss Detection Rate（目标 <0.0005）
  - L1 直接判决率  : 通过快速通道的比例
  - L2 路由比例    : 进入弱信号精判的比例
  - L1.5 路由统计  : 各分流通道占比

用法:
  python scripts/evaluate.py --config configs/default.yaml --data-dir data/datasets/dataset_v4

  # 指定权重目录
  python scripts/evaluate.py --config configs/default.yaml \\
      --data-dir data/datasets/dataset_v4 \\
      --l1 checkpoints/l1_best.pth \\
      --l1-wide checkpoints/l1_wide_best.pth \\
      --l2 checkpoints/l2_best.pth \\
      --l3 checkpoints/l3_best.pth
"""

import argparse
import sys
import numpy as np
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import torch
import yaml
from models.pa3hda import PA3HDA


def evaluate(model: PA3HDA, test_path: str, n_frames: int = None):
    """
    运行完整系统评估。

    Returns:
        metrics dict
    """
    data = np.load(test_path, allow_pickle=True)
    images_short = data['images_short'].astype(np.float32)
    images_long  = data['images_long'].astype(np.float32)
    gt_labels    = data['labels'].astype(np.int32)      # (N, K)
    centers      = data['centers']                       # (K, 2)

    # 归一化
    max_s = float(np.percentile(images_short, 99.9)) + 1e-6
    max_l = float(np.percentile(images_long,  99.9)) + 1e-6

    N = images_short.shape[0]
    if n_frames:
        N = min(N, n_frames)

    total_atoms    = 0
    correct_atoms  = 0
    false_alarms   = 0
    miss_detects   = 0
    n_frames_perfect = 0

    print(f'评估帧数: {N}  原子数/帧: {len(centers)}')
    print('─' * 50)

    for i in range(N):
        img_s = images_short[i] / max_s
        img_l = images_long[i]  / max_l
        gt    = gt_labels[i]    # (K,)

        pred  = model.forward(img_s, img_l, centers.copy().astype(float))

        # 指标统计
        K = len(gt)
        for k in range(K):
            if gt[k] == 1 and pred[k] == 1:
                correct_atoms += 1
            elif gt[k] == 0 and pred[k] == 1:
                false_alarms += 1
            elif gt[k] == 1 and pred[k] == 0:
                miss_detects += 1
        total_atoms += K

        if np.all(pred == gt):
            n_frames_perfect += 1

        if (i + 1) % 50 == 0:
            cur_fid = n_frames_perfect / (i + 1)
            print(f'  进度 {i+1}/{N}  当前保真度: {cur_fid:.4f}')

    # ── 计算最终指标 ──
    n_pos_gt   = int(gt_labels[:N].sum())
    n_neg_gt   = N * len(centers) - n_pos_gt

    fidelity   = n_frames_perfect / N
    far        = false_alarms / max(n_neg_gt, 1)   # FP / 真负样本数
    mdr        = miss_detects / max(n_pos_gt, 1)   # FN / 真正样本数
    atom_acc   = correct_atoms / max(total_atoms, 1)

    metrics = {
        'fidelity'         : fidelity,
        'FAR'              : far,
        'MDR'              : mdr,
        'atom_accuracy'    : atom_acc,
        'frames_perfect'   : n_frames_perfect,
        'total_frames'     : N,
        'false_alarms'     : false_alarms,
        'miss_detects'     : miss_detects,
        'total_atoms'      : total_atoms,
    }
    return metrics


def print_metrics(metrics: dict):
    print('\n' + '═' * 55)
    print('  PA-3HDA 系统评估结果')
    print('═' * 55)
    fid  = metrics['fidelity']
    far  = metrics['FAR']
    mdr  = metrics['MDR']
    acc  = metrics['atom_accuracy']

    def status(val, target, less_is_better=False):
        if less_is_better:
            return '✓ 达标' if val < target else '✗ 未达标'
        else:
            return '✓ 达标' if val >= target else '✗ 未达标'

    print(f'  保真度  (Fidelity) : {fid:.5f}  {status(fid,0.999)}  (目标 >0.999)')
    print(f'  误报率  (FAR)      : {far:.5f}  {status(far,0.0005,True)}  (目标 <0.0005)')
    print(f'  漏检率  (MDR)      : {mdr:.5f}  {status(mdr,0.0005,True)}  (目标 <0.0005)')
    print(f'  原子精度           : {acc:.5f}')
    print(f'  完美帧数           : {metrics["frames_perfect"]}/{metrics["total_frames"]}')
    print(f'  误报次数           : {metrics["false_alarms"]}')
    print(f'  漏检次数           : {metrics["miss_detects"]}')
    print('═' * 55)

    all_pass = fid >= 0.999 and far < 0.0005 and mdr < 0.0005
    if all_pass:
        print('  🎉 所有指标达标！系统满足 PA-3HDA 规格要求。')
    else:
        print('  ⚠ 部分指标未达标，请继续优化。')
    print('═' * 55)


def main():
    parser = argparse.ArgumentParser(description='PA-3HDA 系统评估')
    parser.add_argument('--config',   default='configs/default.yaml')
    parser.add_argument('--data-dir', required=True)
    parser.add_argument('--l1',       default=None)
    parser.add_argument('--l1-wide',  default=None)
    parser.add_argument('--l2',       default=None)
    parser.add_argument('--l3',       default=None)
    parser.add_argument('--n-frames', type=int, default=None,
                        help='评估帧数（默认全部）')
    args = parser.parse_args()

    with open(args.config, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    # 构建模型
    model = PA3HDA(args.config)

    # 加载权重（命令行参数优先，否则用配置文件路径）
    ck = cfg['checkpoint']
    model.load_weights(
        l1      = args.l1      or ck.get('l1_path'),
        l1_wide = args.l1_wide or ck.get('l1_wide_path'),
        l2      = args.l2      or ck.get('l2_path'),
        l3      = args.l3      or ck.get('l3_path'),
    )
    model.to_device()

    test_path = Path(args.data_dir) / 'test.npz'
    assert test_path.exists(), f'测试集不存在: {test_path}'

    metrics = evaluate(model, str(test_path), n_frames=args.n_frames)
    print_metrics(metrics)


if __name__ == '__main__':
    main()
