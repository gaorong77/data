"""
scripts/train_qat.py
PA-3HDA QAT 量化感知训练脚本（使用 Brevitas，CPU 训练）

用法:
  # 从 FP32 权重迁移后 QAT 微调
  python scripts/train_qat.py --model l1 \\
      --fp32-weights checkpoints/l1_best.pth \\
      --data-dir data/datasets/dataset_v4

  python scripts/train_qat.py --model l1_wide \\
      --fp32-weights checkpoints/l1_wide_best.pth \\
      --data-dir data/datasets/dataset_v4

  python scripts/train_qat.py --model l2 \\
      --fp32-weights checkpoints/l2_best.pth \\
      --data-dir data/datasets/dataset_v4

注意: QAT 强制使用 CPU（Brevitas 对 CUDA 支持不完整）
"""

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import torch
import torch.nn as nn
import yaml
import numpy as np
from torch.utils.data import DataLoader

from data.dataset import L1Dataset, L2Dataset
from models.l1_roi_cnn import L1_ROI_CNN

try:
    from models.l1_roi_cnn_qat import L1_ROI_CNN_QAT
    BREVITAS_OK = True
except ImportError:
    BREVITAS_OK = False


def qat_train(qat_model, train_loader, val_loader, cfg, save_path, device):
    """QAT 微调训练循环"""
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(
        qat_model.parameters(),
        lr=cfg.get('qat_lr', 1e-4),
        weight_decay=1e-4)

    epochs = cfg.get('qat_epochs', 20)
    best_fidelity = -1.0
    save_path = Path(save_path)

    print(f'QAT 训练 {epochs} epochs (CPU)')
    for ep in range(1, epochs + 1):
        # 训练
        qat_model.train()
        total_loss = 0.0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            out  = qat_model(x)
            loss = criterion(out, y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * x.size(0)
        train_loss = total_loss / len(train_loader.dataset)

        # 验证
        qat_model.eval()
        all_logits, all_labels = [], []
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(device), y.to(device)
                out = qat_model(x)
                all_logits.append(out.cpu())
                all_labels.append(y.cpu())
        logits = torch.cat(all_logits)
        labels = torch.cat(all_labels)
        preds  = (torch.sigmoid(logits) >= 0.5).long()
        acc    = (preds == labels.long()).float().mean().item()

        print(f'QAT Epoch [{ep:3d}/{epochs}]  '
              f'train_loss={train_loss:.4f}  acc={acc:.4f}', end='')

        if acc > best_fidelity:
            best_fidelity = acc
            torch.save(qat_model.state_dict(), save_path)
            print(f'  ★ → {save_path}')
        else:
            print()

    print(f'\nQAT 完成！最优精度 = {best_fidelity:.4f}')
    return best_fidelity


def main():
    parser = argparse.ArgumentParser(description='PA-3HDA QAT 训练')
    parser.add_argument('--model',        required=True,
                        choices=['l1', 'l1_wide', 'l2'])
    parser.add_argument('--fp32-weights', required=True,
                        help='FP32 预训练权重路径')
    parser.add_argument('--data-dir',     required=True)
    parser.add_argument('--config',       default='configs/default.yaml')
    parser.add_argument('--output',       default=None,
                        help='QAT 权重输出路径（默认 checkpoints/{model}_qat.pth）')
    args = parser.parse_args()

    if not BREVITAS_OK:
        print('错误: Brevitas 未安装')
        print('安装命令: pip install brevitas')
        sys.exit(1)

    with open(args.config, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    qat_cfg   = cfg['qat']
    roi_n     = cfg['roi']['n']
    roi_n_wide = roi_n * cfg['roi']['k_wide']
    m_cfg     = cfg['model']
    device    = torch.device('cpu')  # QAT 强制 CPU

    print(f'[QAT] 设备: CPU（Brevitas 要求）')

    # 确定数据集和 ROI 尺寸
    if args.model == 'l1':
        roi_size = roi_n
        train_ds = L1Dataset(str(Path(args.data_dir) / 'train.npz'),
                             roi_n=roi_size, augment=True)
        val_ds   = L1Dataset(str(Path(args.data_dir) / 'val.npz'),
                             roi_n=roi_size, augment=False)
        mc = m_cfg['l1']
    elif args.model == 'l1_wide':
        roi_size = roi_n_wide
        train_ds = L1Dataset(str(Path(args.data_dir) / 'train.npz'),
                             roi_n=roi_size, augment=True)
        val_ds   = L1Dataset(str(Path(args.data_dir) / 'val.npz'),
                             roi_n=roi_size, augment=False)
        mc = m_cfg['l1_wide']
    elif args.model == 'l2':
        roi_size = roi_n
        from data.dataset import L2Dataset
        train_ds = L2Dataset(str(Path(args.data_dir) / 'train.npz'),
                             roi_n=roi_size, augment=True)
        val_ds   = L2Dataset(str(Path(args.data_dir) / 'val.npz'),
                             roi_n=roi_size, augment=False)
        mc = m_cfg['l2']

    batch_size = cfg['training'][args.model].get('batch_size', 64)
    train_loader = DataLoader(train_ds, batch_size=batch_size,
                              shuffle=True, num_workers=0)
    val_loader   = DataLoader(val_ds,   batch_size=batch_size,
                              shuffle=False, num_workers=0)

    # 加载 FP32 模型权重
    fp32_model = L1_ROI_CNN(**{k: mc[k] for k in
                               ['in_channels','hidden_channels','out_channels']})
    fp32_model.load_state_dict(torch.load(args.fp32_weights,
                                          map_location='cpu',
                                          weights_only=True))
    print(f'[QAT] FP32 权重加载: {args.fp32_weights}')

    # 构建 QAT 模型并迁移权重
    qat_model = L1_ROI_CNN_QAT.from_fp32(fp32_model,
                                          in_ch=mc['in_channels'],
                                          hidden=mc['hidden_channels'],
                                          out_ch=mc['out_channels'])

    # 确定输出路径
    if args.output:
        save_path = args.output
    else:
        save_path = Path('checkpoints') / f'{args.model}_qat.pth'

    Path(save_path).parent.mkdir(parents=True, exist_ok=True)

    qat_train(qat_model, train_loader, val_loader, qat_cfg,
              save_path, device)


if __name__ == '__main__':
    main()
