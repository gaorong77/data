"""
models/__init__.py
PA-3HDA 模型包初始化（懒加载，避免循环导入）
"""

def get_l1_model(cfg=None):
    from models.l1_roi_cnn import L1_ROI_CNN
    if cfg is None:
        return L1_ROI_CNN()
    return L1_ROI_CNN(
        in_channels=cfg.get('in_channels', 1),
        hidden_channels=cfg.get('hidden_channels', 8),
        out_channels=cfg.get('out_channels', 16),
    )

def get_l3_model(cfg=None):
    from models.l3_unet import L3_UNet
    if cfg is None:
        return L3_UNet()
    return L3_UNet(in_channels=cfg.get('in_channels', 1),
                   base_channels=cfg.get('base_channels', 64))

def get_pa3hda(config_path='configs/default.yaml'):
    from models.pa3hda import PA3HDA
    return PA3HDA(config_path)
