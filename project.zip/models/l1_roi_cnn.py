"""
models/l1_roi_cnn.py
L1 ROI-CNN —— 轻量级二分类网络
适用于: L1 快速初判 (5×5 短曝光 ROI)
        L1-Wide 宽感受野精判 (51×51 短曝光 ROI)
        L2 弱信号精判 (17×17 长曝光 ROI)

关键设计:
  - AdaptiveAvgPool2d(1) 使网络接受任意尺寸输入
  - 总参数量: 357 (Conv1:80 + Conv2:1168 + FC:17 + bias:92)
  - 推理延迟: <10μs (FPGA INT8)
"""

import torch
import torch.nn as nn


class L1_ROI_CNN(nn.Module):
    """
    轻量级 ROI 二分类 CNN。

    Args:
        in_ch   : 输入通道数 (默认1, 灰度图)
        hidden  : Conv1 输出通道数
        out_ch  : Conv2 输出通道数
    """
    def __init__(self, in_channels: int = 1, hidden_channels: int = 8, out_channels: int = 16):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, kernel_size=3, padding=1, bias=True),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(hidden_channels, out_channels, kernel_size=3, padding=1, bias=True),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),   # 全局平均池化 → 尺寸无关
        )
        self.classifier = nn.Linear(out_channels, 1)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, nonlinearity='relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, 1, H, W)  H/W 任意 (≥4)
        Returns:
            logits: (B, 1)  使用 BCEWithLogitsLoss 时不需要 sigmoid
        """
        feat = self.features(x)          # (B, out_ch, 1, 1)
        feat = feat.view(feat.size(0), -1)  # (B, out_ch)
        return self.classifier(feat)     # (B, 1)

    @torch.no_grad()
    def predict_prob(self, x: torch.Tensor) -> torch.Tensor:
        """推理时调用: 返回概率值 [0,1]"""
        return torch.sigmoid(self.forward(x))

    def count_params(self) -> int:
        return sum(p.numel() for p in self.parameters())


if __name__ == '__main__':
    model = L1_ROI_CNN()
    print(f'L1_ROI_CNN 参数量: {model.count_params()}')
    # 测试不同输入尺寸
    for sz in [5, 17, 51]:
        x = torch.randn(4, 1, sz, sz)
        out = model(x)
        print(f'  输入 {sz}x{sz} → 输出 {out.shape}')
