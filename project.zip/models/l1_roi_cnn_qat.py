"""
models/l1_roi_cnn_qat.py
L1_ROI_CNN 的 QAT 量化感知训练版本（使用 Brevitas）
权重/激活量化为 INT8，用于 FPGA 部署。

注意: QAT 训练使用 CPU (Brevitas 对 CUDA 支持不完整)
"""

try:
    import brevitas.nn as qnn
    from brevitas.quant import Int8WeightPerTensorFloat, Int8ActPerTensorFloat
    BREVITAS_AVAILABLE = True
except ImportError:
    BREVITAS_AVAILABLE = False
    print('[QAT] Brevitas 未安装，QAT 模式不可用。')
    print('      安装: pip install brevitas')

import torch
import torch.nn as nn


class L1_ROI_CNN_QAT(nn.Module):
    """
    INT8 QAT 版本 L1 ROI-CNN。
    架构与 L1_ROI_CNN 完全相同，但用 QuantConv2d / QuantLinear 替换。
    """
    def __init__(self, in_ch=1, hidden=8, out_ch=16):
        super().__init__()

        if not BREVITAS_AVAILABLE:
            raise ImportError('请先安装 Brevitas: pip install brevitas')

        self.features = nn.Sequential(
            qnn.QuantConv2d(in_ch, hidden, kernel_size=3, padding=1, bias=True,
                            weight_quant=Int8WeightPerTensorFloat),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            qnn.QuantConv2d(hidden, out_ch, kernel_size=3, padding=1, bias=True,
                            weight_quant=Int8WeightPerTensorFloat),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
        )
        self.classifier = qnn.QuantLinear(out_ch, 1, bias=True,
                                          weight_quant=Int8WeightPerTensorFloat)

    def forward(self, x):
        feat = self.features(x)
        feat = feat.view(feat.size(0), -1)
        return self.classifier(feat)

    @torch.no_grad()
    def predict_prob(self, x):
        return torch.sigmoid(self.forward(x))

    @classmethod
    def from_fp32(cls, fp32_model, in_ch=1, hidden=8, out_ch=16):
        """
        从 FP32 L1_ROI_CNN 迁移权重到 QAT 模型。

        Usage:
            fp32 = L1_ROI_CNN(); fp32.load_state_dict(...)
            qat  = L1_ROI_CNN_QAT.from_fp32(fp32)
        """
        qat_model = cls(in_ch=in_ch, hidden=hidden, out_ch=out_ch)
        # 逐层迁移权重（忽略量化参数）
        fp32_state  = fp32_model.state_dict()
        qat_state   = qat_model.state_dict()
        for key in fp32_state:
            if key in qat_state:
                qat_state[key] = fp32_state[key]
        qat_model.load_state_dict(qat_state, strict=False)
        print('[QAT] FP32 权重迁移完成')
        return qat_model
