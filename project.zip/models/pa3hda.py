"""
models/pa3hda.py
PA-3HDA 主推理引擎
集成 L1 / L1.5 / L1-Wide / L2 / L3 五个模块的完整推理流程。

推理流程 (v9.1 原子保护 + L1 双端快速判决):
  输入: 短曝光全图 + 长曝光全图 + ROI 中心坐标
  1. 提取每个原子的 ROI (短曝光 n×n)
  2. L1 批量推理，双端快速判决:
       p > theta_h (0.95)           → 直接接受（有原子）
       p < theta_l (0.05)           → 直接拒绝（确定无原子）
       theta_l <= p <= theta_h      → 进入 L1.5 精判（模糊区间）
  3. L1.5 物理诊断（仅处理模糊区间样本）:
       邻居压力 > neighbor_pressure_thr → 串扰嫌疑 → L1-Wide
         p_wide > theta_wide            → 接受
         p_wide <= theta_wide           → 降级至 L2 终裁
       否则（弱信号 / 背景 / 边界）      → L2 终裁
  4. L2 长曝光终裁（模糊区间唯一"无原子"出口）
  5. 汇总: 输出 K 维状态向量
  (后台) L3: 每 1000 帧更新 ROI 中心坐标
"""

import torch
import torch.nn as nn
import numpy as np
import yaml
from pathlib import Path
from models.l1_roi_cnn import L1_ROI_CNN
from models.l3_unet import L3_UNet


class PA3HDA(nn.Module):
    """
    PA-3HDA 完整推理引擎 (v9.1 原子保护 + L1 双端快速判决)。

    Args:
        config_path: YAML 配置文件路径
    """

    def __init__(self, config_path: str = 'configs/default.yaml'):
        super().__init__()
        with open(config_path, 'r', encoding='utf-8') as f:
            cfg = yaml.safe_load(f)

        self.cfg = cfg
        roi_cfg  = cfg['roi']
        rt_cfg   = cfg['routing']
        dev_cfg  = cfg['device']

        self.n       = roi_cfg['n']           # ROI 边长
        self.k_wide  = roi_cfg['k_wide']      # 宽感受野倍数
        self.n_wide  = self.n * self.k_wide   # 宽感受野 ROI 边长

        # v9.1 路由阈值
        # p > theta_h          → 直接接受（有原子，高置信通行证）
        # p < theta_l          → 直接拒绝（确定无原子，theta_l 极低防漏检）
        # theta_l <= p <= theta_h → L1.5 模糊区精判
        self.theta_h    = rt_cfg['theta_h']
        self.theta_l    = rt_cfg.get('theta_l', 0.05)
        self.theta_wide = rt_cfg.get('theta_wide', 0.90)
        self.p_nbr_thr  = rt_cfg.get('neighbor_pressure_thr', self.theta_h)
        self.border_m   = rt_cfg.get('border_margin', 3)

        # ── 子网络 ──────────────────────────────────────────────
        m_cfg = cfg['model']
        self.l1      = L1_ROI_CNN(**{k: m_cfg['l1'][k] for k in
                                     ['in_channels', 'hidden_channels', 'out_channels']})
        self.l1_wide = L1_ROI_CNN(**{k: m_cfg['l1_wide'][k] for k in
                                     ['in_channels', 'hidden_channels', 'out_channels']})
        self.l2      = L1_ROI_CNN(**{k: m_cfg['l2'][k] for k in
                                     ['in_channels', 'hidden_channels', 'out_channels']})
        self.l3      = L3_UNet(
            in_channels=m_cfg['l3']['in_channels'],
            base_channels=m_cfg['l3']['base_channels']
        )

        # ── 设备 ────────────────────────────────────────────────
        if dev_cfg['auto']:
            if torch.cuda.is_available():
                self.device = torch.device('cuda')
            elif torch.backends.mps.is_available():
                self.device = torch.device('mps')
            else:
                self.device = torch.device('cpu')
        else:
            self.device = torch.device(dev_cfg['force'])

        self._l3_frame_counter = 0
        self._l3_trigger_every = 1000  # 每 N 帧运行 L3

    # ──────────────────────────────────────────────────────────
    # 权重加载
    # ──────────────────────────────────────────────────────────

    def load_weights(self, l1=None, l1_wide=None, l2=None, l3=None):
        """加载预训练权重（跨平台兼容 map_location）"""
        def _load(model, path, name):
            if path and Path(path).exists():
                state = torch.load(path, map_location=self.device,
                                   weights_only=True)
                model.load_state_dict(state)
                print(f'[PA3HDA] {name} 权重加载: {path}')
            else:
                print(f'[PA3HDA] {name} 未找到权重文件，使用随机初始化: {path}')
        _load(self.l1,      l1,      'L1')
        _load(self.l1_wide, l1_wide, 'L1-Wide')
        _load(self.l2,      l2,      'L2')
        _load(self.l3,      l3,      'L3')

    def load_from_config(self):
        """从配置文件中的路径加载所有权重"""
        ck = self.cfg['checkpoint']
        self.load_weights(
            l1      = ck.get('l1_path'),
            l1_wide = ck.get('l1_wide_path'),
            l2      = ck.get('l2_path'),
            l3      = ck.get('l3_path'),
        )

    # ──────────────────────────────────────────────────────────
    # ROI 提取（含边界保护）
    # ──────────────────────────────────────────────────────────

    def _extract_roi_safe(self, img: np.ndarray,
                          cy: float, cx: float,
                          roi_size: int) -> np.ndarray:
        """
        从图像中提取 roi_size×roi_size 的 ROI，越界部分填零。

        Args:
            img     : (H, W) numpy 图像
            cy, cx  : ROI 中心坐标 (float)
            roi_size: ROI 边长
        Returns:
            patch: (roi_size, roi_size) numpy
        """
        H, W = img.shape
        half = roi_size // 2
        r0 = int(round(cy)) - half
        r1 = r0 + roi_size
        c0 = int(round(cx)) - half
        c1 = c0 + roi_size
        patch = np.zeros((roi_size, roi_size), dtype=np.float32)
        # 计算有效区域
        pr0 = max(0, -r0);  pr1 = roi_size - max(0, r1 - H)
        pc0 = max(0, -c0);  pc1 = roi_size - max(0, c1 - W)
        ir0 = max(0, r0);   ir1 = min(H, r1)
        ic0 = max(0, c0);   ic1 = min(W, c1)
        if pr1 > pr0 and pc1 > pc0 and ir1 > ir0 and ic1 > ic0:
            patch[pr0:pr1, pc0:pc1] = img[ir0:ir1, ic0:ic1]
        return patch

    def _batch_extract_rois(self, img: np.ndarray,
                            centers: np.ndarray,
                            roi_size: int) -> torch.Tensor:
        """
        批量提取所有原子的 ROI。

        Args:
            img    : (H, W) numpy
            centers: (K, 2) numpy [(row, col)]
            roi_size: ROI 边长
        Returns:
            rois: (K, 1, roi_size, roi_size) FloatTensor
        """
        K = len(centers)
        rois = torch.zeros(K, 1, roi_size, roi_size, dtype=torch.float32)
        for i, (cy, cx) in enumerate(centers):
            patch = self._extract_roi_safe(img, cy, cx, roi_size)
            rois[i, 0] = torch.from_numpy(patch)
        return rois

    # ──────────────────────────────────────────────────────────
    # L1.5 物理诊断（v9.1：邻居压力判据）
    # ──────────────────────────────────────────────────────────

    def _neighbor_pressure(self, p_l1_all: np.ndarray, k: int) -> float:
        """
        计算格点 k 的 8-邻域 L1 概率最大值（邻居压力）。

        若返回值 > neighbor_pressure_thr，说明邻格存在高置信原子，
        当前格点的弱响应可能来自 PSF 边缘串扰，路由至 L1-Wide。

        Args:
            p_l1_all: (K,) 当前帧所有格点的 L1 概率
            k       : 当前格点索引
        Returns:
            max neighbor probability (float)
        """
        n_atoms = p_l1_all.shape[0]
        side = int(round(n_atoms ** 0.5))
        if side * side != n_atoms:
            return 0.0
        row, col = divmod(k, side)
        nbrs = []
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if dr == 0 and dc == 0:
                    continue
                nr, nc = row + dr, col + dc
                if 0 <= nr < side and 0 <= nc < side:
                    nbrs.append(float(p_l1_all[nr * side + nc]))
        return max(nbrs) if nbrs else 0.0

    # ──────────────────────────────────────────────────────────
    # 主推理入口
    # ──────────────────────────────────────────────────────────

    @torch.no_grad()
    def forward(self, img_short: np.ndarray,
                img_long: np.ndarray,
                centers: np.ndarray) -> np.ndarray:
        """
        完整推理流程 (v9.1 双端快速判决 + L1.5 模糊区精判)。

        Args:
            img_short: (H, W) 短曝光图像 (numpy, float32, 归一化到 [0,1])
            img_long : (H, W) 长曝光图像
            centers  : (K, 2) 原子 ROI 中心坐标 [(row, col)]
        Returns:
            labels   : (K,) int 数组，0=无原子，1=有原子
        """
        self.l1.eval().to(self.device)
        self.l1_wide.eval().to(self.device)
        self.l2.eval().to(self.device)

        K = len(centers)
        labels = np.zeros(K, dtype=np.int32)

        # ── Step 1: 批量 L1 推理（短曝光 n×n）──────────────────
        rois_short = self._batch_extract_rois(img_short, centers, self.n)
        rois_short = rois_short.to(self.device)
        logits = self.l1(rois_short).squeeze(1)   # (K,)
        probs  = torch.sigmoid(logits).cpu().numpy()

        # ── Step 2: L1 双端快速判决 ─────────────────────────────
        # 路径 A-accept: 高置信直接接受（有原子）
        labels[probs > self.theta_h] = 1
        # 路径 A-reject: 极低置信直接拒绝（theta_l=0.05 极低，防漏检）
        labels[probs < self.theta_l] = 0

        # ── Step 3: L1.5 精判（模糊区间 theta_l <= p <= theta_h）
        uncertain_indices = np.where(
            (probs >= self.theta_l) & (probs <= self.theta_h)
        )[0]

        for idx in uncertain_indices:
            cy, cx = centers[idx]

            # L1.5：邻居压力判断
            p_nbr = self._neighbor_pressure(probs, idx)

            if p_nbr > self.p_nbr_thr:
                # 串扰嫌疑：邻格存在高置信原子 → L1-Wide 辨识
                roi_wide = self._extract_roi_safe(img_short, cy, cx, self.n_wide)
                t = torch.from_numpy(roi_wide).unsqueeze(0).unsqueeze(0).to(self.device)
                p_wide = torch.sigmoid(self.l1_wide(t)).item()

                if p_wide > self.theta_wide:
                    # L1-Wide 确认：串扰中的真实原子
                    labels[idx] = 1
                else:
                    # L1-Wide 不确定 → 降级至 L2 长曝光终裁
                    roi_l2 = self._extract_roi_safe(img_long, cy, cx, self.n)
                    t = torch.from_numpy(roi_l2).unsqueeze(0).unsqueeze(0).to(self.device)
                    labels[idx] = 1 if torch.sigmoid(self.l2(t)).item() > 0.5 else 0
            else:
                # 弱信号 / 背景 / 边界 → L2 长曝光终裁
                roi_l2 = self._extract_roi_safe(img_long, cy, cx, self.n)
                t = torch.from_numpy(roi_l2).unsqueeze(0).unsqueeze(0).to(self.device)
                labels[idx] = 1 if torch.sigmoid(self.l2(t)).item() > 0.5 else 0

        # ── Step 4: 后台 L3（每 1000 帧）───────────────────────
        self._l3_frame_counter += 1
        if self._l3_frame_counter % self._l3_trigger_every == 0:
            centers[:] = self._l3_update_centers(img_short, centers)

        return labels

    # ──────────────────────────────────────────────────────────
    # L3 后台更新
    # ──────────────────────────────────────────────────────────

    def _l3_update_centers(self, img_short: np.ndarray,
                           centers: np.ndarray) -> np.ndarray:
        """L3 后台更新 ROI 中心坐标"""
        self.l3.eval().to(self.device)
        t = torch.from_numpy(img_short).unsqueeze(0).unsqueeze(0).to(self.device)
        heatmap = self.l3(t)  # (1, 1, H, W)
        peaks = self.l3.detect_peaks(
            heatmap,
            min_distance=self.cfg['array']['grid_spacing'] // 2
        )
        if len(peaks) == 0:
            return centers

        # 将检测峰值与网格中心匹配（最近邻）
        new_centers = centers.copy().astype(float)
        peaks_arr   = np.array(peaks)
        for i, (cy, cx) in enumerate(centers):
            dists = np.sqrt(((peaks_arr - [cy, cx]) ** 2).sum(axis=1))
            best  = int(np.argmin(dists))
            if dists[best] < self.cfg['array']['grid_spacing'] // 2:
                new_centers[i] = peaks_arr[best]
        return new_centers

    def to_device(self):
        self.l1.to(self.device)
        self.l1_wide.to(self.device)
        self.l2.to(self.device)
        self.l3.to(self.device)
        return self
