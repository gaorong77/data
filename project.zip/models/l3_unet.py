"""
models/l3_unet.py
L3 后台校准 U-Net ── 全图热力图回归
每 1000 帧运行一次，输出原子位置热力图，用于更新 ROI 中心坐标。

损失函数: MSE (连续热力图值，非二分类)
输入: 全图短曝光图像 (1, H, W)
输出: 热力图 (1, H, W)，值域 [0,1]，峰值对应原子位置
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class DoubleConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.conv(x)


class L3_UNet(nn.Module):
    """
    轻量 U-Net，参数量约 500K。

    Args:
        in_channels   : 输入通道 (默认1)
        base_channels : 编码器第一层通道数 (默认64)
    """
    def __init__(self, in_channels: int = 1, base_channels: int = 64):
        super().__init__()
        b = base_channels
        # Encoder
        self.enc1 = DoubleConv(in_channels, b)
        self.enc2 = DoubleConv(b,   b*2)
        self.enc3 = DoubleConv(b*2, b*4)
        # Bottleneck
        self.bottleneck = DoubleConv(b*4, b*8)
        # Decoder
        self.up3 = nn.ConvTranspose2d(b*8, b*4, 2, stride=2)
        self.dec3 = DoubleConv(b*8, b*4)
        self.up2 = nn.ConvTranspose2d(b*4, b*2, 2, stride=2)
        self.dec2 = DoubleConv(b*4, b*2)
        self.up1 = nn.ConvTranspose2d(b*2, b,   2, stride=2)
        self.dec1 = DoubleConv(b*2, b)
        # Output
        self.out_conv = nn.Conv2d(b, 1, 1)
        self.pool = nn.MaxPool2d(2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, 1, H, W)
        Returns:
            heatmap: (B, 1, H, W) sigmoid 输出，值域 [0,1]
        """
        # Encoder
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        # Bottleneck
        b  = self.bottleneck(self.pool(e3))
        # Decoder (with skip connections)
        # F.interpolate 确保 up 输出与 skip 特征图尺寸严格一致，
        # 避免奇数分辨率输入时 ConvTranspose2d 多出 1px 的问题。
        # nearest 插值：零额外显存，仅修剪/填充边缘 1px 对齐 skip connection
        up3 = F.interpolate(self.up3(b),  size=e3.shape[2:], mode='nearest')
        d3 = self.dec3(torch.cat([up3, e3], dim=1))
        up2 = F.interpolate(self.up2(d3), size=e2.shape[2:], mode='nearest')
        d2 = self.dec2(torch.cat([up2, e2], dim=1))
        up1 = F.interpolate(self.up1(d2), size=e1.shape[2:], mode='nearest')
        d1 = self.dec1(torch.cat([up1, e1], dim=1))
        return torch.sigmoid(self.out_conv(d1))

    def count_params(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def detect_peaks(self, heatmap: torch.Tensor,
                     min_distance: int = 10,
                     threshold: float = 0.5):
        """
        从热力图中检测峰值位置（原子坐标）。

        Args:
            heatmap    : (1, 1, H, W) 单帧热力图
            min_distance: 峰值间最小距离 (px)
            threshold  : 最小峰值强度

        Returns:
            peaks: list of (row, col) 坐标
        """
        import numpy as np
        from scipy.ndimage import maximum_filter, label as nd_label

        hm = heatmap.squeeze().cpu().numpy()
        # 局部极值: 在 min_distance 邻域内是最大值
        local_max = (hm == maximum_filter(hm, size=min_distance))
        above_thr = hm > threshold
        detected = local_max & above_thr
        labeled, num = nd_label(detected)
        peaks = []
        for i in range(1, num + 1):
            coords = np.argwhere(labeled == i)
            # 取区域内最强点
            best = coords[np.argmax([hm[r, c] for r, c in coords])]
            peaks.append((int(best[0]), int(best[1])))
        return peaks


if __name__ == '__main__':
    model = L3_UNet()
    print(f'L3_UNet 参数量: {model.count_params():,}')
    x = torch.randn(1, 1, 256, 256)
    y = model(x)
    print(f'  输入 {x.shape} → 输出 {y.shape}')
