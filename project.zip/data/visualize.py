"""
PA3HDA_v4/data/visualize.py
===========================
图像与标签可视化模块，支持：
  1. visualize_group()      — 单组6档曝光全览 + GT叠加
  2. visualize_labels()     — 原子标签格点图（叠加在最长曝光图上）
  3. visualize_roi_grid()   — 按格点索引显示ROI切片网格
  4. visualize_dataset()    — dataset.npz 随机抽帧预览
  5. compare_exposures()    — 任意两档曝光对比
  6. visualize_gt_pipeline()— Ground Truth生成流程分解
  7. visualize_heatmap()    — L3热力图预测 vs GT对比

用法示例：
    from data.visualize import visualize_group, visualize_labels
    visualize_group("D:/data/1", save_path="group1_overview.png")
    visualize_labels("D:/data/1", save_path="group1_labels.png")
"""

from __future__ import annotations

import glob
import json
from pathlib import Path
from typing import Optional, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

# ── 全局样式 ──────────────────────────────────────────────────────────────────
EXPOSURES = [8, 10, 20, 40, 80, 160]
CMAP_IMAGE = "magma"
CMAP_HEAT  = "hot"
ATOM_COLOR = "#00FF88"   # 有原子：绿
EMPTY_COLOR= "#FF4444"   # 无原子：红
GRID_COLOR = "#AAAAAA"   # 格点框：灰


# ═════════════════════════════════════════════════════════════════════════════
# 内部工具
# ═════════════════════════════════════════════════════════════════════════════

def _load_tif(folder: Path, exp: int) -> Optional[np.ndarray]:
    """从 {folder}/{exp}ms/ 或 {folder}/{exp}ms.tif 加载 TIF。"""
    candidates = list((folder / f"{exp}ms").glob("*.tif"))
    if not candidates:
        alt = folder / f"{exp}ms.tif"
        if alt.exists():
            candidates = [alt]
    if not candidates:
        return None
    img = Image.open(candidates[0])
    return np.array(img).astype(np.float32)


def _normalize(img: np.ndarray, pct: float = 99.5) -> np.ndarray:
    """百分位归一化到 [0, 1]。"""
    lo, hi = np.percentile(img, 0.5), np.percentile(img, pct)
    if hi <= lo:
        return np.zeros_like(img)
    return np.clip((img - lo) / (hi - lo), 0, 1)


def _draw_grid_overlay(ax, labels, offset_y, offset_x, spacing, roi_n=17,
                       show_empty=True):
    """在 ax 上叠加格点矩形（绿=有原子，红=无原子，灰=全部轮廓）。"""
    n_rows, n_cols = labels.shape
    half = roi_n // 2
    for r in range(n_rows):
        for c in range(n_cols):
            yc = offset_y + r * spacing
            xc = offset_x + c * spacing
            has_atom = bool(labels[r, c])
            if not has_atom and not show_empty:
                continue
            color = ATOM_COLOR if has_atom else EMPTY_COLOR
            rect = mpatches.Rectangle(
                (xc - half, yc - half), roi_n, roi_n,
                linewidth=0.6, edgecolor=color, facecolor="none", alpha=0.8
            )
            ax.add_patch(rect)
    # 格点标记点
    for r in range(n_rows):
        for c in range(n_cols):
            yc = offset_y + r * spacing
            xc = offset_x + c * spacing
            ax.plot(xc, yc, ".", markersize=1.5,
                    color=ATOM_COLOR if labels[r, c] else EMPTY_COLOR,
                    alpha=0.7)


def _auto_grid_offset(stacked: np.ndarray, spacing: int) -> tuple[int, int]:
    """通过全图最亮点推算格点偏移量。"""
    y_max, x_max = np.unravel_index(np.argmax(stacked), stacked.shape)
    return int(y_max % spacing), int(x_max % spacing)


def _infer_labels(stacked: np.ndarray, n_rows: int, n_cols: int,
                  spacing: int, offset_y: int, offset_x: int,
                  sigma: float = 5.0) -> np.ndarray:
    """从叠加图中推断 GT 标签。"""
    bg  = np.median(stacked)
    std = np.std(stacked - bg) + 1e-6
    labels = np.zeros((n_rows, n_cols), dtype=np.int32)
    for r in range(n_rows):
        for c in range(n_cols):
            yc = int(offset_y + r * spacing)
            xc = int(offset_x + c * spacing)
            if 0 <= yc < stacked.shape[0] and 0 <= xc < stacked.shape[1]:
                roi = stacked[max(0, yc-2):yc+3, max(0, xc-2):xc+3]
                if np.mean(roi) - bg > sigma * std:
                    labels[r, c] = 1
    return labels


def _save_or_show(fig, save_path: Optional[str], dpi: int = 150):
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=dpi, bbox_inches="tight",
                    facecolor=fig.get_facecolor())
        print(f"  [保存] {save_path}")
    else:
        plt.show()
    plt.close(fig)


# ═════════════════════════════════════════════════════════════════════════════
# 1. 单组6档曝光全览
# ═════════════════════════════════════════════════════════════════════════════

def visualize_group(group_dir: str,
                    exposures: Sequence[int] = EXPOSURES,
                    save_path: Optional[str] = None,
                    title: Optional[str] = None):
    """
    并排显示一组数据的所有档位曝光图像。

    Parameters
    ----------
    group_dir : str
        组目录，如 "D:/data/1"
    exposures : list[int]
        要显示的曝光档位列表，默认 [8,10,20,40,80,160]
    save_path : str, optional
        保存路径（None 则弹窗显示）
    title : str, optional
        图标题，默认使用目录名
    """
    folder = Path(group_dir)
    images = {}
    for exp in exposures:
        img = _load_tif(folder, exp)
        if img is not None:
            images[exp] = img

    if not images:
        print(f"[警告] 在 {group_dir} 中未找到 TIF 图像。")
        return

    n = len(images)
    fig, axes = plt.subplots(1, n, figsize=(4 * n, 4.5),
                              facecolor="#1a1a2e")

    if n == 1:
        axes = [axes]

    for ax, (exp, img) in zip(axes, images.items()):
        im_norm = _normalize(img)
        ax.imshow(im_norm, cmap=CMAP_IMAGE, aspect="equal",
                  interpolation="nearest")
        ax.set_title(f"{exp} ms\n({img.shape[1]}×{img.shape[0]}px)",
                     color="white", fontsize=9)
        ax.axis("off")
        # 统计
        peak_ph = int(img.max())
        ax.text(0.02, 0.02, f"peak={peak_ph}", transform=ax.transAxes,
                color="#FFDD57", fontsize=7, va="bottom")

    sup = title or f"Group: {folder.name}  –  {n} exposures"
    fig.suptitle(sup, color="white", fontsize=12, y=1.01)
    _save_or_show(fig, save_path)


# ═════════════════════════════════════════════════════════════════════════════
# 2. 标签叠加可视化
# ═════════════════════════════════════════════════════════════════════════════

def visualize_labels(group_dir: str,
                     n_rows: int = 20, n_cols: int = 20,
                     spacing: int = 54, roi_n: int = 17,
                     ref_exp: int = 160,
                     save_path: Optional[str] = None,
                     labels: Optional[np.ndarray] = None):
    """
    在参考曝光图像上叠加 GT 格点标签。

    左图：参考图 + 格点轮廓（绿=有原子，红=无原子）
    右图：标签热图（20×20 格点的 0/1 分布）

    Parameters
    ----------
    labels : np.ndarray, optional
        已知标签 [n_rows, n_cols]。若 None，则自动从叠加图推断。
    """
    folder = Path(group_dir)
    ref_img = _load_tif(folder, ref_exp)
    if ref_img is None:
        # 降级：尝试最长曝光
        for exp in reversed(EXPOSURES):
            ref_img = _load_tif(folder, exp)
            if ref_img is not None:
                ref_exp = exp
                break

    if ref_img is None:
        print(f"[警告] 未找到参考图像，跳过。")
        return

    # 生成叠加图 & 推断标签
    stacked = np.zeros_like(ref_img)
    for exp in EXPOSURES:
        img = _load_tif(folder, exp)
        if img is not None:
            stacked += img

    offset_y, offset_x = _auto_grid_offset(stacked, spacing)

    if labels is None:
        labels = _infer_labels(stacked, n_rows, n_cols, spacing,
                               offset_y, offset_x)

    n_atoms = int(np.sum(labels))
    fill_rate = n_atoms / (n_rows * n_cols) * 100

    fig, (ax_img, ax_label) = plt.subplots(1, 2, figsize=(14, 7),
                                            facecolor="#1a1a2e")

    # ── 左：参考图 + 格点标注 ─────────────────────────────────
    ax_img.imshow(_normalize(ref_img), cmap=CMAP_IMAGE, aspect="equal",
                  interpolation="nearest")
    _draw_grid_overlay(ax_img, labels, offset_y, offset_x, spacing,
                       roi_n=roi_n, show_empty=True)
    ax_img.set_title(f"{ref_exp}ms  |  原子: {n_atoms}/{n_rows*n_cols}"
                     f"  填充率: {fill_rate:.1f}%",
                     color="white", fontsize=11)
    ax_img.axis("off")

    # legend
    leg = [mpatches.Patch(edgecolor=ATOM_COLOR, facecolor="none",
                           label="有原子"),
           mpatches.Patch(edgecolor=EMPTY_COLOR, facecolor="none",
                           label="无原子")]
    ax_img.legend(handles=leg, loc="upper right", fontsize=8,
                  facecolor="#333", edgecolor="none",
                  labelcolor="white")

    # ── 右：标签热图 ─────────────────────────────────────────
    im2 = ax_label.imshow(labels, cmap="Greens", vmin=0, vmax=1,
                          aspect="equal", interpolation="nearest")
    ax_label.set_title("GT 标签（绿=有原子）",
                        color="white", fontsize=11)
    ax_label.set_xlabel("Col", color="white", fontsize=9)
    ax_label.set_ylabel("Row", color="white", fontsize=9)
    ax_label.tick_params(colors="white")
    for spine in ax_label.spines.values():
        spine.set_edgecolor("gray")
    # 在每格打印数字
    for r in range(n_rows):
        for c in range(n_cols):
            ax_label.text(c, r, str(labels[r, c]), ha="center", va="center",
                          fontsize=4.5, color="white" if labels[r, c] else "#555")
    plt.colorbar(im2, ax=ax_label, fraction=0.03, pad=0.02)

    fig.suptitle(f"Group: {folder.name}  –  Label Visualization",
                 color="white", fontsize=13)
    _save_or_show(fig, save_path)


# ═════════════════════════════════════════════════════════════════════════════
# 3. ROI 切片网格
# ═════════════════════════════════════════════════════════════════════════════

def visualize_roi_grid(group_dir: str,
                       exp: int = 8,
                       n_rows: int = 20, n_cols: int = 20,
                       spacing: int = 54, roi_n: int = 17,
                       save_path: Optional[str] = None):
    """
    将 n_rows×n_cols 个格点的 ROI 切片以网格形式展示。
    绿框=有原子，红框=无原子。
    """
    folder = Path(group_dir)
    img = _load_tif(folder, exp)
    if img is None:
        print(f"[警告] 未找到 {exp}ms 图像。")
        return

    stacked = np.zeros_like(img)
    for e in EXPOSURES:
        tmp = _load_tif(folder, e)
        if tmp is not None:
            stacked += tmp

    offset_y, offset_x = _auto_grid_offset(stacked, spacing)
    labels = _infer_labels(stacked, n_rows, n_cols, spacing,
                           offset_y, offset_x)

    half = roi_n // 2
    fig, axes = plt.subplots(n_rows, n_cols,
                              figsize=(n_cols * 1.2, n_rows * 1.2),
                              facecolor="#111")
    fig.subplots_adjust(hspace=0.05, wspace=0.05)

    img_norm = _normalize(img)
    H, W = img.shape

    for r in range(n_rows):
        for c in range(n_cols):
            ax = axes[r][c]
            yc = int(offset_y + r * spacing)
            xc = int(offset_x + c * spacing)

            y1, y2 = max(0, yc-half), min(H, yc+half+1)
            x1, x2 = max(0, xc-half), min(W, xc+half+1)
            roi = img_norm[y1:y2, x1:x2]

            ax.imshow(roi, cmap=CMAP_IMAGE, aspect="equal",
                      interpolation="nearest", vmin=0, vmax=1)
            ax.axis("off")

            has = bool(labels[r, c])
            for spine in ax.spines.values():
                spine.set_edgecolor(ATOM_COLOR if has else EMPTY_COLOR)
                spine.set_linewidth(1.2)
                spine.set_visible(True)

    fig.suptitle(
        f"Group: {folder.name}  |  {exp}ms ROI Grid ({n_rows}×{n_cols})"
        f"  |  atoms={int(np.sum(labels))}",
        color="white", fontsize=11, y=1.001
    )
    _save_or_show(fig, save_path, dpi=120)


# ═════════════════════════════════════════════════════════════════════════════
# 4. Dataset NPZ 快速预览
# ═════════════════════════════════════════════════════════════════════════════

def visualize_dataset(npz_path: str,
                      n_samples: int = 6,
                      roi_n: int = 17,
                      spacing: int = 54,
                      save_path: Optional[str] = None):
    """
    从合并后的 .npz 数据集中随机抽取 n_samples 帧，
    每帧显示：短曝光全图 / 长曝光全图 / GT标签热图。

    兼容 prepare_real_data.py 输出的 train.npz / val.npz / test.npz。
    """
    data = np.load(npz_path, allow_pickle=True)

    # 兼容两种键名
    imgs_s = data.get("images_short", data.get("img_short"))
    imgs_l = data.get("images_long",  data.get("img_long"))
    labels = data.get("labels")
    centers = data.get("centers")

    N = len(imgs_s)
    n_samples = min(n_samples, N)
    indices = np.random.choice(N, n_samples, replace=False)

    fig, axes = plt.subplots(n_samples, 3,
                              figsize=(13, 4.5 * n_samples),
                              facecolor="#1a1a2e")
    if n_samples == 1:
        axes = axes[np.newaxis, :]

    col_titles = ["短曝光图 (L1)", "长曝光图 (L2)", "GT 标签"]

    for row, idx in enumerate(indices):
        img_s = imgs_s[idx]
        img_l = imgs_l[idx]
        lbl   = labels[idx]       # [K] or [Rows, Cols]

        # 显示短曝光
        axes[row, 0].imshow(_normalize(img_s), cmap=CMAP_IMAGE,
                             aspect="equal", interpolation="nearest")
        axes[row, 0].set_ylabel(f"Frame {idx}", color="white", fontsize=9)

        # 显示长曝光
        axes[row, 1].imshow(_normalize(img_l), cmap=CMAP_IMAGE,
                             aspect="equal", interpolation="nearest")

        # 叠加 GT 格点（若有 centers）
        if centers is not None:
            ctr = centers[idx]    # [K, 2]
            K = len(ctr)
            lbl_flat = lbl.flatten() if lbl.ndim > 1 else lbl
            for k in range(K):
                yc, xc = ctr[k]
                has = bool(lbl_flat[k]) if k < len(lbl_flat) else False
                color = ATOM_COLOR if has else EMPTY_COLOR
                half = roi_n // 2
                for ax_idx in [0, 1]:
                    rect = mpatches.Rectangle(
                        (xc-half, yc-half), roi_n, roi_n,
                        lw=0.5, edgecolor=color, facecolor="none", alpha=0.7)
                    axes[row, ax_idx].add_patch(rect)

        # GT 标签热图
        if lbl.ndim == 1:
            # 尝试推断方形格点数
            side = int(np.round(np.sqrt(len(lbl))))
            lbl_2d = lbl.reshape(side, side) if side*side == len(lbl) else lbl[np.newaxis, :]
        else:
            lbl_2d = lbl

        axes[row, 2].imshow(lbl_2d, cmap="Greens", vmin=0, vmax=1,
                             aspect="equal", interpolation="nearest")
        n_atoms = int(np.sum(lbl))
        axes[row, 2].set_title(f"atoms={n_atoms}", color="white", fontsize=8)

        for ax in axes[row]:
            ax.axis("off")

    for c, t in enumerate(col_titles):
        axes[0, c].set_title(t, color="white", fontsize=10)

    fig.suptitle(f"Dataset Preview: {Path(npz_path).name}  (N={N})",
                 color="white", fontsize=12)
    _save_or_show(fig, save_path)


# ═════════════════════════════════════════════════════════════════════════════
# 5. 任意两档曝光对比
# ═════════════════════════════════════════════════════════════════════════════

def compare_exposures(group_dir: str,
                      exp_a: int = 8, exp_b: int = 160,
                      save_path: Optional[str] = None):
    """
    并排对比两个曝光档位，同时显示差图（归一化后）。
    """
    folder = Path(group_dir)
    img_a = _load_tif(folder, exp_a)
    img_b = _load_tif(folder, exp_b)

    if img_a is None or img_b is None:
        print(f"[警告] 未找到 {exp_a}ms 或 {exp_b}ms 图像。")
        return

    fig, axes = plt.subplots(1, 3, figsize=(18, 6), facecolor="#1a1a2e")
    a_norm = _normalize(img_a)
    b_norm = _normalize(img_b)
    diff   = b_norm - a_norm

    axes[0].imshow(a_norm, cmap=CMAP_IMAGE, aspect="equal",
                   interpolation="nearest")
    axes[0].set_title(f"{exp_a} ms  (短曝光)", color="white", fontsize=11)

    axes[1].imshow(b_norm, cmap=CMAP_IMAGE, aspect="equal",
                   interpolation="nearest")
    axes[1].set_title(f"{exp_b} ms  (长曝光)", color="white", fontsize=11)

    axes[2].imshow(diff, cmap="RdBu_r", aspect="equal",
                   interpolation="nearest", vmin=-0.5, vmax=0.5)
    axes[2].set_title(f"差图  ({exp_b}ms − {exp_a}ms，归一化后)",
                       color="white", fontsize=11)

    for ax in axes:
        ax.axis("off")

    fig.suptitle(f"Exposure Comparison  |  Group: {folder.name}",
                 color="white", fontsize=13)
    _save_or_show(fig, save_path)


# ═════════════════════════════════════════════════════════════════════════════
# 6. GT 生成流程分解
# ═════════════════════════════════════════════════════════════════════════════

def visualize_gt_pipeline(group_dir: str,
                          n_rows: int = 20, n_cols: int = 20,
                          spacing: int = 54,
                          save_path: Optional[str] = None):
    """
    可视化 Ground Truth 生成的 4 个步骤：
    ①最短曝光原图 → ②叠加图 → ③背景减除后信号图 → ④GT标签叠加
    """
    folder = Path(group_dir)

    img_min = _load_tif(folder, 8)
    stacked = None
    for exp in EXPOSURES:
        img = _load_tif(folder, exp)
        if img is not None:
            stacked = img if stacked is None else stacked + img

    if stacked is None:
        print(f"[警告] 目录 {group_dir} 中无法读取图像。")
        return

    offset_y, offset_x = _auto_grid_offset(stacked, spacing)
    labels = _infer_labels(stacked, n_rows, n_cols, spacing,
                           offset_y, offset_x)

    bg = np.median(stacked)
    signal = np.clip(stacked - bg, 0, None)

    n_atoms = int(np.sum(labels))

    fig, axes = plt.subplots(1, 4, figsize=(22, 6), facecolor="#1a1a2e")
    titles = [
        "① 最短曝光 (8ms)",
        "② 全档叠加图",
        "③ 背景减除·信号图",
        f"④ GT 标签  (atoms={n_atoms})"
    ]
    imgs  = [img_min, stacked, signal, stacked]
    cmaps = [CMAP_IMAGE, CMAP_IMAGE, "hot", CMAP_IMAGE]

    for ax, img, cm, t in zip(axes, imgs, cmaps, titles):
        if img is None:
            ax.text(0.5, 0.5, "N/A", ha="center", va="center",
                    color="gray", transform=ax.transAxes)
            ax.axis("off")
            ax.set_title(t, color="white", fontsize=10)
            continue
        ax.imshow(_normalize(img), cmap=cm, aspect="equal",
                  interpolation="nearest")
        ax.set_title(t, color="white", fontsize=10)
        ax.axis("off")

    # 在第4张图上叠加格点
    _draw_grid_overlay(axes[3], labels, offset_y, offset_x, spacing,
                       roi_n=17, show_empty=True)

    # 添加信号图的色条
    sm = plt.cm.ScalarMappable(cmap="hot",
                                norm=plt.Normalize(0, np.percentile(signal, 99.5)))
    sm.set_array([])
    plt.colorbar(sm, ax=axes[2], fraction=0.03, pad=0.02,
                 label="Signal (a.u.)")

    fig.suptitle(f"GT Generation Pipeline  |  Group: {folder.name}",
                 color="white", fontsize=13)
    _save_or_show(fig, save_path)


# ═════════════════════════════════════════════════════════════════════════════
# 7. L3 热力图 预测 vs GT
# ═════════════════════════════════════════════════════════════════════════════

def visualize_heatmap(img: np.ndarray,
                      gt_heatmap: np.ndarray,
                      pred_heatmap: Optional[np.ndarray] = None,
                      title: str = "L3 Heatmap",
                      save_path: Optional[str] = None):
    """
    L3 U-Net 热力图结果可视化。

    Parameters
    ----------
    img          : [H, W] 原始图像（短曝光）
    gt_heatmap   : [H, W] Ground Truth 高斯热力图
    pred_heatmap : [H, W] 模型预测热力图（可选）
    """
    n_cols = 3 if pred_heatmap is not None else 2
    fig, axes = plt.subplots(1, n_cols, figsize=(6 * n_cols, 6),
                              facecolor="#1a1a2e")

    axes[0].imshow(_normalize(img), cmap=CMAP_IMAGE, aspect="equal",
                   interpolation="nearest")
    axes[0].set_title("Input Image", color="white", fontsize=11)

    axes[1].imshow(gt_heatmap, cmap=CMAP_HEAT, aspect="equal",
                   interpolation="nearest", vmin=0, vmax=1)
    axes[1].set_title("GT Heatmap", color="white", fontsize=11)

    if pred_heatmap is not None:
        axes[2].imshow(pred_heatmap, cmap=CMAP_HEAT, aspect="equal",
                       interpolation="nearest", vmin=0, vmax=1)
        corr = np.corrcoef(gt_heatmap.ravel(), pred_heatmap.ravel())[0, 1]
        axes[2].set_title(f"Pred Heatmap  (corr={corr:.4f})",
                           color="white", fontsize=11)

    for ax in axes:
        ax.axis("off")

    fig.suptitle(title, color="white", fontsize=13)
    _save_or_show(fig, save_path)


# ═════════════════════════════════════════════════════════════════════════════
# 命令行快速调用
# ═════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="PA-3HDA Visualization Tool")
    parser.add_argument("mode", choices=[
        "group", "labels", "roi_grid", "dataset",
        "compare", "gt_pipeline"
    ], help="可视化模式")
    parser.add_argument("--path",     required=True, help="组目录或 .npz 文件路径")
    parser.add_argument("--save",     default=None,  help="输出图片路径（默认弹窗显示）")
    parser.add_argument("--exp_a",    type=int, default=8)
    parser.add_argument("--exp_b",    type=int, default=160)
    parser.add_argument("--n-rows",   type=int, default=20)
    parser.add_argument("--n-cols",   type=int, default=20)
    parser.add_argument("--spacing",  type=int, default=54)
    parser.add_argument("--n-samples",type=int, default=6)
    args = parser.parse_args()

    if args.mode == "group":
        visualize_group(args.path, save_path=args.save)
    elif args.mode == "labels":
        visualize_labels(args.path, args.n_rows, args.n_cols,
                         args.spacing, save_path=args.save)
    elif args.mode == "roi_grid":
        visualize_roi_grid(args.path, exp=args.exp_a,
                           n_rows=args.n_rows, n_cols=args.n_cols,
                           spacing=args.spacing, save_path=args.save)
    elif args.mode == "dataset":
        visualize_dataset(args.path, n_samples=args.n_samples,
                          save_path=args.save)
    elif args.mode == "compare":
        compare_exposures(args.path, args.exp_a, args.exp_b,
                          save_path=args.save)
    elif args.mode == "gt_pipeline":
        visualize_gt_pipeline(args.path, args.n_rows, args.n_cols,
                              args.spacing, save_path=args.save)
