"""
data/simulate.py
PA-3HDA 仿真数据生成器 —— 对齐 caps-tum/neutral-atom-imaging-simulation 物理模型

物理场景 : ¹⁷¹Yb 399nm 荧光成像
相机     : Qbit 4610 sCMOS (readout_noise=0.35e-)

建模效应（与 caps-tum 库对齐）:
  1.  Poisson 光子散射噪声
  2.  Gaussian PSF（含 Zernike 像差：散焦/像散/彗差）
  3.  光源空间展宽 (light_source_stdev)
  4.  原子热运动位置抖动 (atom_position_jitter)       ← NEW
  5.  杂散光 (stray_light_rate * exposure_time)
  6.  Gamma 分布暗电流 (dark_current_alpha/beta)
  7.  偏置钳位 (bias_clamp) + 偏置抖动 (bias_stdev)
  8.  行噪声 (row_noise_stdev)
  9.  列噪声，零均值 Gumbel 分布 (column_noise_scale)
 10.  闪烁噪声，零均值 Gumbel 分布 (flicker_noise_scale)
 11.  读出噪声 Gaussian (readout_stdev)
 12.  原子存活概率 (survival_probability)  —— 影响 labels
 13.  串扰 (crosstalk)
 14.  PSF 椭圆像差 (psf_ellipticity)                  ← NEW
 15.  PSF 全局漂移抖动 (psf_drift_stdev)               ← NEW
 16.  热像素 (hot_pixel_rate, hot_pixel_amp)           ← NEW
 17.  整数像素值 + 截断到 [0, 65535]  (16-bit ADC)
"""

import numpy as np
from typing import Tuple, Optional


class AtomArraySimulator:
    """
    模拟原子阵列荧光图像（CMOS 相机噪声模型，与 caps-tum 库对齐）。

    新增真实效应说明
    ─────────────────────────────────────────────────────────
    atom_position_jitter  : 原子热运动导致的位置抖动 (px RMS)
                            ¹⁷¹Yb @10μK, 100kHz 阱频率 → ~0.35px
                            不确定时建议取 0.3~0.5px

    psf_ellipticity       : PSF 椭圆度，模拟物镜像散/不完美准直
                            值域 [0, 1)，0=完美圆形，0.15=典型实验室水平
                            实现：σ_x = σ*(1+ε), σ_y = σ*(1-ε), ε~U(0, ellipticity)
                            每帧随机抽取，模拟随温度漂移的缓慢像差变化

    psf_drift_stdev       : PSF 中心漂移（机械振动/气流，px RMS）
                            影响整帧所有原子的 PSF 整体偏移（共模），
                            独立于 light_source_stdev（单原子随机抖动）
                            典型值 0.1~0.3px

    hot_pixel_rate        : 热像素密度（px^-2），每帧随机出现
                            Qbit 4610 典型值 ~1e-5（每百万像素约10个）

    hot_pixel_amp         : 热像素额外亮度（ph 当量）
    ─────────────────────────────────────────────────────────
    """

    def __init__(
        self,
        # ── 阵列参数 ──
        n_rows: int = 20,
        n_cols: int = 20,
        grid_spacing: int = 54,          # px，对应 5μm / (4.6μm/50) = 54px
        # ── PSF ──
        psf_sigma: float = 4.6,          # px，含像差的综合 PSF σ
        light_source_stdev: float = 1.0, # px，原子位置抖动/光源展宽（单原子）
        # ── 新增：真实效应 ──
        atom_position_jitter: float = 0.35, # px RMS，热运动位置抖动
        psf_ellipticity: float = 0.10,      # PSF 椭圆度（0~1），像散/准直误差
        psf_drift_stdev: float = 0.15,      # px，全帧 PSF 整体漂移（机械振动）
        hot_pixel_rate: float = 1e-5,       # px^-2，热像素密度
        hot_pixel_amp: float = 500.0,       # ph 当量，热像素亮度
        # ── 信号（短曝光 L1 / 长曝光 L2）──
        scattering_rate: float = 35000,  # ph/s/atom
        exposure_time_l1: float = 0.020, # s，短曝光 20ms
        exposure_time_l2: float = 0.040, # s，长曝光 40ms
        survival_probability: float = 1.0,
        # ── 背景 ──
        stray_light_rate: float = 200.0, # ph/s/px
        # ── 量子效率 ──
        quantum_efficiency: float = 0.72,   # Qbit 4610 @399nm
        # ── 暗电流（Gamma 分布）──
        dark_current_alpha: float = 0.003,
        dark_current_beta: float = 1.0,
        # ── 偏置 ──
        bias_clamp: float = 100.0,
        bias_stdev: float = 0.5,
        # ── 空间噪声 ──
        row_noise_stdev: float = 0.01,
        column_noise_scale: float = 0.005,
        flicker_noise_scale: float = 0.005,
        # ── 读出噪声 ──
        readout_stdev: float = 0.35,        # e-，Qbit 4610
        # ── 串扰 ──
        crosstalk: float = 0.01,
        # ── 图像尺寸 ──
        image_h: int = 0,
        image_w: int = 0,
    ):
        self.n_rows = n_rows
        self.n_cols = n_cols
        self.grid_spacing = grid_spacing
        self.psf_sigma = psf_sigma
        self.light_source_stdev = light_source_stdev
        self.atom_position_jitter = atom_position_jitter
        self.psf_ellipticity = psf_ellipticity
        self.psf_drift_stdev = psf_drift_stdev
        self.hot_pixel_rate = hot_pixel_rate
        self.hot_pixel_amp = hot_pixel_amp
        self.scattering_rate = scattering_rate
        self.exposure_time_l1 = exposure_time_l1
        self.exposure_time_l2 = exposure_time_l2
        self.survival_probability = survival_probability
        self.stray_light_rate = stray_light_rate
        self.quantum_efficiency = quantum_efficiency
        self.dark_current_alpha = dark_current_alpha
        self.dark_current_beta = dark_current_beta
        self.bias_clamp = bias_clamp
        self.bias_stdev = bias_stdev
        self.row_noise_stdev = row_noise_stdev
        self.column_noise_scale = column_noise_scale
        self.flicker_noise_scale = flicker_noise_scale
        self.readout_stdev = readout_stdev
        self.crosstalk = crosstalk

        # 从 scattering_rate 推导出每帧光子数
        self.atom_signal    = scattering_rate * exposure_time_l1 * quantum_efficiency
        self.atom_signal_l2 = scattering_rate * exposure_time_l2 * quantum_efficiency
        self.background     = stray_light_rate * exposure_time_l1 * quantum_efficiency
        self.background_l2  = stray_light_rate * exposure_time_l2 * quantum_efficiency

        # 自动计算图像尺寸
        margin = int(3 * grid_spacing)
        self.image_h = image_h if image_h > 0 else (n_rows - 1) * grid_spacing + 2 * margin
        self.image_w = image_w if image_w > 0 else (n_cols - 1) * grid_spacing + 2 * margin

        # 原子网格中心坐标 (row, col)
        row_offset = (self.image_h - (n_rows - 1) * grid_spacing) / 2.0
        col_offset = (self.image_w - (n_cols - 1) * grid_spacing) / 2.0
        rows = np.arange(n_rows) * grid_spacing + row_offset
        cols = np.arange(n_cols) * grid_spacing + col_offset
        col_grid, row_grid = np.meshgrid(cols, rows)
        self.centers = np.stack([row_grid.ravel(),
                                 col_grid.ravel()], axis=1)  # (K, 2)
        self.K = len(self.centers)

    # ──────────────────────────────────────────────────────────────────
    # PSF
    # ──────────────────────────────────────────────────────────────────
    def _psf_kernel(self, sigma_y: float, sigma_x: float) -> np.ndarray:
        """
        归一化椭圆高斯 PSF 核。
        sigma_y: 行方向 σ（px）
        sigma_x: 列方向 σ（px）
        """
        # 核尺寸按较大的 σ 确定
        sigma_max = max(sigma_y, sigma_x)
        ks = int(np.ceil(6 * sigma_max)) | 1
        half = ks // 2
        y, x = np.mgrid[-half:half+1, -half:half+1]
        kernel = np.exp(-(x**2 / (2 * sigma_x**2) + y**2 / (2 * sigma_y**2)))
        return (kernel / kernel.sum()).astype(np.float32)

    def _add_psf(self, canvas: np.ndarray,
                 cy: float, cx: float,
                 amplitude: float,
                 sigma_y: float, sigma_x: float):
        """将单原子椭圆 PSF 叠加到 canvas（含边界保护）"""
        H, W = canvas.shape
        kernel = self._psf_kernel(sigma_y, sigma_x)
        ks = kernel.shape[0]
        half = ks // 2
        r_center = int(round(cy))
        c_center = int(round(cx))
        r0 = r_center - half;  r1 = r0 + ks
        c0 = c_center - half;  c1 = c0 + ks
        pr0 = max(0, -r0);  pr1 = ks - max(0, r1 - H)
        pc0 = max(0, -c0);  pc1 = ks - max(0, c1 - W)
        ir0 = max(0, r0);   ir1 = min(H, r1)
        ic0 = max(0, c0);   ic1 = min(W, c1)
        if pr1 <= pr0 or pc1 <= pc0 or ir1 <= ir0 or ic1 <= ic0:
            return
        canvas[ir0:ir1, ic0:ic1] += amplitude * kernel[pr0:pr1, pc0:pc1]

    # ──────────────────────────────────────────────────────────────────
    # 单帧渲染（完整 CMOS 噪声链 + 真实效应）
    # ──────────────────────────────────────────────────────────────────
    def _render_frame(self,
                      labels: np.ndarray,
                      atom_signal: float,
                      background: float,
                      rng: np.random.Generator) -> np.ndarray:
        """
        渲染一帧（对齐 caps-tum CMOS 噪声模型 + 新增真实效应）。

        噪声链:
          光子信号 → PSF卷积(椭圆) → 光源抖动 → 位置抖动
          → 全帧PSF漂移 → 量子效率
          → 暗电流 → 偏置 → 行噪声 → 列噪声 → 闪烁噪声
          → 读出噪声 → 热像素 → 整数截断
        """
        H, W = self.image_h, self.image_w

        # ══ 帧级随机参数（每帧采样一次）══════════════════════════════

        # A. PSF 椭圆度（每帧缓慢漂移，模拟温度引起的像差变化）
        eps = rng.uniform(0, self.psf_ellipticity)       # 椭圆度幅度
        angle = rng.uniform(0, np.pi)                    # 随机方向
        # 旋转分量: sigma_y/sigma_x 相对 base sigma 的比例
        sigma_y_frame = self.psf_sigma * (1 + eps * np.sin(angle) ** 2)
        sigma_x_frame = self.psf_sigma * (1 + eps * np.cos(angle) ** 2)

        # B. 全帧 PSF 漂移（机械振动/气流，共模偏移）
        drift_y = rng.normal(0, self.psf_drift_stdev) if self.psf_drift_stdev > 0 else 0.0
        drift_x = rng.normal(0, self.psf_drift_stdev) if self.psf_drift_stdev > 0 else 0.0

        # ══ 光电子 canvas ══════════════════════════════════════════════
        canvas = np.zeros((H, W), dtype=np.float64)

        # ① 杂散背景光（Poisson）
        canvas += rng.poisson(background, (H, W)).astype(np.float64)

        # ② 原子信号
        for i, (cy, cx) in enumerate(self.centers):
            if labels[i] == 0:
                continue

            # 热运动位置抖动（单原子随机，每帧每原子独立）
            jitter_y = rng.normal(0, self.atom_position_jitter) if self.atom_position_jitter > 0 else 0.0
            jitter_x = rng.normal(0, self.atom_position_jitter) if self.atom_position_jitter > 0 else 0.0

            # 光源展宽（light_source_stdev，caps-tum 原有效应）
            src_y = rng.normal(0, self.light_source_stdev) if self.light_source_stdev > 0 else 0.0
            src_x = rng.normal(0, self.light_source_stdev) if self.light_source_stdev > 0 else 0.0

            # 最终原子位置 = 标称位置 + 热运动抖动 + 光源展宽 + 全帧漂移
            cy_final = cy + jitter_y + src_y + drift_y
            cx_final = cx + jitter_x + src_x + drift_x

            # Poisson 光子数
            n_photons = rng.poisson(atom_signal)
            self._add_psf(canvas, cy_final, cx_final,
                          float(n_photons), sigma_y_frame, sigma_x_frame)

            # 串扰：向 8 邻居泄漏
            if self.crosstalk > 0:
                for di in [-1, 0, 1]:
                    for dj in [-1, 0, 1]:
                        if di == 0 and dj == 0:
                            continue
                        ncy = cy + di * self.grid_spacing
                        ncx = cx + dj * self.grid_spacing
                        if 0 <= ncy < H and 0 <= ncx < W:
                            ct_amp = rng.poisson(max(0, n_photons * self.crosstalk))
                            self._add_psf(canvas, ncy, ncx, float(ct_amp),
                                          sigma_y_frame, sigma_x_frame)

        # ③ 暗电流（Gamma 分布，per pixel）
        if self.dark_current_alpha > 0:
            dc = rng.gamma(self.dark_current_alpha, self.dark_current_beta, (H, W))
            canvas += dc

        # ④ 偏置钳位 + 偏置抖动
        bias = self.bias_clamp
        if self.bias_stdev > 0:
            bias = bias + rng.normal(0, self.bias_stdev)
        canvas += bias

        # ⑤ 行噪声（每行一个偏移，Gaussian）
        if self.row_noise_stdev > 0:
            row_noise = rng.normal(0, self.row_noise_stdev, (H, 1))
            canvas += row_noise

        # ⑥ 列噪声（零均值 Gumbel）
        if self.column_noise_scale > 0:
            col_noise = rng.gumbel(0, self.column_noise_scale, (1, W))
            col_noise -= col_noise.mean()
            canvas += col_noise

        # ⑦ 闪烁噪声（零均值 Gumbel，per pixel）
        if self.flicker_noise_scale > 0:
            flicker = rng.gumbel(0, self.flicker_noise_scale, (H, W))
            flicker -= flicker.mean()
            canvas += flicker

        # ⑧ 读出噪声（Gaussian）
        canvas += rng.normal(0, self.readout_stdev, (H, W))

        # ⑨ 热像素（随机亮点，模拟相机缺陷像素）
        if self.hot_pixel_rate > 0:
            n_hot = rng.poisson(self.hot_pixel_rate * H * W)
            if n_hot > 0:
                hot_rows = rng.integers(0, H, n_hot)
                hot_cols = rng.integers(0, W, n_hot)
                hot_amps = rng.exponential(self.hot_pixel_amp, n_hot)
                canvas[hot_rows, hot_cols] += hot_amps

        # ⑩ 整数截断（16-bit ADC，去掉偏置后返回净信号）
        canvas = np.clip(np.round(canvas - bias), 0, 65535).astype(np.float32)
        return canvas

    # ──────────────────────────────────────────────────────────────────
    # 公开接口
    # ──────────────────────────────────────────────────────────────────
    def generate_frame(self,
                       labels: np.ndarray,
                       rng: Optional[np.random.Generator] = None
                       ) -> Tuple[np.ndarray, np.ndarray]:
        """
        生成单帧短曝光 + 长曝光图像对。

        Args:
            labels : (K,) int，1=有原子，0=无原子
            rng    : 随机数生成器
        Returns:
            short_img : (H, W) float32，短曝光（L1，20ms）
            long_img  : (H, W) float32，长曝光（L2，60ms）
        """
        if rng is None:
            rng = np.random.default_rng()

        short_img = self._render_frame(labels, self.atom_signal,    self.background,    rng)
        long_img  = self._render_frame(labels, self.atom_signal_l2, self.background_l2, rng)
        return short_img, long_img

    def generate_frame_with_survival(self,
                                     fill_prob: float,
                                     rng: np.random.Generator
                                     ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        生成帧并模拟原子存活概率（caps-tum survivalProbability 效应）。
        """
        labels_initial = (rng.random(self.K) < fill_prob).astype(np.int32)
        survival_mask  = rng.random(self.K) < self.survival_probability
        labels_survived = (labels_initial * survival_mask).astype(np.int32)

        short_img = self._render_frame(labels_survived, self.atom_signal,    self.background,    rng)
        long_img  = self._render_frame(labels_survived, self.atom_signal_l2, self.background_l2, rng)
        return short_img, long_img, labels_survived

    def generate_dataset(self,
                         n_frames: int,
                         fill_prob: float = 0.85,
                         rng_seed: int = 42,
                         use_survival: bool = False
                         ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        批量生成数据集。

        Args:
            n_frames    : 帧数
            fill_prob   : 原子填充概率
            rng_seed    : 随机种子
            use_survival: 是否启用存活概率模拟
        Returns:
            images_short : (N, H, W) float32
            images_long  : (N, H, W) float32
            labels       : (N, K)   int32
        """
        rng = np.random.default_rng(rng_seed)
        all_short, all_long, all_labels = [], [], []
        for _ in range(n_frames):
            if use_survival:
                s, l, lbl = self.generate_frame_with_survival(fill_prob, rng)
            else:
                lbl = (rng.random(self.K) < fill_prob).astype(np.int32)
                s, l = self.generate_frame(lbl, rng=rng)
            all_short.append(s)
            all_long.append(l)
            all_labels.append(lbl)

        return (np.stack(all_short),
                np.stack(all_long),
                np.stack(all_labels))
