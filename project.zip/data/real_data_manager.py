import os
import glob
import numpy as np
from PIL import Image
import json
import torch
from tqdm import tqdm

class RealDataManager:
    """
    PA-3HDA Real Data Manager
    Handles the 1001 groups of real acquisition data.
    Structure: data/{group_id}/{exposure}ms/*.tif
    """
    def __init__(self, data_root, config):
        self.data_root = data_root
        self.config = config
        self.exposures = [8, 10, 20, 40, 80, 160]
        self.groups = self._find_groups()
        
        # Lattice parameters from config
        self.n_rows = config['array']['n_rows']
        self.n_cols = config['array']['n_cols']
        self.spacing = config['array']['grid_spacing']
        self.roi_n = config['roi']['n']
        
    def _find_groups(self):
        groups = []
        if not os.path.exists(self.data_root):
            return []
        for d in os.listdir(self.data_root):
            if os.path.isdir(os.path.join(self.data_root, d)) and d.isdigit():
                groups.append(int(d))
        return sorted(groups)

    def load_image(self, group_id, exposure):
        """Load TIF image for a specific group and exposure."""
        folder = os.path.join(self.data_root, str(group_id), f"{exposure}ms")
        tif_files = glob.glob(os.path.join(folder, "*.tif"))
        if not tif_files:
            # Try alternate structure: data/{group_id}/{exposure}ms.tif
            alt_path = os.path.join(self.data_root, str(group_id), f"{exposure}ms.tif")
            if os.path.exists(alt_path):
                tif_files = [alt_path]
            else:
                return None
        
        img = Image.open(tif_files[0])
        return np.array(img).astype(np.float32)

    def generate_ground_truth(self, group_id, threshold_sigma=5.0):
        """
        Generate binary labels by stacking all exposures.
        Logic: Sum all images -> Filter -> Peak detection at lattice sites.
        """
        stacked = None
        for exp in self.exposures:
            img = self.load_image(group_id, exp)
            if img is not None:
                if stacked is None:
                    stacked = img
                else:
                    stacked += img
        
        if stacked is None:
            return None
        
        # 1. Simple background subtraction (median)
        bg = np.median(stacked)
        signal = stacked - bg
        
        # 2. Extract ROI centers (Assuming a fixed grid for now)
        # In a real system, we might need to find the top-left corner first.
        # Here we assume (0,0) or use a calibration offset if provided.
        labels = np.zeros((self.n_rows, self.n_cols), dtype=np.int32)
        
        # Heuristic: Find global max to align grid if needed, or assume centered.
        # For this script, we'll assume grid centers are roughly at (r*spacing, c*spacing)
        # with some offset.
        offset_y, offset_x = self._estimate_grid_offset(signal)
        
        for r in range(self.n_rows):
            for c in range(self.n_cols):
                y = int(offset_y + r * self.spacing)
                x = int(offset_x + c * self.spacing)
                
                # Check if center is within bounds
                if 0 <= y < signal.shape[0] and 0 <= x < signal.shape[1]:
                    # Measure average signal in a small central core (e.g. 5x5)
                    core = signal[max(0, y-2):y+3, max(0, x-2):x+3]
                    if np.mean(core) > threshold_sigma * np.std(signal):
                        labels[r, c] = 1
                        
        return labels, (offset_y, offset_x)

    def _estimate_grid_offset(self, signal):
        """Roughly estimate the top-left atom position."""
        # Simple implementation: find global max and assume it's one of the atoms.
        # Then find the best fit for (offset_y % spacing, offset_x % spacing).
        y_max, x_max = np.unravel_index(np.argmax(signal), signal.shape)
        off_y = y_max % self.spacing
        off_x = x_max % self.spacing
        return off_y, off_x

    def create_dataset_v4_style(self, output_dir, l1_exp=8, l2_exp=40):
        """
        Process all groups and save as .npz files compatible with PA-3HDA.
        """
        os.makedirs(output_dir, exist_ok=True)
        
        metadata = []
        
        for gid in tqdm(self.groups, desc="Processing Groups"):
            res = self.generate_ground_truth(gid)
            if res is None: continue
            
            labels, offset = res
            img_l1 = self.load_image(gid, l1_exp)
            img_l2 = self.load_image(gid, l2_exp)
            
            if img_l1 is None or img_l2 is None: continue
            
            # Save as NPZ
            save_path = os.path.join(output_dir, f"group_{gid:04d}.npz")
            np.savez_compressed(
                save_path,
                img_short=img_l1,
                img_long=img_l2,
                labels=labels,
                grid_offset=offset
            )
            
            metadata.append({
                "group_id": gid,
                "file": f"group_{gid:04d}.npz",
                "n_atoms": int(np.sum(labels))
            })
            
        with open(os.path.join(output_dir, "metadata.json"), "w") as f:
            json.dump(metadata, f, indent=4)
            
        print(f"Dataset created at {output_dir} with {len(metadata)} samples.")

if __name__ == "__main__":
    import yaml
    with open("/workspace/PA3HDA_v4/configs/default.yaml", 'r') as f:
        cfg = yaml.safe_load(f)
        
    manager = RealDataManager(data_root="/workspace/data", config=cfg)
    manager.create_dataset_v4_style(output_dir="/workspace/PA3HDA_v4/data/datasets/real_v1")
