import torch
import numpy as np
from torch.utils.data import Dataset


# ─────────────────────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────────────────────

def _extract_roi(img, cy, cx, roi_n):
    """从图像中裁剪 roi_n×roi_n 的 ROI，边界自动补零。"""
    n2 = roi_n // 2
    r0, c0 = int(cy) - n2, int(cx) - n2
    roi = np.zeros((roi_n, roi_n), dtype=np.float32)
    ir0, ir1 = max(0, r0), min(img.shape[0], r0 + roi_n)
    ic0, ic1 = max(0, c0), min(img.shape[1], c0 + roi_n)
    pr0 = ir0 - r0;  pr1 = pr0 + (ir1 - ir0)
    pc0 = ic0 - c0;  pc1 = pc0 + (ic1 - ic0)
    roi[pr0:pr1, pc0:pc1] = img[ir0:ir1, ic0:ic1]
    return roi


def _make_heatmap(shape, centers, labels, sigma):
    """生成多原子高斯热力图，用于 L3 U-Net 监督。"""
    H, W = shape
    heatmap = np.zeros((H, W), dtype=np.float32)
    radius = int(3 * sigma)
    for cy, cx in centers[labels == 1]:
        y0, y1 = max(0, int(cy) - radius), min(H, int(cy) + radius + 1)
        x0, x1 = max(0, int(cx) - radius), min(W, int(cx) + radius + 1)
        yy, xx = np.mgrid[y0:y1, x0:x1]
        heatmap[y0:y1, x0:x1] = np.maximum(
            heatmap[y0:y1, x0:x1],
            np.exp(-((xx - cx)**2 + (yy - cy)**2) / (2 * sigma**2)))
    return heatmap


# ─────────────────────────────────────────────────────────────
# L1 / L1-Wide Dataset
# ─────────────────────────────────────────────────────────────

class L1Dataset(Dataset):
    """
    L1 / L1-Wide ROI-CNN 数据集（短曝光）。

    增强策略（augment=True）：
      - 位置抖动：裁剪原点随机平移 ±jitter_px 像素，让模型学会识别
        偏离中心的光斑（解决 atom_position_jitter 导致 p_l1→0 的问题）
      - 高斯噪声：叠加 σ=0.01 的白噪声，提升泛化能力
    """
    def __init__(self, data_path: str, roi_n: int = 17,
                 augment: bool = True, jitter_px: int = 2):
        data = np.load(data_path, allow_pickle=True)
        self.images    = data['images_short'].astype(np.float32)
        self.labels    = data['labels'].astype(np.int32)
        self.centers   = data['centers']
        self.roi_n     = roi_n
        self.augment   = augment
        self.jitter_px = jitter_px
        self.N, self.K = self.labels.shape
        self._gmax     = float(np.percentile(self.images[:20], 99.9)) + 1e-6

    def __len__(self):
        return self.N * self.K

    def __getitem__(self, idx):
        fi, ai  = divmod(idx, self.K)
        img     = self.images[fi]
        cy, cx  = self.centers[ai]
        label   = self.labels[fi, ai]

        if self.augment and self.jitter_px > 0:
            dy = np.random.randint(-self.jitter_px, self.jitter_px + 1)
            dx = np.random.randint(-self.jitter_px, self.jitter_px + 1)
        else:
            dy = dx = 0

        roi = _extract_roi(img, cy + dy, cx + dx, self.roi_n)
        roi = roi / self._gmax

        if self.augment:
            roi += np.random.normal(0, 0.01, roi.shape).astype(np.float32)

        return (torch.from_numpy(roi).unsqueeze(0),
                torch.tensor(label, dtype=torch.float32))


# ─────────────────────────────────────────────────────────────
# L2 Dataset
# ─────────────────────────────────────────────────────────────

class L2Dataset(Dataset):
    """
    L2 ROI-CNN 数据集（长曝光）。

    增强策略（augment=True）：
      - 位置抖动：同 L1，覆盖 atom_position_jitter 导致的偏移
      - 长曝光 SNR 高，不加额外高斯噪声（避免引入训练分布偏差）
    """
    def __init__(self, data_path: str, roi_n: int = 17,
                 augment: bool = True, jitter_px: int = 2):
        data = np.load(data_path, allow_pickle=True)
        self.images    = data['images_long'].astype(np.float32)
        self.labels    = data['labels'].astype(np.int32)
        self.centers   = data['centers']
        self.roi_n     = roi_n
        self.augment   = augment
        self.jitter_px = jitter_px
        self.N, self.K = self.labels.shape
        self._gmax     = float(np.percentile(self.images[:20], 99.9)) + 1e-6

    def __len__(self):
        return self.N * self.K

    def __getitem__(self, idx):
        fi, ai  = divmod(idx, self.K)
        img     = self.images[fi]
        cy, cx  = self.centers[ai]
        label   = self.labels[fi, ai]

        if self.augment and self.jitter_px > 0:
            dy = np.random.randint(-self.jitter_px, self.jitter_px + 1)
            dx = np.random.randint(-self.jitter_px, self.jitter_px + 1)
        else:
            dy = dx = 0

        roi = _extract_roi(img, cy + dy, cx + dx, self.roi_n)
        roi = roi / self._gmax

        return (torch.from_numpy(roi).unsqueeze(0),
                torch.tensor(label, dtype=torch.float32))


# ─────────────────────────────────────────────────────────────
# L3 Dataset
# ─────────────────────────────────────────────────────────────

class L3Dataset(Dataset):
    """
    L3 U-Net 数据集（全图热力图回归）。

    训练时随机裁剪 crop_size×crop_size 块（防 VRAM 溢出）；
    验证/推理时可传 is_train=False 使用完整帧。
    """
    def __init__(self, data_path: str, sigma: float = 4.6,
                 crop_size: int = 256, is_train: bool = True):
        data = np.load(data_path, allow_pickle=True)
        self.images    = data['images_short'].astype(np.float32)
        self.labels    = data['labels'].astype(np.int32)
        self.centers   = data['centers']
        self.sigma     = sigma
        self.crop_size = crop_size
        self.is_train  = is_train
        self.N, self.H, self.W = self.images.shape

        print('[L3Dataset] 正在估算亮度统计值...', end='', flush=True)
        samples = self.images[np.linspace(0, self.N-1, 5, dtype=int)].ravel()
        self._gmax = float(np.percentile(samples, 99.9)) + 1e-6
        print(f' 完成 (Max={self._gmax:.1f})')

    def __len__(self):
        return self.N

    def __getitem__(self, idx):
        img_full = self.images[idx]
        lbl_full = self.labels[idx]

        if self.is_train:
            cs = self.crop_size
            y0 = np.random.randint(0, self.H - cs)
            x0 = np.random.randint(0, self.W - cs)
            img = img_full[y0:y0+cs, x0:x0+cs] / self._gmax
            mask = ((self.centers[:, 0] >= y0) & (self.centers[:, 0] < y0+cs) &
                    (self.centers[:, 1] >= x0) & (self.centers[:, 1] < x0+cs))
            local_c = self.centers[mask] - np.array([y0, x0])
            local_l = lbl_full[mask]
            hmap = _make_heatmap((cs, cs), local_c, local_l, self.sigma)
        else:
            img  = img_full / self._gmax
            hmap = _make_heatmap((self.H, self.W),
                                 self.centers, lbl_full, self.sigma)

        return (torch.from_numpy(img).unsqueeze(0),
                torch.from_numpy(hmap).unsqueeze(0))
