"""
PA3HDA_v4/data/dataset.py
==========================
PyTorch Dataset 适配器，支持：
  - 真实数据（prepare_real_data.py 输出）：每个曝光档位独立 NPZ
  - 仿真数据（auto_search.py 输出）：images_short / images_long 双图

真实数据 NPZ 格式（单曝光档位）
--------------------------------
  images   : [N, H, W]  float32  — 当前曝光档位图像
  labels   : [N, K]     int32    — GT标签（K = n_rows × n_cols，展平）
  centers  : [N, K, 2]  float32  — 格点中心 (y, x)
  group_ids: [N]        int32    — 组编号（可选，用于追溯）

仿真数据 NPZ 格式（双曝光）
----------------------------
  images_short : [N, H, W]   短曝光
  images_long  : [N, H, W]   长曝光
  labels       : [N, K]
  centers      : [N, K, 2]
"""

from __future__ import annotations

import os
from typing import Optional

import numpy as np
import torch
from torch.utils.data import Dataset


# ══════════════════════════════════════════════════════════════════════════════
# 工具
# ══════════════════════════════════════════════════════════════════════════════

def _extract_roi(img: np.ndarray, yc: float, xc: float, n: int) -> np.ndarray:
    """从全图中提取以 (yc, xc) 为中心的 n×n ROI（边界零填充）。"""
    H, W = img.shape
    half = n // 2
    y1, y2 = int(yc) - half, int(yc) + half + 1
    x1, x2 = int(xc) - half, int(xc) + half + 1

    roi = np.zeros((n, n), dtype=np.float32)
    sy1, sy2 = max(0, y1), min(H, y2)
    sx1, sx2 = max(0, x1), min(W, x2)
    dy1, dy2 = sy1 - y1, sy2 - y1
    dx1, dx2 = sx1 - x1, sx2 - x1

    if sy1 < sy2 and sx1 < sx2:
        roi[dy1:dy2, dx1:dx2] = img[sy1:sy2, sx1:sx2]
    return roi


# ══════════════════════════════════════════════════════════════════════════════
# 基类
# ══════════════════════════════════════════════════════════════════════════════

class _BaseROIDataset(Dataset):
    """
    从 NPZ 文件加载格点 ROI 数据集的基类。

    子类只需指定 _img_key（使用哪组图像）和可选的 _normalize。
    """
    _img_key: str = "images"       # 子类覆盖：'images' / 'images_short' / 'images_long'

    def __init__(self, npz_path: str, roi_n: int = 17, augment: bool = False):
        if not os.path.exists(npz_path):
            raise FileNotFoundError(f"数据集文件不存在: {npz_path}")

        data = np.load(npz_path, allow_pickle=True)

        # ── 图像：按子类指定的键名取，若不存在则 fallback ─────────────────────
        img_arr = None
        for key in (self._img_key, "images", "images_short", "images_long",
                    "img_short", "img_long"):
            if key in data:
                img_arr = data[key].astype(np.float32)
                break
        if img_arr is None:
            raise KeyError(f"NPZ 中未找到图像键 (tried: images, images_short, …): {npz_path}")

        # ── 统一为 [N, H, W] ──────────────────────────────────────────────────
        if img_arr.ndim == 2:
            img_arr = img_arr[np.newaxis]

        self.images  = img_arr                          # [N, H, W]
        self.labels  = data["labels"].astype(np.int32) # [N, K] or [N, R, C]
        self.centers = data["centers"].astype(np.float32) \
                       if "centers" in data else None   # [N, K, 2]

        # 展平 labels 为 [N, K]
        if self.labels.ndim == 3:
            self.labels = self.labels.reshape(len(self.labels), -1)

        self.N, self.K = self.labels.shape
        self.roi_n   = roi_n
        self.augment = augment

        # 索引：(帧索引, 格点索引)
        self.index = [(f, k) for f in range(self.N) for k in range(self.K)]

    # ── Dataset 接口 ──────────────────────────────────────────────────────────

    def __len__(self) -> int:
        return len(self.index)

    def __getitem__(self, idx: int):
        f, k = self.index[idx]
        img  = self.images[f]

        # 提取 ROI
        if self.centers is not None:
            yc, xc = float(self.centers[f, k, 0]), float(self.centers[f, k, 1])
        else:
            # fallback：等间距格点（须与 config 一致）
            yc, xc = 0.0, 0.0

        roi = _extract_roi(img, yc, xc, self.roi_n)

        # 最大值归一化
        mx = roi.max()
        if mx > 0:
            roi = roi / mx

        # 随机翻转增强
        if self.augment:
            if np.random.rand() > 0.5:
                roi = np.fliplr(roi).copy()
            if np.random.rand() > 0.5:
                roi = np.flipud(roi).copy()

        label = self.labels[f, k]
        x = torch.from_numpy(roi).unsqueeze(0).float()   # [1, roi_n, roi_n]
        y = torch.tensor(float(label)).float()
        return x, y


# ══════════════════════════════════════════════════════════════════════════════
# 公开子类
# ══════════════════════════════════════════════════════════════════════════════

class L1Dataset(_BaseROIDataset):
    """
    L1 / L1-Wide 数据集 — 使用短曝光档位图像。

    真实数据：加载对应曝光时间目录下的 train/val/test.npz，键名为 'images'。
    仿真数据：fallback 到 'images_short'。
    """
    _img_key = "images"


class L2Dataset(_BaseROIDataset):
    """
    L2 数据集 — 使用长曝光档位图像。

    真实数据：加载对应曝光时间目录下的 train/val/test.npz，键名为 'images'。
    仿真数据：fallback 到 'images_long'。
    """
    _img_key = "images_long"      # 仿真数据 fallback；真实数据命中 'images'


# ══════════════════════════════════════════════════════════════════════════════
# L3 全图热力图数据集
# ══════════════════════════════════════════════════════════════════════════════

class L3Dataset(Dataset):
    """
    L3 U-Net 热力图回归数据集。

    输出：
      x : [1, H, W]  输入图像（最大值归一化）
      y : [1, H, W]  高斯热力图（每个原子位置绘制一个 σ=gaussian_sigma 的高斯）
    """

    def __init__(self, npz_path: str, sigma: float = 4.6, is_train: bool = True):
        if not os.path.exists(npz_path):
            raise FileNotFoundError(f"数据集文件不存在: {npz_path}")

        data = np.load(npz_path, allow_pickle=True)

        # 图像：优先 'images'，再 fallback
        img_arr = None
        for key in ("images", "images_short", "img_short"):
            if key in data:
                img_arr = data[key].astype(np.float32)
                break
        if img_arr is None:
            raise KeyError(f"NPZ 中未找到图像键: {npz_path}")
        if img_arr.ndim == 2:
            img_arr = img_arr[np.newaxis]

        self.images  = img_arr
        self.labels  = data["labels"].astype(np.int32)
        self.centers = data["centers"].astype(np.float32) \
                       if "centers" in data else None
        self.sigma   = sigma

        # labels 展平为 [N, K]
        if self.labels.ndim == 3:
            self.labels = self.labels.reshape(len(self.labels), -1)

        self.N, self.K = self.labels.shape
        H, W = self.images.shape[1], self.images.shape[2]
        self.H, self.W = H, W

        # 预生成 GT 热力图（所有帧）
        self._gt_heatmaps = self._build_all_heatmaps()

    def _build_all_heatmaps(self) -> np.ndarray:
        """预计算所有帧的高斯热力图 [N, H, W]。"""
        hms = np.zeros((self.N, self.H, self.W), dtype=np.float32)
        tmp_size = int(self.sigma * 4)

        for f in range(self.N):
            hm = hms[f]
            for k in range(self.K):
                if self.labels[f, k] == 0:
                    continue
                if self.centers is not None:
                    yc, xc = self.centers[f, k]
                else:
                    continue
                y1, y2 = max(0, int(yc)-tmp_size), min(self.H, int(yc)+tmp_size+1)
                x1, x2 = max(0, int(xc)-tmp_size), min(self.W, int(xc)+tmp_size+1)
                yy, xx  = np.ogrid[y1:y2, x1:x2]
                g = np.exp(-((xx-xc)**2 + (yy-yc)**2) / (2*self.sigma**2))
                hm[y1:y2, x1:x2] = np.maximum(hm[y1:y2, x1:x2], g)
        return hms

    def __len__(self) -> int:
        return self.N

    def __getitem__(self, idx: int):
        img = self.images[idx]
        mx  = img.max()
        if mx > 0:
            img = img / mx

        x = torch.from_numpy(img).unsqueeze(0).float()
        y = torch.from_numpy(self._gt_heatmaps[idx]).unsqueeze(0).float()
        return x, y
