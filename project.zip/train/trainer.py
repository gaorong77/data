"""
train/trainer.py
PA-3HDA 通用 Trainer

支持:
  - L1 / L1-Wide / L2 模型训练（BCEWithLogitsLoss）
  - L3 U-Net 训练（MSELoss）
  - 基于 Fidelity 的 Best Checkpoint 保存
  - TensorBoard / matplotlib 可视化
  - WeightedRandomSampler（L2 均衡采样）
  - 跨平台: Windows/Mac(MPS)/Linux(CUDA)
"""

import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, WeightedRandomSampler
import numpy as np
from pathlib import Path


class Trainer:
    def __init__(self, model, train_dataset, val_dataset,
                 cfg: dict, save_path: str,
                 device: torch.device,
                 model_type: str = 'l1',      # l1 | l1_wide | l2 | l3
                 use_balanced_sampler: bool = False,
                 visualizer=None):
        """
        Args:
            model      : PyTorch 模型
            train_dataset / val_dataset: Dataset
            cfg        : training.{model_type} 子配置字典
            save_path  : 最优模型保存路径 (.pth)
            device     : torch.device
            model_type : 决定损失函数和评估指标
            use_balanced_sampler: L2 时启用均衡采样
            visualizer : Visualizer 实例（可选）
        """
        self.model      = model.to(device)
        self.device     = device
        self.cfg        = cfg
        self.save_path  = Path(save_path)
        self.save_path.parent.mkdir(parents=True, exist_ok=True)
        self.model_type = model_type
        self.visualizer = visualizer

        # ── 损失函数 ──
        loss_name = cfg.get('loss', 'bce')
        if loss_name == 'bce':
            self.criterion = nn.BCEWithLogitsLoss()
        elif loss_name == 'focal':
            self.criterion = FocalLoss(alpha=0.25, gamma=2.0)
        elif loss_name == 'mse':
            self.criterion = nn.MSELoss()
        else:
            raise ValueError(f'未知损失函数: {loss_name}')

        # ── 优化器 ──
        lr  = cfg.get('lr', 1e-3)
        wd  = cfg.get('weight_decay', 1e-4)
        opt = cfg.get('optimizer', 'adam').lower()
        if opt == 'adam':
            self.optimizer = torch.optim.Adam(model.parameters(), lr=lr,
                                              weight_decay=wd)
        elif opt == 'sgd':
            self.optimizer = torch.optim.SGD(model.parameters(), lr=lr,
                                             momentum=0.9, weight_decay=wd)
        else:
            raise ValueError(f'未知优化器: {opt}')

        # ── 学习率调度器 ──
        # L3 用 ReduceLROnPlateau（val_loss 平台期自动降 LR）
        # L1/L2 用 CosineAnnealingLR（平滑衰减）
        if model_type == 'l3':
            self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
                self.optimizer, mode='min', factor=0.5,
                patience=3, min_lr=1e-6)
        else:
            epochs = cfg.get('epochs', 50)
            self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer, T_max=epochs, eta_min=lr * 0.01)

        # ── DataLoader ──
        batch_size = cfg.get('batch_size', 64)
        workers    = 0   # Windows 必须为 0

        if use_balanced_sampler and model_type == 'l2':
            # WeightedRandomSampler 打破正负样本不均衡
            labels_flat = []
            for i in range(len(train_dataset)):
                _, lbl = train_dataset[i]
                labels_flat.append(int(lbl.item()))
            labels_flat = np.array(labels_flat)
            n_pos = labels_flat.sum()
            n_neg = len(labels_flat) - n_pos
            w_pos = 1.0 / max(n_pos, 1)
            w_neg = 1.0 / max(n_neg, 1)
            weights = np.where(labels_flat == 1, w_pos, w_neg)
            sampler = WeightedRandomSampler(
                torch.from_numpy(weights).float(),
                num_samples=len(weights), replacement=True)
            self.train_loader = DataLoader(
                train_dataset, batch_size=batch_size,
                sampler=sampler, num_workers=workers)
        else:
            self.train_loader = DataLoader(
                train_dataset, batch_size=batch_size,
                shuffle=True, num_workers=workers)

        self.val_loader = DataLoader(
            val_dataset, batch_size=batch_size,
            shuffle=False, num_workers=workers)

        self.epochs = cfg.get('epochs', 50)
        self.best_fidelity = -1.0
        self.history = {'train_loss': [], 'val_loss': [],
                        'val_acc': [], 'val_fidelity': [], 'lr': []}

    def _compute_metrics(self, logits, labels):
        """计算准确率和保真度"""
        if self.model_type == 'l3':
            # L3 输出热力图，用峰值像素相关系数作为代理指标
            # 避免 mse 量级不稳定导致 fidelity 跳变
            pred_flat = logits.view(-1).float()
            true_flat = labels.view(-1).float()
            # Pearson 相关系数: 1=完美, 0=无关
            vp = pred_flat - pred_flat.mean()
            vt = true_flat - true_flat.mean()
            corr_denom = (vp.norm() * vt.norm()).clamp(min=1e-8)
            pearson = (vp * vt).sum() / corr_denom
            pseudo = pearson.clamp(0, 1).item()
            return pseudo, pseudo
        probs  = torch.sigmoid(logits)
        preds  = (probs >= 0.5).long()
        labels_i = labels.long()
        acc = (preds == labels_i).float().mean().item()
        # 保真度: 所有原子都正确的帧比例（此处用逐样本精度代替）
        fidelity = acc  # 单样本级别近似
        return acc, fidelity

    def train_epoch(self):
        self.model.train()
        total_loss = 0.0
        for x, y in self.train_loader:
            x, y = x.to(self.device), y.to(self.device)
            self.optimizer.zero_grad()
            out  = self.model(x)
            # 统一形状: [B,1] → [B]，避免 BCE 形状不匹配
            if out.dim() == 2 and out.shape[1] == 1:
                out = out.squeeze(1)
            loss = self.criterion(out, y)
            loss.backward()
            self.optimizer.step()
            total_loss += loss.item() * x.size(0)
        return total_loss / len(self.train_loader.dataset)

    @torch.no_grad()
    def val_epoch(self):
        self.model.eval()
        total_loss = 0.0
        all_logits, all_labels = [], []
        for x, y in self.val_loader:
            x, y = x.to(self.device), y.to(self.device)
            out  = self.model(x)
            # 统一形状: [B,1] → [B]
            if out.dim() == 2 and out.shape[1] == 1:
                out = out.squeeze(1)
            loss = self.criterion(out, y)
            total_loss += loss.item() * x.size(0)
            all_logits.append(out.cpu())
            all_labels.append(y.cpu())
        logits = torch.cat(all_logits)
        labels = torch.cat(all_labels)
        acc, fidelity = self._compute_metrics(logits, labels)
        return (total_loss / len(self.val_loader.dataset)), acc, fidelity

    def train(self):
        """执行完整训练流程"""
        print(f'\n[Trainer] 开始训练 {self.model_type.upper()} | '
              f'设备: {self.device} | Epochs: {self.epochs}')
        print(f'  损失函数: {self.cfg.get("loss","bce")} | '
              f'LR: {self.cfg.get("lr")} | '
              f'Batch: {self.cfg.get("batch_size")}')
        print(f'  保存路径: {self.save_path}')
        print('-' * 60)

        for ep in range(1, self.epochs + 1):
            train_loss            = self.train_epoch()
            val_loss, val_acc, vl_fid = self.val_epoch()

            self.history['train_loss'].append(train_loss)
            self.history['val_loss'].append(val_loss)
            self.history['val_acc'].append(val_acc)
            self.history['val_fidelity'].append(vl_fid)
            current_lr = self.optimizer.param_groups[0]['lr']
            self.history['lr'].append(current_lr)

            print(f'Epoch [{ep:3d}/{self.epochs}]  '
                  f'train_loss={train_loss:.4f}  '
                  f'val_loss={val_loss:.4f}  '
                  f'corr={vl_fid:.4f}  '
                  f'lr={current_lr:.2e}', end='')

            # ── 按 Fidelity/Loss 保存最优模型 ──
            if self.model_type == 'l3':
                # L3 以 val_loss 最小为准
                is_best = (val_loss < -self.best_fidelity) if self.best_fidelity < 0 \
                          else (val_loss < getattr(self, '_best_val_loss', float('inf')))
                if is_best:
                    self._best_val_loss = val_loss
                    self.best_fidelity  = vl_fid
                    torch.save(self.model.state_dict(), self.save_path)
                    print(f'  ★ 新最优(loss={val_loss:.4f}) → {self.save_path}')
                else:
                    print()
            else:
                if vl_fid > self.best_fidelity:
                    self.best_fidelity = vl_fid
                    torch.save(self.model.state_dict(), self.save_path)
                    print(f'  ★ 新最优 → {self.save_path}')
                else:
                    print()

            # ── 学习率调度 ──
            if self.model_type == 'l3':
                self.scheduler.step(val_loss)       # plateau: 监控 val_loss
            else:
                self.scheduler.step()               # cosine: 按 epoch 衰减

            # ── 可视化 ──
            if self.visualizer is not None:
                self.visualizer.log(ep, train_loss, val_loss, val_acc, vl_fid)

        print('-' * 60)
        print(f'训练完成！最优 Fidelity = {self.best_fidelity:.4f}')
        if self.visualizer is not None:
            self.visualizer.save_plots(self.model_type)

        return self.best_fidelity, self.history


# ─────────────────────────────────────────────────
# FocalLoss（备用，不推荐用于 L1 正样本占多数场景）
# ─────────────────────────────────────────────────
class FocalLoss(nn.Module):
    def __init__(self, alpha: float = 0.25, gamma: float = 2.0):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, logits, targets):
        bce_loss = nn.functional.binary_cross_entropy_with_logits(
            logits, targets, reduction='none')
        probs = torch.sigmoid(logits)
        p_t   = probs * targets + (1 - probs) * (1 - targets)
        alpha_t = self.alpha * targets + (1 - self.alpha) * (1 - targets)
        focal_weight = alpha_t * (1 - p_t) ** self.gamma
        return (focal_weight * bce_loss).mean()
