"""
train/visualizer.py
训练曲线可视化器，支持 matplotlib 和 wandb。
"""

import os
import numpy as np
from pathlib import Path
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm


# ── Windows 中文字体自动配置 ──────────────────────────────────────────
def _setup_cjk_font():
    """自动检测并配置支持中文的字体（Windows / macOS / Linux）"""
    candidates = [
        'Microsoft YaHei',   # Windows 微软雅黑
        'SimHei',            # Windows 黑体
        'STHeiti',           # macOS 黑体-简
        'Heiti SC',          # macOS
        'Noto Sans CJK SC',  # Linux
        'WenQuanYi Micro Hei',
    ]
    available = {f.name for f in fm.fontManager.ttflist}
    for name in candidates:
        if name in available:
            plt.rcParams['font.family'] = name
            plt.rcParams['axes.unicode_minus'] = False
            return
    # 找不到中文字体时，把中文换成英文（不报错）
    plt.rcParams['axes.unicode_minus'] = False

_setup_cjk_font()


class Visualizer:
    """
    Args:
        backend : 'matplotlib' | 'wandb' | 'tensorboard'
        log_dir : 日志保存目录
        run_name: 本次训练名称
    """
    def __init__(self, backend='matplotlib', log_dir='./logs',
                 run_name='pa3hda', save_plots=True):
        self.backend    = backend
        self.log_dir    = Path(log_dir)
        self.run_name   = run_name
        self._save_plots = save_plots
        self.log_dir.mkdir(parents=True, exist_ok=True)

        self._epochs       = []
        self._train_losses = []
        self._val_losses   = []
        self._accs         = []
        self._fidelities   = []

        if backend == 'wandb':
            try:
                import wandb
                wandb.init(project='pa3hda', name=run_name, reinit=True)
                self._wandb = wandb
            except ImportError:
                print('[Visualizer] wandb 未安装，回退到 matplotlib')
                self.backend = 'matplotlib'
        elif backend == 'tensorboard':
            try:
                from torch.utils.tensorboard import SummaryWriter
                self._writer = SummaryWriter(log_dir=str(self.log_dir / run_name))
            except ImportError:
                print('[Visualizer] tensorboard 未安装，回退到 matplotlib')
                self.backend = 'matplotlib'

    def log(self, epoch, train_loss, val_loss, acc, fidelity):
        self._epochs.append(epoch)
        self._train_losses.append(train_loss)
        self._val_losses.append(val_loss)
        self._accs.append(acc)
        self._fidelities.append(fidelity)

        if self.backend == 'wandb' and hasattr(self, '_wandb'):
            self._wandb.log({'train_loss': train_loss, 'val_loss': val_loss,
                             'acc': acc, 'fidelity': fidelity, 'epoch': epoch})
        elif self.backend == 'tensorboard' and hasattr(self, '_writer'):
            self._writer.add_scalar('Loss/train', train_loss, epoch)
            self._writer.add_scalar('Loss/val',   val_loss,   epoch)
            self._writer.add_scalar('Metrics/acc',      acc,      epoch)
            self._writer.add_scalar('Metrics/fidelity', fidelity, epoch)

    def save_plots(self, model_name='model'):
        if not self._save_plots:
            return
        try:
            # matplotlib 已在开头导入
            matplotlib.use('Agg')
            # plt 已在开头导入

            fig, axes = plt.subplots(1, 2, figsize=(12, 4))
            fig.suptitle(f'PA-3HDA {model_name.upper()} 训练曲线', fontsize=14)

            # 损失曲线
            axes[0].plot(self._epochs, self._train_losses, 'b-o', ms=3,
                         label='Train Loss')
            axes[0].plot(self._epochs, self._val_losses,   'r-o', ms=3,
                         label='Val Loss')
            axes[0].set_xlabel('Epoch'); axes[0].set_ylabel('Loss')
            axes[0].legend(); axes[0].grid(alpha=0.3)
            axes[0].set_title('损失曲线')

            # 准确率/保真度曲线
            axes[1].plot(self._epochs, self._accs,       'g-o', ms=3,
                         label='Accuracy')
            axes[1].plot(self._epochs, self._fidelities, 'm-s', ms=3,
                         label='Fidelity')
            axes[1].axhline(y=0.999, color='r', ls='--', lw=1,
                            label='Target 0.999')
            axes[1].set_xlabel('Epoch'); axes[1].set_ylabel('Score')
            axes[1].set_ylim(0, 1.05); axes[1].legend(); axes[1].grid(alpha=0.3)
            axes[1].set_title('精度/保真度曲线')

            # 标注最优点
            best_ep  = self._epochs[int(np.argmax(self._fidelities))]
            best_fid = max(self._fidelities)
            axes[1].annotate(f'Best: {best_fid:.4f}\nEp{best_ep}',
                             xy=(best_ep, best_fid),
                             xytext=(best_ep, max(0, best_fid - 0.15)),
                             arrowprops=dict(arrowstyle='->', color='purple'),
                             fontsize=9, color='purple')

            plt.tight_layout()
            out_path = self.log_dir / f'{self.run_name}_{model_name}_curves.png'
            plt.savefig(out_path, dpi=150, bbox_inches='tight')
            plt.close()
            print(f'[Visualizer] 训练曲线已保存: {out_path}')
        except Exception as e:
            print(f'[Visualizer] 绘图失败: {e}')
